# SimpleDSH Development Plans

本文件是开发阶段的唯一索引；`plans/` 中的文件是临时执行计划，不是第二份产品契约。

## 权威顺序

发生冲突时按以下顺序处理：

1. `AGENTS.md`：仓库协作、审查和证据规则；
2. `dev/docs/architecture-charter.md`：顶层架构、不变量和复杂性边界；
3. `dev/docs/dsh-spec.md`：唯一正式 Engineering Spec，当前技术栈为 TypeScript；
4. 当前 Active Plan：阶段范围、所有权、验证与交接；
5. `dev/docs/gpt-dev-doc.md` 与 Pi 相关文档：设计研究和参考材料，不是实现契约。

Plan 不得覆写 Charter 或 Engineering Spec。若实现需要改变声明行为，Plan Lead 必须先更新 `dev/docs/dsh-spec.md`，完成所需独立审查，再改代码。

## 当前基线

- Stage 00 契约候选已在本地 revision `ce5b186` 通过 fresh review（Direction `KEEP`; Implementation `ACCEPT`; Verification `PASSED`），未 push/publish。
- 用户已指定 TypeScript 版 `dsh-spec.md` 为唯一正式 Engineering Spec，并已将其放入 `dev/docs/dsh-spec.md`；旧 Go 版已删除。
- Stage 00 接受时的 Spec SHA-256 为 `9242f09145f2b4c3f11a596f5a8a1b38e0c056e99f5783f139be9915a34124f2`；Stage 02 接受的 canonical Spec SHA-256 为 `b732f32eaec7ff43980c099d5d01a1c4a1146303e560ddfb1bda8f930da537fb`。Stage 03 fresh review 对 pre-review `fa1cefa4...` 给出 `KEEP/ACCEPT AFTER CUTS/NOT RUN`；五项 contract cuts 已落实，当前 implementation canonical Spec SHA-256 为 `77070cb66acfae15455ef6a192330ef285132f291c40ed835701e4bc57cdb867`。
- Stage 01 bootstrap 已在 implementation revision `fffe92e` 完成，并由 fresh read-only verification 确认全部验收；evidence revision `c0866f3` 后已清理 Plan/index。
- Stage 02 Protocol Truth 已在 implementation revision `58c5a08` 完成，evidence revision `9360579` 记录 70/70 离线测试、Node 22/26、精确 golden、live fail-closed 与 fresh cut-review `KEEP/ACCEPT/PASSED`；Plan/index 已清理。
- Stage 03 Journal/Artifact 已在 accepted evidence revision `ae5e2e4` 闭环并清理：implementation `3eec1ac`，fresh review `KEEP/ACCEPT/PASSED`、cuts 为零，Node 22/26 各 45/45，canonical Spec SHA-256 `77070cb66acfae15455ef6a192330ef285132f291c40ed835701e4bc57cdb867`。
- Stage 04 implementation/evidence 已在 `441f888` 获得接受，待按完成规则清理 Plan/index；Stage 05 由 `/root` 作为唯一 Lead，shared event/schema/tool wiring 仍由 Lead 串行集成，workers 仅写 Plan 登记的无冲突路径。

## 固定开发后端、请求与成本基线

- 唯一模型后端是 DeepSeek 官方 OpenAI-format Chat Completions API：`POST https://api.deepseek.com/chat/completions`。只借鉴 Maka 把后端危险收口到一个 `src/ds` 边界的做法；不建立 Provider interface/factory/registry/router，不使用任何 AI SDK，不支持其他 provider、兼容 endpoint、translation shim 或可配置 `base_url`。
- 开发和全部验收固定请求身份：`model = "deepseek-v4-flash"`、`thinking = {"type":"enabled"}`、`reasoning_effort = "max"`。不提供 Pro、`high`、模型选择/切换/路由；修改这三个值属于重新立项的契约变更，不是运行时配置。
- Fork 在 v0.1 baseline 为 `unavailable`；只有真实 same-prefix branch caller 通过 Stage 10 准入并先修订/review 契约后才可定义。任何未来方案仍固定 Flash/thinking/max，跨模型 fork、独立模型上下文和模型覆盖明确禁止。
- 成本统一使用 2026-08-03 核对的 [DeepSeek 官方价格页](https://api-docs.deepseek.com/quick_start/pricing) Flash USD 单价：cache hit `$0.0028/1M input tokens`、cache miss `$0.14/1M input tokens`、output `$0.28/1M tokens`，即 `r = 50`。Stage 00 和发布门必须刷新官方价格与核对日期，历史证据不得静默重算。
- 本地 `.env` 必须被 Git ignore，存在时必须是非 symlink 普通文件且权限 `0600`；不得打包或提交。只有 `CredentialLoader` 可自动读取它，只有 `src/ds` 可在发送瞬间消费 key 并放入官方 DeepSeek HTTP `Authorization` header；任何 header capture 必须 redact。工具 child env 采用 closed allowlist，不自动继承 key 或其他 credential。v0.1 明确不提供 bash 执行隔离：bash 与 harness 同用户运行，命令主动读取工作区、`.env` 或其他本机可读文件后，其输出可能进入 Artifact/Context/Journal；这是一项明确不做的产品边界，不得表述为 credential 安全保证。自动 credential 路径本身不得把 key/其他 credential values 放入模型可见 Request Snapshot body、Journal、Artifact、日志、诊断、Context、工具 child env 或交接材料。

## 状态语义

| 状态 | 含义 |
|---|---|
| `BLOCKED` | 前置条件或证据门未满足；不得实现，只能只读核对或执行审查允许的最小实验 |
| `READY` | 前置条件完整，可以由一个 Lead 领取 |
| `ACTIVE` | 恰好一个 Lead 持有写入权，写入范围已登记 |
| `REVIEW` | 设计或实现冻结，只处理 reviewer 裁决和必要 cuts |

不使用 `COMPLETE` 状态。阶段完成后，把耐久结论迁入正式文档或可复用 workflow，删除对应 Plan 文件及本索引行，由 Git 历史保存执行过程。

## 阶段索引

| 顺序 | Plan | Gate | 状态 | 依赖 | 独占写入域 | 独立审查 |
|---:|---|---|---|---|---|---|
| 04 | [Context, lineage, and projector](plans/04-context-lineage-projector.md) | Gate 1 基础 | `ACTIVE` | 03 evidence `ae5e2e4` | `src/ctx/**`、`src/lineage/**`、Snapshot 投影 | 必须 |
| 05 | [Effect Gateway and four tools](plans/05-effect-gateway-four-tools.md) | Gate 1 基础 | `ACTIVE` | 03 evidence `ae5e2e4`；与 04 无冲突路径并行 | `src/proc/**`、`src/tool/**`、Effect 事件集成 | 必须 |
| 06 | [Session Kernel](plans/06-session-kernel.md) | Gate 1 集成 | `BLOCKED` | 04、05 | `src/session/**`、最小 `src/cli/**` | 必须 |
| 07 | [Recovery, observability, and Gate 1](plans/07-recovery-observability-gate1.md) | Gate 1 | `BLOCKED` | 06 | 恢复集成、`src/cost/**`、只读投影、固定任务套件 | 必须 |
| 08 | [Permissions, file containment, and supply chain](plans/08-permissions-isolation-supply-chain.md) | Gate 2 基础 | `BLOCKED` | 07 | `src/permission/**`、file-containment/doctor/security fixtures、供应链检查 | 必须 |
| 09 | [Compaction](plans/09-compaction.md) | Gate 2 可选能力 | `BLOCKED` | 08 + 真实成本证据 | 准入前只读审计；获准后才由新契约分配源码域 | 必须 |
| 10 | [Fork](plans/10-fork.md) | Gate 2 可选能力 | `BLOCKED` | 08 + 真实分支需求；若 09 获准则与其串行 | 准入前只读审计；获准后才由新契约分配源码域 | 必须 |
| 11 | [Extensibility admission](plans/11-constrained-extensibility.md) | Gate 3 | `BLOCKED` | Gate 2 + 每个 slice 的真实 caller/失败证据 | 准入前只读审计；获准 slice 才由新契约分配源码域 | 必须 |
| 12 | [Release hardening](plans/12-release-hardening.md) | 发布门 | `BLOCKED` | 所有已获准阶段；未触发的可选能力不构成依赖 | 发布脚本、用户文档、跨平台矩阵、最终验收 | 条件性 |

## 依赖图

```text
02 [Gate 0] → 03
               ├→ 04 ─┐
               └→ 05 ─┴→ 06 → 07 [Gate 1] → 08 [Gate 2 基础]
                                               ├→ 09（证据触发）
                                               ├→ 10（证据触发）
                                               └→ 11（caller 触发）[Gate 3]
所有已获准阶段完成 ─────────────────────────────────────────→ 12
```

09 与 10 都会修改 lineage/context；即使二者分别获准，也必须串行集成。未出现触发证据时保持 `BLOCKED`，不得为了“路线图完整”预先实现。

09–11 在 Gate 2 之后必须各执行一次有界准入审计，不能无限期保留 `BLOCKED`。闭环只有两种：

- **admitted:** readiness 的真实 trigger/caller 完整，按 Plan 实现、review、验收；
- **non-admitted:** 审计细节留在 Plan/Git history，只把本 candidate 的普通用户可见 `unavailable` 说明和重新准入 trigger 写入 README；证明包内没有该能力的 module/stub/CLI/schema 后，删除 Plan 与索引行。

Non-admission 下对应稳定测试可以 exit 0，但它只证明“README 声明与实现缺席一致”，不得输出能力 PASS、建立 capability registry/protocol 或伪造 caller。未来证据出现时必须新建 Plan/revision 重新准入。

## 稳定验证入口

Stage 01 必须在 `package.json` 中建立并保持以下入口。具体测试文件可以演进，但下游 Plan 和 CI 只依赖这些命令：

```text
npm run check
npm run test:protocol
npm run test:journal
npm run test:context
npm run test:effects
npm run test:session
npm run test:recovery
npm run test:security
npm run test:acceptance
npm run test:release
```

Stage 09–11 未准入时不得预建 feature-specific script；若某项获准，具体 Spec/review 同时定义其测试入口。Gate 2/3 closure 用既有 `npm run check`、明确的 README 查询和 `npm pack --dry-run` 证明缺席；Stage 12 激活最终 `npm run test:release`，核对包内容与 README 声明一致。

Live DeepSeek 验证与离线 CI 分开，必须显式提供 `DSH_LIVE=1`、已记录的请求范围/成本条款和凭据：

```text
DSH_LIVE=1 npm run test:live:protocol
DSH_LIVE=1 npm run test:live:cache
```

任何真实 outbound request 还必须经过 durable user fact、Commit Boundary 与 `request_snapshot_stored`。因此 Stage 02 只以本地 HTTP fixture 冻结 transport/protocol；`test:live:protocol` 在 Stage 06 接通 Journal + Projector + Session Kernel 前必须 fail closed，不能为提前 smoke 绕过持久化不变量。Stage 06 负责最小 live protocol/tool roundtrip，Stage 07/12 负责 cache/task/release live evidence。

Stage 06 live 授权记录：授权日期 `2026-08-04`；只允许 DeepSeek v4 Flash、thinking enabled、`reasoning_effort=max`；不设硬性成本上限，计费使用本节已记录的 Flash 单价；禁止 Pro、`reasoning_effort=high`、任何其他模型或 provider。第一次 live 请求只能在所有 durable-before-send 测试通过后发出。

Live 运行必须先断言固定的 Flash/thinking/max 请求身份；`src/ds` 只在发送瞬间附加 Authorization header，header capture 一律 redact，自动 credential 路径不得把 credential values 放入 Snapshot body、日志、Context 或交接。测试不得把真实 key 交给 bash 或用真实 key 作为泄漏 sentinel。DeepSeek cache 是 best-effort；CI 验证前缀字节，live 命中率按分布报告。

## Agent Team 协作规则

### 角色

- **Plan Lead**：唯一可修改当前 Plan、本索引对应行、共享接口、事件 schema、请求序列化器、工具 registry 和正式契约；负责集成与最终验收。
- **Worker**：只修改 Plan 中分配的独占路径；不得修改 Plan、`PLANS.md` 或共享接口。
- **Verification Worker**：默认只读运行验证；需要新增 fixture/test 时必须先获得独占测试路径。
- **Reviewer**：使用 fresh、independent context，完整读取 `dev/docs/pi-style-reviewer-system-prompt.md`，保持只读，只给 verdict，不实现。

### 并行规则

- 默认阶段间不可并行；只有双方 Plan 都明确写出 `May overlap with` 且路径无交叠时才可并行。
- 同一文件、schema、serializer、registry、lockfile、根构建文件或 CI wiring 只有一个 writer。
- 多 Agent 可以并行做只读研究、fixture 设计和失败轨迹分类；合并契约与共享接口只能由 Lead 完成。
- 若工作区已经存在同路径未归因改动，停止写入并先完成 handoff 或用户协调。

### 必交接证据

每个 Worker 返回：

```text
baseline revision / dirty-state record
owned and changed paths
contract assumptions
diff summary
exact validation commands, exit codes, and result summary
metric or invariant impact
evidence artifact paths
unresolved risks
downstream assumptions
```

Lead 必须在自己的上下文复跑阶段验收，不能只引用 Worker 的“通过”结论。

## 全局停止条件

遇到以下任一情况立即停止实现：

- Charter 与 Engineering Spec 的相关语义尚未收敛；
- 上一 Gate 没有精确命令、退出码和结果；
- 没有可归因 baseline，或其他 Agent 正在修改相同路径；
- 行为变更没有先改 `dev/docs/dsh-spec.md`；
- Core 新机制没有可复现失败，或 Prompt、Skill、Artifact、现有原语、CLI、Extension 已足够；
- 必需审查没有得到 `KEEP`，或 `ACCEPT AFTER CUTS` 的 cuts 尚未落实；
- 试图改写 provider-visible 旧字节、重新 materialize 重试请求、把 Cache Checkpoint 当 Commit Boundary、绕过 Journal/Effect Gateway，或对 `indeterminate` 副作用猜测和盲重试；
- 试图引入第二本账、隐藏 Memory/状态、动态工具集、通用 Provider 抽象、内建 planner/fleet/agent graph；
- 试图加入 Pro、`high`、模型切换/路由/覆盖、跨模型 fork、其他 provider、兼容 endpoint、`base_url` 配置或 AI SDK；
- `.env` 未被 Git ignore/不是非 symlink `0600` 普通文件，CredentialLoader/`src/ds` 之外的自动 credential 路径消费 key，header capture 未 redact，工具 child env 自动继承 credential，文档把同用户 bash 说成隔离/安全边界，macOS/Linux 因缺少 Lima/container/runtime/capability 而拒绝 bash，真实 secret 被用于测试/交接证据，或自动 credential 路径把 credential value 写入 Snapshot body、Journal/Artifact/log/diagnostics/Context/tool child env/evidence；
- 未获得明确请求范围/成本条款与凭据授权就运行 live DeepSeek 验证；
- 为 token 或 wall-clock 收益牺牲协议、恢复、副作用正确性或 pass@1。

## Plan 完成与清理

每个阶段退出前必须：

1. 填写所有 Actual result、命令、退出码、revision 与 evidence path；
2. 获得所需 reviewer verdict，并落实所有 cuts；
3. 将契约变化写入 `dev/docs/dsh-spec.md`；
4. 只有可复用的验证方法才提升到 `dev/docs/workflows/`；
5. 把下游依赖改写为可验证证据，不依赖即将删除的 Plan；
6. 删除完成的 `plans/<slug>.md` 与本索引行；
7. 保留仍有效的 durable docs，只更新、合并或标记 superseded；
8. 由 Git 历史保存执行档案。
