# SimpleDSH Agent Rules

SimpleDSH is a small, DeepSeek-native agent harness. Keep the model intelligent
and the harness mechanical. Do not add workflow machinery without observed need.

## Before work

- Use `DOCS.md` when present to locate only the documents relevant to the task;
  until then, inspect `dev/docs/` directly.
- Check `PLANS.md` when present for overlapping active work.
- Create `plans/<slug>.md` only for cross-cutting, risky, multi-stage, or
  multi-session work. Trivial fixes do not need a plan.
- A plan states the actual need, non-goals, smallest working loop, verification,
  and expected metric or invariant impact.

## While changing

- `dev/docs/dsh-spec.md` is the current engineering contract. Change the
  contract first when intentionally changing declared behavior.
- Prefer files, Shell, Git, existing CLI tools, and visible artifacts.
- Core additions require an observed failure that Prompt, Skill, Artifact,
  existing primitives, or Extension cannot solve.
- Do not add hidden state, a second source of truth, or a second agent inside
  the harness.
- Keep changes scoped and preserve unrelated user work.

## Evidence and finish

- Define acceptance evidence before feedback-driven work and follow an indexed
  workflow when one exists.
- If no workflow exists, record the smallest adequate method in the active plan;
  promote it to `dev/docs/workflows/` only when it becomes reusable.
- Do not claim correctness or improvement without the exact validation command
  and result.
- Update durable documentation only when a contract, decision, or reusable
  workflow changed. Do not create documentation for ordinary implementation.
- Move durable conclusions out of a completed plan, then remove its file and
  index entry. Git history is the execution archive.
- Durable docs are not deleted merely because construction ended. Update, merge,
  or mark obsolete material as superseded and keep the document index accurate.

## North star

Optimize in this order:

1. Preserve protocol, recovery, and side-effect invariants.
2. Improve task pass@1 on the fixed real-task suite.
3. At equal task quality, reduce uncached input tokens per task.
4. At equal quality and token cost, reduce wall-clock time.

Never trade a higher-priority outcome for a lower-priority metric silently.

## Independent review

Do not invoke a reviewer for routine work.

A review is required when a change:

- adds a Core tool, mode, store, agent, provider abstraction, or background service;
- changes the system prompt, tool schema, context projection, cache lineage, or
  provider-visible request shape;
- changes persistence, recovery, concurrency, side-effect, permission, or
  sandbox semantics;
- introduces a durable abstraction without a second real caller;
- has multiple materially different designs and lacks decisive evidence.

A review is not required for:

- documentation-only or test-only changes;
- mechanical refactors with unchanged behavior and request shape;
- scoped bug fixes with a clear failing test and no architectural change;
- formatting, naming, or routine cleanup.

For a required review:

1. Use a fresh, independent Codex context, not the implementing agent and not
   its inherited reasoning.
2. Have it read
   `dev/docs/pi-style-reviewer-system-prompt.md` completely and follow it as
   the governing review instructions.
3. Give it only the actual need, hard constraints, active plan or diff,
   relevant code, and validation evidence.
4. Keep the reviewer read-only. It judges; it does not implement.
5. Record the verdict in the active plan. Do not create a permanent review
   report unless the result changes a durable design contract.

Normally perform one review per plan, at the earliest point where the proposed
design is concrete enough to judge.

Review again only when:

- the first verdict requests missing evidence;
- the design changes materially after review;
- the final implementation deviates from the reviewed design in a correctness
  boundary.

For gated changes:

- `KEEP` permits implementation;
- `NEED EVIDENCE` permits only the smallest experiment needed to obtain it;
- `REJECT` or `REWORK` requires revision or explicit user direction;
- `ACCEPT AFTER CUTS` requires the listed cuts, but not another review unless
  they materially change the design.
