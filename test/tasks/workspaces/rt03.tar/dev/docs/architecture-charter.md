# SimpleDSH 顶层架构

**Architecture Charter v0.1**

> SimpleDSH 是一个 DeepSeek-native、cache-stable、log-grounded、single-loop 的本地 Coding Harness。  
> 模型负责理解、规划与纠错；Harness 只负责忠实传递、可靠执行、事实持久化、恢复边界和成本可见性。

本文只定义系统定位、核心边界、不变量和演进准则。具体模型名、价格、超时、字段格式、目录结构和算法参数属于 Engineering Spec，不进入顶层架构。

---

## 1. 产品定位

SimpleDSH 不是通用 Agent 平台，也不是精简版工作流框架。

它解决一个明确问题：

> 让开发者在本地代码仓库中，以最小的 Harness 认知税，可靠、透明、低成本地使用 DeepSeek 完成真实工程任务。

成功率是第一目标。在任务成功率相当时，分别最小化：

- 未缓存输入；
- 端到端时间；
- 工具与上下文开销；
- 用户干预次数；
- 崩溃后的恢复歧义。

这里的 “Simple” 指模型可见语义面积小、系统概念少、行为可解释；不意味着牺牲协议正确性、持久化，也不允许隐瞒或夸大安全边界。

每个 Run 的基本形态是：

> **一个活动血统、一个单写者、一个模型循环、一份事实日志、一个确定性投影器、一个副作用出口、四个核心原语。**

---

## 2. 八项不可妥协的架构决定

### 2.1 DeepSeek Native

SimpleDSH 只连接 **DeepSeek 官方 API**，并直接表达其请求、流式响应、thinking、tool-call、reasoning roundtrip、缓存和 usage 语义。

LLM Backend 的职责边界参考 Maka：认证、请求发送、流解析、取消、错误与 usage 采集集中在一个后端收口，Session Kernel 不直接处理传输细节。这里借鉴的是**边界与收口方式**，不是 Maka 的多 Provider 能力。

Core 只有一个具体的 `DeepSeekOfficialBackend`，不建立 Provider interface、Factory、注册表、router、SDK 适配层或跨厂商归一化层；不支持 OpenAI、Anthropic 等其他 Provider，也不支持第三方“兼容 DeepSeek”端点、代理端点或可配置 `base_url`。后端复杂性不能泄漏成 Agent Policy。

### 2.2 Single Loop

系统只有一个模型—工具循环：

```text
Context → Model → Tool → Result → Model → Visible Output
```

模型负责规划、拆解、选择工具和根据错误自纠。Harness 不实现第二套 planner、router、goal state machine、reflection graph 或手写 reasoning protocol。

### 2.3 Single Journal

Append-only Journal 是唯一事实源。

会话状态、模型历史、恢复状态、成本、UI、搜索索引和诊断信息都必须能够由 Journal 与其引用的 Artifact 重建。任何缓存、索引或元数据文件都只能是可丢弃的投影，不能成为第二本账。

### 2.4 Deterministic Projector

Context 不是事实，而是事实的临时视图。

Context Projector 必须是版本化、确定性的纯投影：

```text
Journal + Artifacts + Active Lineage
→ Exact Model Context
→ Immutable Request Snapshot
```

时间、工作目录、Git 状态和扩展输入等外部信息，必须先成为显式事实，再进入投影。Projector 不得在请求时偷偷读取外部状态或注入隐藏 Memory。

### 2.5 Cache Lineage ABI

DeepSeek 官方 API 可见的请求形状是性能 ABI。

模型、协议版本、Projector 版本、system/project 指令、工具定义及顺序共同构成冻结的 Cache ABI。一个血统内只能在尾部追加，不能改写既有内容。

任何会改变冻结区的操作都必须显式创建新血统，包括：

- 未来经正式契约修订后修改固定开发模型元组（当前运行时没有入口）；
- 修改 system/project 指令；
- 增删或重排工具；
- 修改协议或投影规则；
- 压缩历史；
- 从旧边界分支。

重试必须复用同一个不可变 Request Snapshot，而不是重新构造“语义相同”的请求。

### 2.6 Bounded Evidence

原始证据不等于模型上下文。

大型工具输出保存为可寻址 Artifact；模型第一次只接收有界、稳定的投影，需要时再按范围读取。已经进入血统的结果永不被事后截断、摘要或改写。

计划、TODO、报告和长期知识使用用户可见、可编辑、可版本化的工作区文件，而不是隐藏数据库。

### 2.7 Fail-Closed Effects

所有外部副作用只能经过一个 Effect Gateway。

可能改变外部世界的操作遵循：

```text
durable prepared
→ external effect
→ durable completed
```

如果进程在两者之间崩溃，该操作进入 `indeterminate`，系统停止猜测，等待 reconcile 或人工确认。

这不是 exactly-once；它保证的是：系统永远不会把“不知道是否发生过”伪装成“没有发生过”，也不会盲目重试。

这个失败关闭边界只回答“外部操作是否已经发生以及结果是否已经 durable”，不把同用户进程清理观察包装成执行隔离。`bash` 已取得终态、原始输出已 durable 时，原进程组与 stdio 的回收观察以 `descendantsReaped` 如实记录；`false` 不会把一个已知终态改写成 `indeterminate`。反过来，只要仍是 `effect_prepared` 而没有 durable `effect_completed`，无论当时能否在主机上看到进程，都仍按 crash gap 进入 `indeterminate`。

### 2.8 Evidence-Driven Complexity

Core 只承载所有工作流都必须正确的不变量。工作流偏好进入文件、Skill、CLI 或 Extension。

任何新机制进入 Core 前，必须证明：

1. 它解决了反复出现、可复现的真实失败；
2. 模型、现有原语和普通 CLI 无法合理解决；
3. Extension 或 Artifact 不足以承载；
4. 它不会增加不成比例的上下文与状态负担；
5. 它可观察、可恢复、可禁用；
6. 它不破坏 Cache ABI、Journal 或 Effect Boundary。

---

## 3. 逻辑架构

```mermaid
flowchart LR
    U["User / CLI / TUI"] --> S["Session Kernel<br/>single writer · single loop"]

    J[("Append-only Journal<br/>source of truth")] --> C["Context and Prefix Kernel<br/>deterministic projector"]
    A[("Artifacts<br/>raw evidence · visible state")] --> C

    S --> C
    C --> D["DeepSeek Official Backend<br/>Maka-inspired boundary · one implementation"]
    D --> S

    S --> E["Effect Gateway<br/>four primitives · fail-closed effects"]
    E --> O["OS / Files / Shell"]

    S --> J
    D --> J
    E --> J
    E --> A

    J --> V["Read-only Projections<br/>UI · cache/cost · diagnostics"]

    X["Constrained Extensions"] -.-> C
    X -.-> E
```

| 架构域 | 唯一职责 | 明确不负责 |
|---|---|---|
| Interaction Plane | 展示、输入、中断、恢复、分支和用户控制 | 保存隐藏状态 |
| Session Kernel | 单循环、顺序、Run 生命周期、提交与恢复 | 任务规划、模型路由 |
| Context & Prefix Kernel | 血统、确定性投影、请求快照、完整性 | 推理、Memory 检索 |
| DeepSeek Official Backend | 官方端点认证、原生协议、流语义、错误分类、取消、usage | 多 Provider、兼容端点、模型路由 |
| Effect Gateway | 工具执行、机械策略、取消、生命周期观察、结果预算 | 判断任务策略、提供执行隔离 |
| Journal & Artifacts | 权威事实、原始证据、显式共享状态 | 成为工作流引擎 |
| Extension Plane | 按需增加局部能力 | 改写历史或绕过核心边界 |

---

## 4. 核心对象与边界

| 概念 | 含义 | 硬规则 |
|---|---|---|
| Session | 用户可见的持久化任务容器 | 一份权威 Journal，可包含多条分支 |
| Cache ABI | 模型与冻结请求形状的身份 | ABI 改变必开新血统 |
| Lineage | 一条具有独立分支身份的只追加历史 | 与 Cache ABI 分离；相同 ABI 可有多个血统 |
| Run | 一次具体执行尝试 | 恢复永远创建新 Run，不恢复旧进程栈 |
| Request Snapshot | 一次请求的精确序列化快照 | 重试原样复用，不重新 materialize |
| Cache Checkpoint | Provider 可能复用的前缀位置 | 只表示缓存价值，不表示副作用安全 |
| Commit Boundary | 协议闭合且所有副作用已完成或已明确处置的位置 | 默认恢复和分支的安全起点 |
| Artifact | Journal 引用的证据或用户可见状态 | 原始证据在保留期内不可改写；可编辑状态必须显式版本化 |

Cache Checkpoint 与 Commit Boundary 必须严格区分：前者是性能概念，后者才是正确性与恢复概念。

---

## 5. 主执行闭环

1. 用户输入先写入 Journal。

2. Projector 从当前血统生成不可变 Request Snapshot。

3. `DeepSeekOfficialBackend` 发起流式请求。流式内容可以作为“未提交预览”展示；只有完整响应才能进入正式模型历史。

4. 如果流在尚无语义输出时中断，可以原样重试同一 Snapshot；产生过文本或 tool-call delta 后，不得透明重放，只能记录 interruption 并创建新 Run。

5. 完整 assistant 响应作为原子事实提交。`reasoning_content`、tool calls 和协议状态不可拆分、改写或摘要。

6. 如果存在工具调用，所有调用进入 Effect Gateway：

   - 只有可证明只读的连续批次可以有界并行；
   - 结果仍按模型声明顺序提交；
   - 任何可能产生副作用的调用按模型顺序串行；
   - 原始输出进入 Artifact，模型只接收有界结果；
   - 所有 tool call 必须得到且仅得到一个匹配结果。

7. 工具结果完成后进入下一次模型请求；没有工具调用时创建 Commit Boundary，完成本轮。

---

## 6. 恢复语义

恢复不是继续旧连接、旧 goroutine 或旧内存状态，而是：

```text
重放唯一 Journal
→ 验证血统、请求和工具闭合性
→ 定位最后一个 Commit Boundary
→ 检查未完成副作用
→ 创建新 Run
→ 从已证明安全的状态继续
```

恢复决策只有三种：

- **确定未执行：** 可以执行；
- **确定已完成：** 不得重跑；
- **状态不确定：** 标记 `indeterminate`，停止并协调。

任何恢复后请求字节发生非预期变化、出现孤立 tool result、缺失 reasoning state 或未计划 Cache Break，都属于核心正确性故障。

---

## 7. Context 与缓存生命周期

一个血统由两部分构成：

```text
Frozen Header + Append-only Tail
```

Frozen Header 只包含高频、通用、必须常驻的内容；低频能力通过 Skill、文件或 CLI 渐进披露。日期、环境状态和项目变化只能作为新事实追加到尾部，不能回写到头部。

生命周期操作遵循：

- **开发模型元组：** 由 Engineering Spec 固定，不提供运行时切换；未来若变更，必须先修订契约并创建新的 Cache ABI 与血统；
- **工具集变化：** 新血统；Extension Tool 只能在血统创建时静态锁定；
- **Fork：** 只允许在固定开发模型元组内，从安全提交边界继承已有字节前缀；
- **Compaction：** 生成带来源引用和局限说明的有损 Digest，再创建新血统；
- **旧血统：** 始终保留为权威历史，Digest 永远不能替代原始事实。

Compaction 是显式、罕见且可度量的经济决策，应依据预计剩余工作量，而不是机械地依据上下文占用比例。

---

## 8. 工具、扩展与安全边界

Core 内建工具固定为四个正交原语：

```text
read · write · edit · bash
```

搜索、Git、测试、网络请求和进程管理优先复用现有 CLI。专用工具只有在真实数据证明其明显优于原语时才有资格加入。

扩展可以提供 Skill、Command 或静态工具，但不得：

- 修改既有 Journal 事实或 provider-visible 字节；
- 重排工具与事件；
- 在运行中偷偷改变工具集；
- 绕过 Effect Gateway 执行副作用；
- 注入不可追溯的隐藏上下文；
- 启动不可观察的隐藏 Agent。

权限策略只能决定“允许、询问或拒绝”；路径检查、closed child environment、进程组 TERM→KILL 与回收观察也都只是低成本的误操作和生命周期措施，不是安全沙箱。

**v0.1 明确不提供 `bash` 执行隔离。** 在受支持的 macOS 与 Linux 上，`bash` 直接以运行 SimpleDSH 的当前 Unix 用户执行，因此能访问该用户能访问的文件、秘密、进程与网络。此前评审过的 Linux 虚拟机/container 方案因依赖特定 Lima/runtime 版本、镜像 digest、mount 与主机 inode 条件，不能满足“干净机器安装后立即可用”的分发契约，现已放弃；它不是可选 backend，也不是缺少外部组件时的暂时 unavailable 状态。未来若重新引入任何内建执行隔离，必须作为新的产品契约提出并重新审查，不能从历史证据、配置项或 Extension 偷渡回来。

只有 Credential Loader 会在 Harness 自动路径中读取本地秘密引导文件，只有 `DeepSeekOfficialBackend` 会自动消费已加载的 API key；子进程环境从 closed allowlist 构造，避免普通继承。但同用户 `bash` 仍可主动读取 `.env`、检查父进程或访问其他可读秘密，Harness 不对此作对抗性保证。需要不可信执行隔离时，操作者必须把**整个 dsh 进程**放进其选择的 container、VM 或独立 Unix user；这属于部署边界，不是 SimpleDSH 的运行时依赖或能力探测。

---

## 9. 可观察性与架构适应度

用户必须随时能够回答：

- 模型实际看到了什么；
- 当前位于哪个 Session、Lineage、Run 和 Commit Boundary；
- 调用了什么工具，产生了什么结果或副作用；
- 哪些过程仍在运行；
- 状态和原始证据存在哪里；
- 如何中断、恢复、分支或回滚；
- 当前缓存与成本状况如何。

顶层指标分三组独立报告，不混成量纲不一致的总分：

- **任务效果：** pass@1、完成时间、调用轮数、用户干预；
- **缓存效率：** uncached tokens/task、按模型与血统统计的命中率、非计划 Cache Break；
- **运行正确性：** 协议错误、恢复成功率、工具错误、`indeterminate` 副作用数量。

必须长期保留的架构级验证包括：

- 重试与恢复后的请求字节一致；
- reasoning、tool call 和 tool result 始终闭合；
- 任意崩溃点都不会导致盲目重复副作用；
- 巨量工具输出不会无界进入 Context；
- 非计划 Cache Break 为零；
- Extension 无法改写历史或绕过 Effect Gateway。

---

## 10. 明确非目标

除非出现可复现失败并通过 Core 准入审查，SimpleDSH 不内建：

- 通用多 Provider 平台；
- OpenAI、Anthropic 或任何其他模型 Provider；
- 第三方 DeepSeek-compatible 端点、可配置 `base_url`、Provider registry、SDK adapter 或模型 router；
- Planner/Executor、Goal Mode、Plan Mode 或 Todo 状态机；
- 隐藏长期 Memory、Vector DB 或自动 Recall；
- 隐藏模型路由、Sub-agent Fleet、Agent Graph 或 Swarm；
- 动态 MCP 工具全集注入；
- 内部后台进程管理器、分布式队列或微服务；
- 多套 Event Store、Projection DB 或任务账本；
- 自动修改 system prompt、滚动摘要或频繁自动压缩；
- 桌面产品、开放 Gateway、Bot 通道和 IDE 全家桶；
- 把权限、路径检查或进程组清理表述成安全隔离的 permission theater；
- 内建 `bash` sandbox、虚拟机/container runner、runtime admission 或 host capability matrix。

除 Provider 范围和内建执行隔离外，这些能力并非永远禁止；它们只是没有资格默认占用所有用户和所有请求的复杂性预算。Provider 范围或内建 `bash` isolation/VM/container runner 若要改变，必须作为新的产品与架构契约提出，不能凭普通 feature evidence、配置或 Extension 混入。

---

## 11. 演进顺序

### Gate 0：Protocol Truth

先证明 DeepSeek 请求、流、reasoning/tool roundtrip、不可变请求和缓存遥测正确。此门不过，后续全部停止。

### Gate 1：Durable Minimal Loop

交付真正可用的最小闭环：单循环、四原语、单 Journal、Artifact、有界输出、副作用边界、恢复和基本可观察性。

### Gate 2：Safe Context Lifecycle

补齐权限决策、上下文生命周期与供应链验证；在观测数据证明必要后，加入显式 Compaction 与 Fork。v0.1 不在这一 Gate 增加内建 `bash` 隔离，仍不引入工作流编排。

### Gate 3：Constrained Extensibility

最后开放 Skills、Commands 和静态工具。每项扩展都必须通过核心不变量测试，且可以独立禁用和删除；v0.1 不以 Extension 形式预留或偷渡 Exec Backend。

---

## 12. 最终架构准则

> **模型拥有智能，Harness 拥有机制。**  
> **请求字节定义缓存身份，Journal 定义事实，Projector 定义模型视图，Effect Gateway 定义外部现实。**  
> **用原语完成动作，用 Artifact 保存状态，用 Extension 承载偏好，只为不可回避的正确性支付核心复杂性。**
