# 设计研究结论

> **状态说明（2026-08-03）：** 本文保留为非规范性设计研究；若与 `dev/docs/dsh-spec.md` 冲突，以 Engineering Spec 为准。当前正式决策是：LLM Backend 的集中边界参考 Maka，但只实现 `DeepSeekOfficialBackend`，只访问 DeepSeek 官方 API；不实现其他 Provider、兼容端点、SDK、registry、factory、router 或 `base_url`。开发模型固定为 `deepseek-v4-flash`，每次显式发送 `thinking=enabled`、`reasoning_effort=max`。下文涉及 Flash/Pro 对比或多 preset 的旧研究均已被此决策取代。

不要做一个“精简版 Reasonix”，也不要做一个“终端版 Maka”。

真正合理的组合是：

> **Pi 的最小原语内核 + Reasonix 的 DeepSeek 协议与 cache engineering + Maka 的 LLM Backend 边界、事实日志与可恢复执行。**

我会把这个 harness 定义为：

> **Cache-stable、log-grounded、single-loop 的 DeepSeek-native harness。**

它的核心不是增加 planner、memory、sub-agent、graph 或 mode，而是消灭四类 harness tax：

[
\text{Harness Tax}
==================

\text{Cache Miss}
+
\text{Context Noise}
+
\text{Tool Entropy}
+
\text{Recovery Ambiguity}
]

最终目标不是“功能最多”，而是：

[
\text{Effective Agent Performance}
==================================

\frac{\text{Task Progress}}
{\text{Uncached Tokens}+\text{Latency}+\text{Tool Overhead}+\text{Recovery Cost}}
]

一句话架构：

> **一个 Agent Loop、一个 append-only Journal、一个 Context Projector、一个 DeepSeek Official Backend、四个基础 Tools。**

---

# 一、三者分别取什么、舍什么

| 来源           | 真正值得继承                                                                                      | 不应进入核心                                                                         |
| ------------ | ------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------ |
| **Pi**       | 小 system prompt；`read/write/edit/bash` 四原语；无内建 plan、todo、sub-agent；工作流通过文件和 extension 表达    | 它对 DeepSeek 协议、cache、断点恢复和副作用一致性的处理还不够专门                                       |
| **Reasonix** | DeepSeek direct API；prefix cache 稳定性；静态 tool schema；SSE/Tool Call 协议修复；cache telemetry；单二进制 | Goal/Plan/AutoResearch、Memory、Fleet、Guardian、LSP、Remote、复杂 Coordinator、庞大默认工具面 |
| **Maka**     | typed model protocol；单一 stream adapter；attempt/TTFB/usage telemetry；Log is Runtime；T1/T2 副作用边界 | BackendRegistry、provider registry、AiSdkFlow、ModelAdapter、多 Provider/SDK、完整 Desktop/Task 平台 |

## 1. Pi：继承它的“功能准入标准”

Pi 默认只有 `read / write / edit / bash`，不内建 plan mode、sub-agent、todo 和 permission theater，把这些能力留给 extension、文件、容器和现有系统原语。它的精髓不是“代码少”，而是：

> **Core 只负责所有工作流都必须正确的 invariant，工作流偏好不进入 Core。**

这必须成为新 harness 的最高设计原则。([[GitHub](https://github.com/earendil-works/pi/tree/main/packages/coding-agent)][1])

但 Pi 不是 DeepSeek 专属设计：它没有把 DeepSeek 的 prefix cache、thinking tool-call roundtrip、cache-hit telemetry 和长 reasoning SSE 行为提升到第一等架构约束。因此我们不是复制 Pi，而是在 Pi 的哲学上补上 DeepSeek-native runtime。

---

## 2. Reasonix：只取下半身，不取上半身

Reasonix 最有价值的不是 Goal Mode、Planner 或 sub-agent，而是它底部这一层：

* 直接适配 DeepSeek；
* request prefix 稳定；
* tool schema canonicalization；
* cache-aware context maintenance；
* SSE keep-alive 与连接中断处理；
* assistant tool-call 与 tool result 配对修复；
* thinking 模式下 `reasoning_content` 的协议兼容；
* cache hit/miss 与 prefix shape 诊断。

它的工程规范本身强调 thin harness、single binary、lean dependencies 和 “Evolve, don’t over-engineer”。([[GitHub](https://github.com/esengine/DeepSeek-Reasonix/tree/main-v2)][2])

Reasonix 处理了几个非常值得直接学习的 DeepSeek 长尾问题：

1. 中断或恢复后的历史可能包含没有对应 tool result 的 assistant tool call，必须在再次请求前修复 pairing；
2. thinking tool-call turn 可能需要保留 provider-issued `reasoning_content` 字段；
3. SSE 在尚未产生任何语义输出前断开时可以安全重连，但已经产生 partial tool call 后绝不能透明重放；
4. 半截 tool-call arguments 不能暴露给执行层。([[GitHub](https://github.com/esengine/DeepSeek-Reasonix/blob/main-v2/internal/provider/openai/openai.go)][3])

这些属于 **DeepSeek transport correctness**，应该完整吸收。

但 Reasonix 当前已经从 thin harness 演进成一个较大的 agent platform：仓库中出现了 autoresearch、guardian、memory、planmode、jobs、LSP、remote、sandbox、skill、sub-agent fleet 等大量产品机制，核心 agent、coordinator 和 compaction 文件也变得非常庞大。它们不一定设计错误，但已经偏离“DeepSeek 专属、简洁、高性能 coding loop”的目标。([[GitHub](https://github.com/esengine/DeepSeek-Reasonix/tree/main-v2/internal)][4])

因此：

> **继承 Reasonix 的 DeepSeek Protocol/Cache 经验，重写它的 Agent/Workflow 层；Provider 边界由下节的 Maka 裁剪方案定义。**

---

## 3. Maka：继承语义，不继承基础设施规模

Maka 对 SimpleDSH 最直接的工程参考，是把模型协议、具体 stream adapter 与单次物理请求 telemetry 分开：上层只消费 typed event，adapter 独占 raw chunk 解析和取消语义，attempt outcome / TTFB / usage 与 best-effort diagnostics 分离。SimpleDSH 把这条边界裁成**一个** `DeepSeekOfficialBackend`。

Maka 另一个重要思想是：

> **Runtime Event Log 是事实源；Session、UI、model history、recovery、compaction 都是对事实日志的 projection。**

这比“把 messages 数组保存下来”深一层。因为 messages 只是下一次 inference 需要看到的内容，不是系统真正发生过的全部事实。Maka 明确区分了模型上下文、tool evidence、运行状态和恢复事实。([[GitHub](https://github.com/Maka-Agent/maka-agent/tree/main)][5])

Maka 的第二个关键贡献是 T1/T2：

```text
preflight
→ T1: durable tool.prepared
→ external side effect
→ T2: durable tool.completed
→ result may enter model context
```

如果进程在 T1 和 T2 之间崩溃，系统不能假装工具没运行，也不能盲目重试，而应将该 operation 标为 `indeterminate`，等待 reconcile 或人工判断。([[GitHub](https://github.com/maka-agent/maka-agent/blob/main/docs/architecture/runtime-resume-architecture.md)][6])

这是正确的 agent runtime invariant，应该保留。

但 Maka 是 local-first desktop workspace + durable task platform。它需要 SessionManager、RuntimeKernel、AgentRun、RuntimeRunner、AiSdkFlow、AgentBackend、TaskRun、Graph、AHE、SQLite operational authority 等多层结构，这对它的产品目标合理，但对一个高性能 coding harness 太重。([[GitHub](https://github.com/maka-agent/maka-agent/blob/main/docs/architecture/runtime-core-architecture-draft.md)][7])

因此：

> **取单一 LLM Backend 收口、“事实先于 projection”和“T1/T2”；不照搬 BackendRegistry、AiSdkFlow、多 Provider/SDK 与完整 event-sourcing 平台。**

---

# 二、推荐的总体架构

暂时称它为 **DSH：DeepSeek Harness**。

```text
                    ┌─────────────────────┐
                    │ CLI / TUI / JSON-RPC│
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │   Session Runtime   │
                    │ single writer/session│
                    └──────┬────────┬─────┘
                           │        │
              ┌────────────▼──┐   ┌─▼─────────────────┐
              │  Agent Loop   │   │ Append-only Journal│
              │ one loop only │   │ semantic facts     │
              └──────┬────────┘   └─┬─────────────────┘
                     │              │
          ┌──────────▼──────────┐   │
          │  Context Projector  │◄──┘
          │ journal → messages  │
          └──────────┬──────────┘
                     │
          ┌──────────▼──────────┐
          │ DeepSeek Native API │
          │ SSE / thinking/tool │
          │ cache telemetry     │
          └──────────┬──────────┘
                     │ tool calls
          ┌──────────▼──────────┐
          │    Tool Runtime     │
          │ validate/preflight  │
          │ T1 → execute → T2   │
          └──────┬────────┬─────┘
                 │        │
       ┌─────────▼──┐  ┌──▼──────────────┐
       │ Exec Backend│  │ Artifact Store  │
       │ host/container│ │ large raw output│
       └─────────────┘  └─────────────────┘
```

核心只有六个模块：

1. `agent`
2. `deepseek`
3. `session`
4. `context`
5. `tools`
6. `exec`

没有 `planner`、`coordinator`、`fleet`、`memory`、`graph`、`autoresearch`、`guardian`。

---

# 三、第一原则：DeepSeek API 不是普通 OpenAI-compatible Provider

截至 2026 年 8 月 3 日，SimpleDSH 开发期只使用官方 wire alias `deepseek-v4-flash`，只访问 `https://api.deepseek.com/chat/completions`，并固定 thinking enabled + reasoning effort max。DeepSeek API 是 stateless，每一轮都需要客户端重建完整历史。([[DeepSeek API Docs](https://api-docs.deepseek.com/zh-cn/index.html?utm_source=chatgpt.com)][8])

因此，不要设计：

```ts
interface GenericProvider {
  chat(...args: unknown[]): unknown;
}
```

然后在一堆 OpenAI、Anthropic、Gemini compatibility branches 里寻找 DeepSeek 的最小公分母。

应该直接设计：

```ts
final class DeepSeekOfficialBackend {
  stream(snapshot: ImmutableRequestSnapshot, signal: AbortSignal): AsyncIterable<DeepSeekEvent>;
}
```

内部结构直接表达：

* `thinking.type`
* `reasoning_effort`
* `reasoning_content`
* `tool_calls`
* `prompt_cache_hit_tokens`
* `prompt_cache_miss_tokens`
* SSE keep-alive
* `finish_reason`
* `system_fingerprint`
* DeepSeek strict tool schema

所谓“专属 harness”，核心价值就是不做无意义的 Provider abstraction。这个类是 Maka 式集中后端边界的**唯一具体实现**，不是 interface + factory；不接受 provider、model、effort 或 `base_url` 参数。

其他模型或非官方端点不属于当前产品范围；若未来要改变，必须先修改 Architecture Charter 与 Engineering Spec，而不是预留 adapter package。

---

# 四、第二原则：Cache Epoch 是第一等架构概念

DeepSeek 的硬盘缓存默认启用，基于完整匹配的输入 prefix unit；API 会直接返回 cache-hit 和 cache-miss tokens。([[DeepSeek API Docs](https://api-docs.deepseek.com/zh-cn/guides/kv_cache/)][9])

所以每个 session 应有明确的：

```text
cache_epoch
```

一个 epoch 内必须满足：

```text
Stable Header + Append-only Tail
```

## Stable Header

整个 epoch 中不可改变：

```text
1. base system prompt
2. project instructions snapshot
3. tool definitions
4. tool order
5. tool descriptions
6. model preset
7. protocol mode
```

## Append-only Tail

只能在末尾增加：

```text
user
assistant
tool
assistant
user
...
```

禁止在中间：

* 重写旧 system prompt；
* 插入动态 memory；
* 重新排序 tool schema；
* 动态增加 MCP tools；
* 每轮改变 skill 列表；
* 修改旧 tool result；
* 悄悄切换模型或 thinking preset。

任何下列操作都会创建新的 `cache_epoch`：

```text
model change
tool set change
system/project instruction change
compaction
branch from old turn
protocol shape change
```

这比“尽量利用 cache”更严格：

> **Request shape 本身就是 harness 的性能 ABI。**

---

# 五、最关键的 context 创新：不要事后 prune，应该入场时就 bounded

Reasonix 和 Maka 都设计了较复杂的后期 prune/compaction。它们解决的是真问题，但对 DeepSeek cache 来说，修改旧 tool result 会从修改点开始破坏历史 prefix。

更好的做法是：

> **原始输出永久保存，但 model-visible tool result 在第一次进入 transcript 时就被限制到合理尺寸，之后永不改写。**

例如 Bash 输出 20 MB：

```text
Raw output:
  artifacts/tool-0192.stdout
  sha256: ...
  size: 20 MB

Model-visible result:
  exit_code: 1
  duration: 31.2s
  first 120 lines: ...
  last 120 lines: ...
  omitted: 184,211 lines
  full_output: artifact://tool-0192.stdout
```

这样同时得到：

* Journal 中有真实 evidence；
* 模型看到足够的信息；
* 需要更多时可以 `read` artifact 的指定范围；
* 旧 transcript 不需要被后续修改；
* cache prefix 保持稳定；
* context 不会被一次测试输出炸穿。

这实际上是：

```text
Evidence != Context
```

Maka 的核心洞察应当保留，但实现应比 Maka 更简单：

```text
Raw evidence → Artifact
Bounded projection → Model context
```

而不是把所有 raw payload 先塞进 context，再设计复杂系统删除它。

---

# 六、Agent Loop 应该保持愚蠢

核心 loop 应当接近以下伪代码：

```go
append(turn.started)

for step := 0; step < maxSteps; step++ {
    messages := projector.Build(journal, cacheEpoch)

    response := deepseek.Stream(messages, staticTools)

    append(model.completed(response))

    if len(response.ToolCalls) == 0 {
        append(run.ended("completed"))
        return response.Content
    }

    calls := validate(response.ToolCalls)

    executeReadOnlyCallsConcurrently(calls)
    executeMutatingCallsSequentially(calls)

    // committed Tool Results automatically become
    // part of the next context projection
}

append(run.ended("step_limit"))
```

它不应该承担：

* task decomposition；
* planner selection；
* agent routing；
* memory retrieval policy；
* research mode；
* goal-state machine；
* sub-agent scheduling；
* self-reflection graph；
* autonomous retry policy。

这些都不是 model loop 的通用 invariant。

模型自己决定先读、搜索、编辑还是测试。Harness 只保证工具调用真实、上下文合法、日志可靠。

---

# 七、Tool Surface：就四个

默认工具：

```text
read
write
edit
bash
```

## `read`

负责：

* 文件读取；
* line range；
* 目录浅层列表；
* artifact range 读取。

## `write`

完整创建或覆盖文件。

## `edit`

精确 `old_text → new_text` 替换，带唯一性检查。不要同时内建五种 patch API。

## `bash`

运行现有系统命令：

* `rg`
* `find`
* `git`
* `pytest`
* `npm`
* `go test`
* `curl`
* `tmux`

Glob、Grep、Git、Test、Process、Package Manager 都不需要独立 tool。

### 为什么不做大量专用工具

每个新增工具都会增加：

* tool schema tokens；
* tool-selection entropy；
* cache prefix 体积；
* 参数格式错误；
* 语义重叠；
* harness 维护成本。

DeepSeek 当前支持 strict tool schema，但它仍属于 Beta，并要求 object properties 全部 required，且 `additionalProperties=false`。因此 harness 应提供一个 canonical schema compiler，启动 session 时锁定 strict 或 standard mode，不能在运行中来回切换。([[DeepSeek API Docs](https://api-docs.deepseek.com/zh-cn/guides/tool_calls/)][10])

Tool schemas 必须：

* 固定顺序；
* 固定 serialization；
* 短描述；
* 参数尽量扁平；
* 不使用 DeepSeek 不支持的 JSON Schema 特性；
* 在执行前再次本地校验。

---

# 八、并发只做一种：并行读取，串行写入

复杂 multi-agent 并发很容易降低整体代码一致性。

核心只支持：

```text
read-only tool calls → bounded concurrency
mutating tool calls  → serialized in model order
```

例如模型一次发出四个 `read`：

* 并行执行；
* 但结果按照原 tool-call 顺序写入 Journal；
* 保证下一轮 provider messages deterministic。

`write`、`edit`、`bash` 默认都视为可能产生副作用，串行执行。

不要尝试写一个 shell command classifier，猜某条 Bash 是否“只读”。这类复杂度不能提供可靠安全边界。

Session 内 single writer，不同 session 可以并行。

---

# 九、Journal：只要一份，不要三套 Store

推荐一个 session 一个 append-only 文件：

```text
.sessions/<session-id>/
    events.jsonl
    artifacts/
    meta.json
```

不需要第一版就使用：

* SessionStore；
* RuntimeEventStore；
* AgentRunStore；
* TaskEventStore；
* Projection DB；
* task ledger；
* migration authority。

JSONL 每条记录保持较小，较大 payload 进入 artifact。启动时扫描尾部；若最后一行因 crash 不完整，截断到最后一个合法 event。

最小事件集：

```text
turn.started
model.completed
model.interrupted
tool.rejected
tool.prepared
tool.completed
checkpoint.created
run.ended
```

必要 identity：

```text
session_id
turn_id
run_id
tool_call_id
operation_id
seq
```

不需要再单独引入 Maka 的 `invocation_id`。在我们这个 runtime 里，一个 `run_id` 就是一次具体 execution attempt。

---

# 十、T1/T2 只用于真正需要的地方

对于 `read`：

* crash 后重复执行通常安全；
* 不必每次都强制两次 fsync。

对于 `write / edit / bash`：

```text
1. validate
2. permission / execution preflight
3. append + fsync tool.prepared       // T1
4. execute external operation
5. append + fsync tool.completed      // T2
6. tool result may enter model context
```

恢复规则非常简单：

| Journal 状态                         | 恢复决策                      |
| ---------------------------------- | ------------------------- |
| 没有 `tool.prepared`                 | 工具一定没有越过执行边界              |
| `tool.prepared + tool.completed`   | 已完成，不得重跑                  |
| `tool.prepared` 无 `tool.completed` | 状态未知，禁止盲目重跑               |
| read call 没有 result                | 可以重新读取                    |
| run 没 terminal event               | 创建新 `run_id` continuation |

这保留了 Maka 最有价值的安全语义，但不需要引入它完整的 recovery control plane。

所谓 resume 也不是恢复旧 goroutine、旧 SSE connection 或旧 stack：

> **Resume 永远创建一个新 run，从最后一个被证明安全的 journal boundary 继续。**

---

# 十一、DeepSeek thinking 的正确处理

DeepSeek 当前普通多轮示例说明，历史 assistant `reasoning_content` 不会作为一般对话记忆继续使用；但 thinking + tool-call roundtrip 存在专门的协议形状，Reasonix 也专门处理了 tool-call turn 的 reasoning replay。([[DeepSeek API Docs](https://api-docs.deepseek.com/zh-cn/api_samples/thinking_mode_api_example_streaming/)][11])

因此应当区分：

## 普通 reasoning

* 流式显示给用户；
* 可以写入 diagnostics；
* 不把它当长期 memory；
* 不将其再总结回 prompt；
* 不要求普通 assistant turn 永久携带。

## Tool-call reasoning

* 作为 opaque provider state 保存；
* 严格按照当前 DeepSeek tool-call 协议回放；
* 不解析，不修改，不“优化”；
* protocol adapter 负责，不泄漏到 agent policy。

原则是：

> **Reasoning 不是 memory，但有时是 protocol state。**

---

# 十二、SSE 与网络恢复策略

DeepSeek 长 thinking 请求会发送 SSE keep-alive 注释；官方文档明确要求自解析 HTTP 时正确处理空行和 `: keep-alive`。([[DeepSeek API Docs](https://api-docs.deepseek.com/zh-cn/quick_start/rate_limit/?utm_source=chatgpt.com)][12])

Adapter 的重连规则必须是：

```text
连接断开
├─ 尚未产生任何 semantic output
│    └─ 可以透明重发请求
└─ 已经产生 text/tool-call delta
     └─ 不可透明重放
        记录 model.interrupted
        交给 runtime 创建新 run
```

尤其要避免：

* 已经向 UI 输出部分文本后重放，造成重复；
* 半截 tool-call JSON 被执行；
* partial arguments 被当作完整参数；
* 没有 `[DONE]` 却把 stream 当正常完成。

Tool call 应先在 adapter 内完整组装：

```text
delta by index
→ concatenate name/arguments
→ finish_reason=tool_calls
→ JSON parse
→ schema validate
→ emit complete ToolCall
```

只有最后一步完成，Agent Loop 才能看到它。

---

# 十三、开发模型：固定 V4 Flash + Max Thinking

开发期只有一个冻结请求元组：

```text
model = deepseek-v4-flash
thinking.type = enabled
reasoning_effort = max
```

`deepseek-v4-flash` 是当前官方 wire model ID；Harness 记录响应的 `model` 与 `system_fingerprint` 以观测官方维护 ID 背后的版本，但不会动态发现、路由或切换模型。model、thinking 和 effort 都不是 CLI、TOML、环境变量或 extension 配置。

因此没有 fast/balanced/deep preset，没有 Pro fallback，没有 `consult-pro`，也没有跨模型 fork。未来若改变元组，必须先修订正式契约、更新 golden request 与 Cache ABI，再创建新血统。

---

# 十四、Compaction 应当罕见，并显式创建新 Cache Epoch

DeepSeek 当前上下文很长，但上下文大不代表应该把所有东西都塞进去。真正应该优化的是：

```text
uncached input tokens
model-visible noise
attention dilution
cache reset frequency
```

由于工具输出已经在 admission time 被 bounded，正常 session 可以维持很久。

只有达到较高阈值，例如 80%–85% context budget，才进行 compaction。

最小 checkpoint：

```json
{
  "through_seq": 812,
  "source_hash": "...",
  "goal": "...",
  "completed": ["..."],
  "current_state": "...",
  "modified_files": ["..."],
  "verified_results": ["..."],
  "unresolved": ["..."],
  "artifact_refs": ["..."]
}
```

Replay：

```text
stable system/tool prefix
+ checkpoint
+ raw events after through_seq
+ current user turn
```

Checkpoint 必须包含：

* 覆盖到哪个 journal sequence；
* 对应 source hash；
* 关键 artifact refs；
* limitations。

不需要 Maka 那套多 ledger、rolling CAS projection 和复杂 checkpoint successor graph。

Compaction 本质上就是一次有意识的 cache reset，因此：

```text
checkpoint.created
→ cache_epoch++
```

不要每轮刷新 rolling summary。

---

# 十五、Memory 不应进入 Core

Core 不要实现：

* vector database；
* BM25 pre-turn recall；
* hidden long-term memory；
* automatic fact extraction；
* memory scoring；
* memory decay；
* memory consolidation。

需要长期状态时，优先使用：

```text
AGENTS.md
PROJECT.md
PLAN.md
NOTES.md
decisions/
reports/
Git commits
session artifacts
```

它们：

* 用户可见；
* 模型可读；
* 可以 diff；
* 可以编辑；
* 可以版本化；
* 可以跨 agent 共享；
* 不会偷偷改变 prompt。

以后若真实数据证明需要 retrieval，可以做一个 read-only extension，但 retrieval 结果必须追加在当前 user turn 尾部，不能改写 stable system prefix。

---

# 十六、Extension 只允许改变尾部，不能破坏 Cache ABI

第一版甚至不需要做完整 plugin framework。

先只保留两类扩展：

## 1. Skill

Markdown 文件，描述如何调用现有 CLI。

```text
.dsh/skills/docker-debug/SKILL.md
.dsh/skills/release/SKILL.md
```

按需 `read`，不默认把全文注入 system prompt。

## 2. Exec Backend

```go
type ExecBackend interface {
    Run(ctx context.Context, command Command) Result
}
```

可实现：

```text
LocalBackend
ContainerBackend
SSHBackend — 后续可选
```

真正的安全隔离由 container/VM/Unix user 完成，不伪装成复杂 permission framework。

后续若确实需要代码扩展，采用 subprocess + JSONL/stdio，而不是 Go in-process plugin。扩展只可：

* 在 session 创建时注册固定 tool；
* 在当前 user turn 末尾追加 context；
* 监听 journal event；
* 提供 execution backend。

它不能：

* 修改旧 events；
* 动态改 system prompt；
* 运行中重新排列 tools；
* 不经 Journal 直接执行副作用；
* 私自启动隐藏 agent。

---

# 十七、明确不做什么

第一版应明确拒绝：

1. **通用多 Provider 架构**
   这是只连接 DeepSeek 官方 API 的 harness，不为假设中的未来模型增加抽象；同时拒绝其他 Provider、第三方兼容端点、可配置 `base_url`、SDK、registry、factory 与 router。

2. **内建 Planner/Executor**
   DeepSeek 自己会规划。复杂任务可以写 `PLAN.md`。

3. **Goal Mode / AutoResearch Mode**
   它们是 workflow template，不是 runtime invariant。

4. **内建 Todo 数据库**
   使用 `TODO.md` 或 GitHub issue。

5. **Memory DB / Vector DB / 自动 BM25 recall**
   没有真实失败证据前不构建。

6. **Sub-agent Fleet / Agent Graph**
   可选外部 session，而不是 Core。

7. **内建 Self-check Agent**
   模型完成后正常运行测试即可；独立 reviewer 可以作为显式 extension。

8. **AHE / Self-evolution**
   属于实验平台，不属于 coding harness。

9. **动态 MCP Tool Dump**
   不把几十上百个 schemas 注入每轮 prompt。优先 CLI + skill。

10. **LSP、Browser、Remote、Computer Use 全家桶**
    真实需求出现后独立扩展。

11. **内部 Background Process Manager**
    使用 tmux、systemd、Docker、shell primitives。

12. **多套 Event Store 和 Projection DB**
    一个 append-only journal 足够启动。

---

# 十八、推荐代码布局

采用 Go 是合理选择：单 binary、SSE/进程并发直接、部署简单，也延续 Reasonix 已经验证过的工程方向。但代码结构必须比 Reasonix 收敛得多。

```text
cmd/dsh/
    main.go

internal/agent/
    loop.go
    run.go

internal/deepseek/
    client.go
    request.go
    stream.go
    toolcall.go
    protocol.go
    usage.go
    prefix.go

internal/session/
    journal.go
    events.go
    recovery.go

internal/context/
    projector.go
    budget.go
    checkpoint.go
    artifact_projection.go

internal/tools/
    registry.go
    read.go
    write.go
    edit.go
    bash.go

internal/exec/
    backend.go
    local.go
    container.go

internal/frontend/
    cli.go
    rpc.go
```

依赖方向：

```text
frontend
   ↓
agent
   ↓
deepseek / context / tools
   ↓
session / exec
```

禁止反向依赖。

尤其不要出现一个 3,000–4,000 行的 `agent.go` 或 `coordinator.go`。Agent Loop 应当保持在几百行内；复杂性应该集中在：

* DeepSeek protocol tests；
* journal crash tests；
* tool execution correctness；
* context projection tests。

---

# 十九、真正的高性能指标

不要只看总 tokens 和单轮 latency。核心指标应当是：

## DeepSeek 层

```text
prompt_cache_hit_tokens
prompt_cache_miss_tokens
cache_hit_ratio
time_to_first_reasoning_token
time_to_first_content_token
output_tokens/sec
stream interruption rate
tool-call repair rate
```

DeepSeek 官方明确区分 cache-hit 和 cache-miss tokens，当前两者计费差距也很大，因此 **uncached input tokens** 应当成为一级 KPI。([[DeepSeek API Docs](https://api-docs.deepseek.com/zh-cn/guides/kv_cache/)][9])

## Harness 层

```text
stable_prefix_tokens
tool_schema_tokens
model_visible_tool_output_tokens
artifact bytes externalized
cache epochs per session
compactions per 100 turns
tool validation failures
unknown-side-effect incidents
recovery success rate
```

## Agent 层

```text
task pass@1
turns to completion
model calls to completion
tool calls to completion
wall-clock task time
user interventions
regression rate
```

Benchmark 必须固定：

* 同一 DeepSeek model；
* 同一 reasoning preset；
* 同一 task；
* 同一 tool set；
* 同一 timeout；
* 同一 sandbox；
* 同一 project snapshot。

然后对比：

```text
Pi + generic DeepSeek adapter
Reasonix
新 DSH
```

重点看：

```text
pass@1
uncached tokens/task
wall time/task
tool error rate
cache hit ratio
```

而不是比较谁的 feature list 更长。

---

# 二十、推荐的实现顺序

## Phase 0：最小闭环

只实现：

```text
DeepSeek SSE
4 tools
single agent loop
CLI
in-memory transcript
cache usage metrics
```

先跑真实 coding tasks。

## Phase 1：Journal 与恢复

加入：

```text
events.jsonl
artifacts
run identities
T1/T2
safe-boundary continuation
```

## Phase 2：Context Engine

加入：

```text
admission-time output bounding
token budget
rare checkpoint
cache epoch
prefix fingerprint/diff
```

## Phase 3：真实验证后再扩展

只有出现真实需求才加入：

```text
container backend
skills
JSON-RPC frontend
external process extension
```

Planner、memory、fleet、graph 不列入默认 roadmap。只有 benchmark 明确证明它们解决了反复出现的失败，才承担新增复杂性的举证责任。

---

# 最终架构准则

这套 harness 可以压缩成六条不可违反的规则：

> **One loop：** 模型负责思考，Harness 不再造第二个大脑。
> **One journal：** 发生过的事实只有一个权威来源。
> **One projector：** Context 是从事实计算出的临时视图。
> **Four tools：** 用正交原语，而不是堆积 feature。
> **Stable prefix：** 一个 epoch 内只追加，不重写。
> **No guessing：** 副作用状态不确定时停下，不盲目恢复。

最核心的一句话是：

> **把 Reasonix 的聪明留在 DeepSeek 协议和 cache 层，把 Maka 的严谨留在事实与副作用边界，把 Pi 的克制贯彻到除此之外的一切。**

[1]: https://github.com/earendil-works/pi/tree/main/packages/coding-agent "pi/packages/coding-agent at main · earendil-works/pi · GitHub"
[2]: https://github.com/esengine/DeepSeek-Reasonix/tree/main-v2 "GitHub - esengine/DeepSeek-Reasonix: DeepSeek-native AI coding agent for your terminal. Engineered around prefix-cache stability — leave it running. · GitHub"
[3]: https://github.com/esengine/DeepSeek-Reasonix/blob/main-v2/internal/provider/openai/openai.go "DeepSeek-Reasonix/internal/provider/openai/openai.go at main-v2 · esengine/DeepSeek-Reasonix · GitHub"
[4]: https://github.com/esengine/DeepSeek-Reasonix/tree/main-v2/internal "DeepSeek-Reasonix/internal at main-v2 · esengine/DeepSeek-Reasonix · GitHub"
[5]: https://github.com/Maka-Agent/maka-agent/tree/main "GitHub - maka-agent/maka-agent: Maka — local-first AI desktop assistant · GitHub"
[6]: https://github.com/maka-agent/maka-agent/blob/main/docs/architecture/runtime-resume-architecture.md "maka-agent/docs/architecture/runtime-resume-architecture.md at main · maka-agent/maka-agent · GitHub"
[7]: https://github.com/maka-agent/maka-agent/blob/main/docs/architecture/runtime-core-architecture-draft.md "maka-agent/docs/architecture/runtime-core-architecture-draft.md at main · maka-agent/maka-agent · GitHub"
[8]: https://api-docs.deepseek.com/zh-cn/index.html?utm_source=chatgpt.com "首次调用 API | DeepSeek API Docs"
[9]: https://api-docs.deepseek.com/zh-cn/guides/kv_cache/ "上下文硬盘缓存 | DeepSeek API Docs"
[10]: https://api-docs.deepseek.com/zh-cn/guides/tool_calls/ "Tool Calls | DeepSeek API Docs"
[11]: https://api-docs.deepseek.com/zh-cn/api_samples/thinking_mode_api_example_streaming/ "thinking_mode_api_example_streaming | DeepSeek API Docs"
[12]: https://api-docs.deepseek.com/zh-cn/quick_start/rate_limit/?utm_source=chatgpt.com "限速与隔离 | DeepSeek API Docs"
[13]: https://api-docs.deepseek.com/zh-cn/api/create-chat-completion/ "Chat Completions API | DeepSeek API Docs"
