# SimpleDSH

SimpleDSH is a small, DeepSeek-native agent harness. The v0.1 candidate is
under active development and is not yet published.

## Bash execution boundary

`bash` runs directly as the current user and can access every file, secret,
process, command, and network resource that user can access. SimpleDSH v0.1
does not provide bash execution isolation.

File-tool path checks, the closed child environment, and process-group cleanup
are low-cost mistake and lifecycle measures. They are not a sandbox or a
security guarantee. If untrusted execution needs isolation, run the entire
`dsh` process inside a container, virtual machine, or independent Unix user
that you configure and manage.
