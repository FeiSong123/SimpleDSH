# Stage 11 — Extensibility Admission Closure

- **Status:** `BLOCKED`
- **Gate:** evidence-gated after Stage 08 and closure of any admitted Stage 09/10 lineage work
- **Depends on:** accepted Gate 2 baseline plus a real caller/failure for each independently considered slice
- **Lead:** unassigned
- **Baseline:** record when activated
- **Review:** required per slice; fresh read-only reviewer judges the actual evidence and admission conclusion
- **Write scope before admission:** this Plan, its `PLANS.md` row, and ordinary user-facing availability statements in `README.md`; caller/trace evidence is read-only

## Actual need

Close the initial extensibility stage without building an extension framework. The baseline has no extension directory, hook/registry, loader, transport, plugin API, related configuration, or feature test. Gate 2 considers each observed need independently; one admitted slice never authorizes another or a shared abstraction.

## Candidate evidence categories, not promised APIs

The bounded audit may encounter a Skill-like file workflow, command template, lifecycle callback, additional static tool, alternate local execution target, or remote tool source. These labels only route evidence. They do not predefine names, directories, schemas, transports, events, discovery, or runtime behavior.

For each encountered category, all conditions are required before implementation scope exists:

1. A named real caller and repeatable failure are preserved with original request, pre-fix tree or trace, outcome, and verifier.
2. Files, Shell, Git, the four baseline tools, visible Artifacts, or a direct one-off integration cannot solve it adequately.
3. The required input/effect/cache/recovery boundary is stated from evidence; no harness credential, hidden transcript/Memory, dynamic model routing, second Agent, scheduler, or background service is involved.
4. Evidence is credential-free, attributable to the frozen Gate 2 revision, and reproducible by the Lead.

## Bounded audit loop

```text
freeze Gate 2 revision
→ classify only observed callers/failures
→ test cheaper existing primitives per caller
→ fresh independent review per conclusion
→ admitted slice design revision OR README unavailable statement
→ Lead verifies package/code presence or absence
→ delete Plan/index row
```

## Closure A — admitted slice

Do not implement from a category label. First revise the Engineering Spec and this Plan with the single observed caller, exact input/schema/byte shape, lifecycle, Cache ABI and planned-break impact, Journal/Projector/Effect Gateway/permission/isolation/recovery behavior, exclusive source/test scope, deterministic fixtures, any authorized live budget, and exact validation commands. Obtain a fresh implementation-permitting verdict; only that slice may become `ACTIVE`. A generic substrate still requires two independent real callers and its own review.

Every future admitted slice remains bounded by Spec §13: journal inputs before projection; freeze provider-visible bytes; execute through validator/Gateway/policy/isolation/T1/T2; preserve raw Artifacts and bounded results; never write Journal/history/Snapshot directly, see credentials, mutate tools at runtime, route models, or keep hidden state/services.

## Closure B — non-admitted slice

Keep audit details in this Plan/Git history. Add only plain candidate-specific availability statements and falsifiable re-admission triggers to `README.md`; do not create a capability registry/protocol. Do not add `src/ext`, shared substrate, stub, loader, hook/registry, transport, CLI/config/schema, event, or feature-specific test script for an unavailable slice.

## Lead verification

| Evidence | Exact command | Expected |
|---|---|---|
| Baseline health | `npm run check` | exit 0 |
| Non-admitted claims | exact `rg` query frozen from the categories actually audited | each unavailable statement has one falsifiable trigger |
| Non-admitted package | `npm pack --dry-run` | exit 0; no unavailable extension substrate/entrypoint |
| Final release consistency | `npm run test:release` | deferred to Stage 12; then exit 0 and README/package agree |
| Admitted path | commands frozen in each reviewed replacement section | no implementation before review |

## No-go conditions

- A category lacks a real caller/failure, or evidence for one category is reused to authorize another.
- Implementation begins from a predesigned framework/API or creates dynamic tools, hidden state, provider routing, a second Agent, or a Gateway/credential bypass.
- Non-admitted categories remain indefinitely `BLOCKED`, ship placeholders, or are reported as capability PASS.

## Completion cleanup

Lead records revision, exact commands/exits, inspected evidence, rejected cheaper placements, per-slice verdict/cuts, and closure. Durable user-visible availability remains normal README release text; audit details remain in Git history. Rewrite downstream dependencies, then remove this Plan and its index row.
