# Stage 06 — Session Kernel

- **Status:** `BLOCKED`
- **Gate:** Gate 1 integration
- **Depends on:** Stage 04 Context/Lineage/Projector and Stage 05 Effect Gateway/Four Tools
- **Lead:** unassigned
- **Baseline:** record when activated
- **Review:** required because this stage fixes the single loop, concurrency order, cancellation, and commit semantics
- **Exclusive write scope:** `src/session/**`, minimal `src/cli/**`, integration fixtures, `test:session` wiring

## Actual need

The verified protocol, durable facts, deterministic context, and Effect Gateway need one mechanical coordinator. It must preserve order and lifecycle without becoming a planner, router, second agent, or hidden workflow state machine.

## Contract and invariant impact

- Charter: Single Loop, logical architecture, main execution loop, and Session/Run/Commit Boundary objects.
- Engineering Spec: invariants 2, 3, and 5; dependency rules; tool batching; M1 minimal loop.
- Protects one active Lineage, one writer, atomic assistant commit, exact tool pairing, ordered effects, and cancellation propagation.
- Expected metric impact: first runnable task loop; no pass@1/cache/latency claim until Stage 07 measures it.

## Smallest working loop

```text
durable user fact
→ safe user Commit Boundary
→ stored Request Snapshot
→ fake model response with one read call
→ Effect Gateway result
→ safe tool-result-batch Commit Boundary
→ second Snapshot
→ complete visible answer
→ final-assistant Commit Boundary
```

## In scope

- Session Kernel with exactly one active Run, active Lineage, and Journal writer.
- User input is durable before projection or network request.
- Immutable Snapshot selection and the sole official DeepSeek call through Stage 02; the Kernel cannot select endpoint/model/preset and accepts only the fixed Flash/thinking/max ABI.
- Streamed reasoning/text shown only as uncommitted preview.
- Complete assistant response committed in one atomic `assistant_committed` event with reasoning/tool calls, raw finish reason, verified usage, provider request id, attempt id, and Snapshot id; it is also the physical-attempt success terminal.
- Tool-call validation and dispatch only through Stage 05 Effect Gateway.
- One and only one matching tool result per call, committed in declared order.
- Consecutive proven-read-only calls may use the bounded batch interface; mutating calls remain serial.
- Commit Boundary is created immediately after each safe new user commit, complete ordered tool-result batch, and final no-tool assistant when protocol and all effects are closed or reconciled.
- Abort propagation to provider stream and active effect; a post-semantic-delta `request_interrupted` is journaled and the Run ends without transparent replay.
- Minimal non-interactive CLI path sufficient for offline integration fixtures.
- First outbound protocol E2E only through the complete durable path: one no-tool turn and one thinking/read/tool-result roundtrip on fixed Flash/max under the recorded 2026-08-04 authorization and this Plan's two-turn scope; no cache/task-quality claim.

## Non-goals

- No planner, goal/todo mode, Provider/router/SDK, Pro/high/other model or model switching, reflection loop, sub-agent, retry policy outside the Gateway, hidden background job manager, full TUI, recovery UX, cost dashboard, compaction, fork, or extension hooks.
- No second in-memory transcript treated as authority.
- No automatic repair that invents a missing tool result or effect outcome.

## Readiness gate

- [ ] Stage 04 Snapshot, boundary, ABI, and Lineage APIs pass review.
- [ ] Stage 02/04 evidence proves the only accepted request identity is official endpoint + Flash/thinking/max.
- [ ] Stage 05 Effect API and crash-state model pass review.
- [ ] Shared event schema versions/hashes match between both branches.
- [ ] The integration Lead has exclusive ownership of Session and CLI files.
- [ ] Fake Gateway and fake effect fixtures can drive all paths without live credentials.
- [x] User authorization and bounded live request scope/cost terms are recorded below; no live call occurs before every durable-before-send test passes.

## Live authorization — 2026-08-04

- **Authorized backend/request:** DeepSeek v4 Flash, `thinking={"type":"enabled"}`, `reasoning_effort=max`.
- **Cost terms:** no hard monetary cap; use the dated Flash unit prices recorded in `PLANS.md`. The Stage 06 scope is one no-tool turn and one thinking/read/tool-result roundtrip, plus only the protocol's already-bounded physical retries; record actual calls, native usage, and cost.
- **Forbidden:** Pro, `reasoning_effort=high`, any other model, provider, endpoint, SDK, or configurable routing path.
- **First-send prerequisite:** every durable-before-send test must pass before the first live request. The user fact and Request Snapshot must already be durable and Commit Boundary eligibility must be correct; a smoke request may not bypass persistence.

## Work packages

1. **Run state machine:** explicit states and allowed transitions, with no task-policy states.
2. **Input/request path:** durable user fact, projection, Snapshot lookup, sole `src/ds` invocation.
3. **Response path:** preview stream, atomic assistant/usage/attempt-success commit, canonical `request_interrupted` failure record.
4. **Tool path:** validate, batch read-only calls, serialize effects, order results, loop.
5. **Completion/cancel:** immediate user/tool-batch/final-assistant Commit Boundaries, final Run closure, and end-to-end AbortSignal.
6. **Minimal CLI:** start one task, render preview/final output, propagate exit reason.
7. **Integration fixtures:** scripted model/tool traces for success, error, cancel, and invalid closure.
8. **Durable live protocol:** after offline acceptance, run the two minimal official-endpoint E2E turns and retain redacted request/usage/cost evidence.

## Ownership and allowed parallelism

| Lane | Exclusive scope | May overlap |
|---|---|---|
| Lead | Run state machine, shared integration, Commit Boundary creation | none on shared flow |
| CLI worker | reserved minimal CLI files | after Kernel interface freeze |
| Fixture worker | fake Gateway/effect scenarios | Kernel implementation |
| Verification worker | read-only traces and cancellation checks | after patch freeze |

No Worker changes event schemas, serializer, tool registry, package scripts, or Effect semantics. Integration conflicts return to the Lead.

## Verification

| Evidence | Exact command | Expected result | Actual result |
|---|---|---|---|
| Full Session suite | `npm run test:session` | exit 0 | — |
| One-loop trace | `npm run test:session -- --test-name-pattern="single loop"` | only Context→Model→Tool→Result→Model→Output | — |
| Durable-before-send | `npm run test:session -- --test-name-pattern="durable user|snapshot before send"` | provider not invoked before both facts are durable | — |
| Fixed backend | `npm run test:session -- --test-name-pattern="backend|model override"` | only stored Flash/thinking/max Snapshot can be sent; overrides fail closed | — |
| Atomic assistant | `npm run test:session -- --test-name-pattern="atomic assistant|partial"` | preview never becomes committed half-blob | — |
| Tool closure/order | `npm run test:session -- --test-name-pattern="tool result|declared order"` | exactly one result per id, in order | — |
| Boundary timing | `npm run test:session -- --test-name-pattern="user boundary|tool batch boundary|final boundary"` | each of the three safe append points emits one boundary; pending calls/effects emit none | — |
| Effect ordering | `npm run test:session -- --test-name-pattern="read-only batch|mutating serial"` | bounded reads; writes/effects serial | — |
| Semantic interruption | `npm run test:session -- --test-name-pattern="semantic interruption"` | old Run ends, canonical `request_interrupted` exists, no same-Run transparent replay; §8.2 recovery alias remains legal | — |
| Cancellation | `npm run test:session -- --test-name-pattern="AbortSignal|cancel"` | stream/effect stop and state remains closed or explicit | — |
| Live protocol E2E | `DSH_LIVE=1 npm run test:live:protocol` | exit 0; durable Snapshot-before-send; no-tool + thinking/read roundtrip; fixed Flash/max; no 400; redacted cost evidence | — |
| Static checks | `npm run check` | exit 0; dependency direction and single-writer rules pass | — |

## Independent review

Use a fresh read-only reviewer when the state diagram and integration diff are concrete. Review the absence of policy intelligence, Commit Boundary eligibility, effect ordering, post-delta interruption, and cancellation. Record verdict and cuts.

- **Reviewer context/date:** —
- **Verdict:** —
- **Required cuts/evidence:** —

## No-go conditions

- Kernel decides task strategy, routes models, or owns a second plan/todo state.
- Kernel accepts Pro/high/model/endpoint override or contains a Provider selection branch.
- A request is sent before its user fact/Snapshot is durable.
- Preview bytes enter canonical history before complete response finalization.
- Direct tool/process execution bypasses Effect Gateway.
- A Cache Checkpoint is emitted as a Commit Boundary while effects are open.
- A retry after semantic output is hidden inside the Kernel.

## Handoff evidence

Return baseline, changed paths, state diagram, representative event traces, exact commands/exits, cancellation/process observations, reviewer verdict, open risks, and the stable recovery/observability inputs for Stage 07.

## Completion and cleanup

- [ ] All Actual result and review fields are filled.
- [ ] Fake loop and authorized minimal live loop reach valid Commit Boundaries with no orphan state.
- [ ] Durable behavior/state changes are in the Engineering Spec.
- [ ] Stage 07 is unblocked by exact event traces and commands.
- [ ] Remove this Plan and its index row after handoff.
