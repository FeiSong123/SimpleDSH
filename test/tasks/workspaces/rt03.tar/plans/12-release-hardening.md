# Stage 12 — Release Hardening

- **Status:** `BLOCKED`
- **Gate:** 发布门
- **Depends on:** 所有已经获准并进入 release scope 的阶段；09–11 若始终未获证据准入，不构成依赖
- **Review:** 条件性；若只做验证、文档和机械发布接线则不要求，若改变行为或引入抽象则必须 fresh independent review
- **Write scope:** 发布测试与 fixtures、package/release wiring、用户文档、能力矩阵、SBOM/provenance 产物；不得顺手实现新能力

## Actual need

SimpleDSH 在发布前需要证明的不是“可以打包”，而是固定范围内的协议、恢复、副作用与安全不变量在真实安装和固定官方 DeepSeek Flash/thinking/max 调用中仍成立。发布门还必须防止用更低 token 或更短时间掩盖 pass@1 或正确性退化。

## Contract references

- `AGENTS.md` 与 `PLANS.md`：North star、稳定验证入口、停止条件、精确证据、审查和清理。
- `dev/docs/architecture-charter.md` §1、§5–§10：主循环、恢复、安全、可观察性与指标优先级。
- `dev/docs/dsh-spec.md` §5、§11–§17：TypeScript 分发、供应链、验证计划和获准路线图。

## Smallest working loop

```text
冻结 release scope 与 revision
→ 从干净安装运行全部 offline gates
→ 运行恢复/effect/security 矩阵
→ 在明确授权范围与成本条款下以唯一官方 endpoint + Flash/thinking/max 运行 live protocol/cache/真实任务套件
→ 先判 pass@1，再判 uncached tokens，最后判 wall time
→ 在仓库外安装 tarball
→ 生成能力矩阵、SBOM、provenance、用户文档并做条件性 review
→ 等待用户明确发布授权
```

## Frozen release scope

- Scope 只包含进入本阶段前已经完成、验收并迁出 Plan 的阶段；冻结后不得加 feature。
- 09 compaction、10 fork、11 extensions 是 dormant evidence-gated 能力；未获准就明确标为 unavailable，不阻塞基础版发布。
- 固定 revision、Node/依赖、tool golden、Projector/protocol version、官方 endpoint、Flash/thinking/max、dated Flash price 和 suite；冻结后仅收 blocker。

## In scope

1. 全量 offline acceptance 与固定 `POST https://api.deepseek.com/chat/completions` + `deepseek-v4-flash` + thinking enabled + max 的 live protocol/cache/task acceptance。
2. crash/recovery、effect indeterminate、权限/路径、direct-child terminal/cleanup observation、自动 credential 路径与同用户 bash-access 诚实披露矩阵。
3. 固定真实任务 suite 的 pass@1、uncached input tokens/task、wall-clock 分开报告。
4. npm tarball 在仓库外的全新安装；Bun 仅在已安装且被声明支持时验证。
5. macOS、Linux、Windows 的 Tested/Supported/Degraded/Unsupported 能力矩阵；bash 在 macOS/Linux 只能是无外部 runtime 前置的 native 路径，Windows 只能是 unavailable，不得出现依赖外部隔离组件的条件性支持。
6. 用户文档明确声明 v0.1 无 bash 执行隔离，以及 `.env` ignore/non-symlink/0600/not-packed、closed child env、自动 credential 路径、lock/shrinkwrap、依赖棘轮、audit、SBOM、tarball hash 和 provenance。

## Non-goals

- 不为“版本完整”启用 09–11，不新增 Provider interface/registry/router/SDK、其他 provider/endpoint、`base_url`、Pro/high/模型切换/跨模型 fork、工具、模式、TUI feature 或自动优化。
- 不以一次 DeepSeek cache miss 判失败，也不把多血统指标汇总成一个伪精确分数。
- 不在本阶段直接 `npm publish`；外部发布必须由用户另行明确授权。

## Readiness

- 所有授权阶段都有 exact commands、exit codes、revision、evidence paths 和必要 verdict。
- Stage 07 已冻结真实任务 suite 与可比较 baseline；没有 baseline 就不能声称质量或效率改进。
- candidate 可归因且干净；live 授权/留存边界、`.env`/credential boundary，以及 package/version/license/files/engines/平台均已确定。
- Flash 官方价格已在发布日刷新并带日期；历史成本保持原核对日期，不静默重算。

## Work packages

1. **Scope freeze:** 生成 release manifest，列出 included、dormant、unsupported 与已知风险。
2. **Offline matrix:** 在 fresh install 上跑 check、acceptance、release 及所有已授权阶段测试。
3. **Correctness matrix:** kill/abort/torn-tail、prepared/effect/completed 各崩溃点、indeterminate reconcile、重复副作用防护、路径逃逸、非 TTY deny、PGID/setsid cleanup observation、closed child env、自动 credential redaction/non-flow 与非秘密 explicit-read marker；setsid fixture 必须短时自杀，不留人工清理进程。
4. **Live matrix:** 固定官方 endpoint、Flash/thinking/max、suite、次数和已授权成本条款，验证 reasoning、重试字节、usage、缓存分布、Flash 成本和任务结果。
5. **Package and evidence:** repo 外 npm/Bun smoke；生成 SBOM、依赖棘轮、audit、tarball hash、provenance、能力矩阵并核对文档。

## Metric decision order

1. 协议、恢复、副作用与安全不变量必须全部通过；任何失败直接阻断。
2. 在固定 suite 上先比较 pass@1；低于已批准 baseline 时阻断，不得用成本补偿。
3. 只有任务质量相等时比较 uncached input tokens/task，按固定 Flash + Lineage 分桶，并用 hit `$0.0028`、miss `$0.14`、output `$0.28` 每 1M tokens 的当日核对价。
4. 只有质量和 token 成本相等时比较 wall-clock；queue wait 单列，不冒充 harness 延迟。

## Allowed parallelism and ownership

- 可并行：不同平台的只读验证、文档核对、SBOM/audit、live 结果分析。
- 单 writer：version、lock/shrinkwrap、package allowlist、release workflow 与最终 manifest。
- Verification Worker 不修代码；失败回交拥有该模块的 Lead，修复后完整复跑受影响门。

## Planned validation commands

```bash
npm ci --ignore-scripts
npm run check
npm run test:acceptance
npm run test:release
DSH_LIVE=1 npm run test:live:protocol
DSH_LIVE=1 npm run test:live:cache
npm audit --omit=dev
npm audit signatures --omit=dev
npm sbom --sbom-format cyclonedx > release-sbom.cdx.json
RELEASE_SMOKE_DIR="$(mktemp -d)" npm run test:release
```

`npm run test:release` 必须在自己创建并校验所有权的临时目录中执行 `npm pack`、仓库外 `npm install --ignore-scripts <tarball>`、CLI smoke 和安全清理。若 Bun 被声明支持，它还必须在独立临时目录执行 Bun install/smoke；未安装 Bun 时记录 `NOT TESTED`，不得宣称支持。

## Acceptance evidence

| Evidence | Expected | Actual result |
|---|---|---|
| Frozen manifest | revision/scope/golden/version，并逐字记录 official endpoint、`deepseek-v4-flash`、thinking enabled、`reasoning_effort=max` | |
| Offline gates | `check`、`test:acceptance`、`test:release` 均 exit 0 | |
| Recovery/effect/security matrix | 全部确定性不变量通过，`indeterminate` 不盲重试 | |
| Live protocol/cache | 在授权范围与成本条款内完成；字节/usage 正确，命中率以分布报告 | |
| Fixed backend identity | provider/model/thinking/effort/base_url override 均被拒；Pro/high/switch/cross-model/SDK 不可达 | |
| Fixed task suite | pass@1 不退化；随后才报告 token 与 wall time | |
| External npm install | repo 外 fresh install 与 CLI smoke 通过 | |
| Optional Bun | 通过，或明确 `NOT TESTED/UNSUPPORTED` | |
| Capability matrix | 每个平台能力与降级均有实际证据或诚实标记 | |
| Supply chain | ratchet、audit、SBOM、tarball hash、provenance 齐全 | |
| Credential/bash boundary | `.env` ignored/not packed/non-symlink `0600`；仅 CredentialLoader 自动读取、key 仅瞬时进入 `src/ds` Authorization header 且 capture redact；closed child env 不自动继承 credential；自动 credential 路径不进入 Snapshot body/log/Context/child env/evidence；非秘密 marker 证明同用户 bash 可主动读取可访问文件且输出会普通持久化；live/release evidence 无真实 key；macOS/Linux 无 runtime 前置，Windows only unavailable | |
| Documentation | 安装、安全、恢复、成本、限制与实现一致 | |
| Conditional review | `N/A` 有理由，或 required verdict/cuts 已完成 | |

## Independent review

若 release diff 改变请求形状、工具 schema、Context、持久化、恢复、effect、permission/process boundary 或新增 durable abstraction，必须按 reviewer prompt 进行 fresh read-only review。纯测试、文档同步和机械打包接线记录 `N/A` 理由即可。

## No-go conditions

- 任一高优先级不变量失败、pass@1 退化、证据来自非冻结 revision，或 live 验证超出记录的请求范围/成本条款或无授权。
- 外部安装依赖仓库内未打包文件，依赖棘轮上升未解释，SBOM/provenance 缺失，或能力矩阵夸大平台支持。
- 为发布日期临时启用 dormant 能力、吞掉失败、弱化权限/credential 处理或诚实边界，或把单次 cache miss 当作确定性回归。
- 发现 Pro/high/模型切换/跨模型 fork、其他 provider/endpoint/SDK/base_url 路径；出现内建 bash isolation/runner backend，macOS/Linux 获得外部 runtime 前置或 unavailable 路径，或 Windows 尝试 native bash；工具 child env 自动继承 credential；自动 credential 路径或 release 测试把真实 `.env`/credential 值写入包、日志、Context、Request Snapshot body、工具环境、evidence 或 release artifact；Authorization capture 未 redact；或文档夸大同用户 bash 的秘密阻断/安全保证。

## Handoff

向用户交付 candidate revision、tarball/SHA-256、SBOM/provenance、命令/退出码、固定 Flash 请求与 dated price 证据、suite 三组指标、自动 credential non-flow/closed child-env/非秘密 explicit-access marker 证明、无 bash 隔离限制、live 成本、平台矩阵和 publish checklist。只有明确授权后才发布。

## Completion cleanup

把可复用发布流程提升到 `dev/docs/workflows/`，把用户契约留在正式文档；填满 Actual result 后删除本 Plan 及 `PLANS.md` 对应行，由 Git 历史和 release artifacts 保存执行证据。
