# Stage 05 — Effect Gateway and Four Tools

- **Status:** `ACTIVE`
- **Gate:** Gate 1 foundation
- **Depends on:** accepted Stage 03 Journal/Artifact durability and Stage 04 context contracts; shared schema/event wiring remains Lead-owned
- **Lead:** `/root`
- **Accepted dependency evidence:** Stage 03 implementation `3eec1ac896bb3ce26ab472c598f9e07b940cee0e`, acceptance revision `ae5e2e4`
- **Current integration base:** `441f888e4e66d487a15bd07b0f4b01483fe5e918`
- **Review:** required because this stage adds Core tools and changes side-effect, cancellation, process, recovery, and concurrency semantics
- **Exclusive code scope after the contract stop:** `src/proc/**`, `src/tool/**`, effect/event adapters, reserved effect fixtures, `test:effects` wiring, and only the shared schema/credential/package changes approved by the Lead

## Actual need

The model needs exactly four mechanical primitives—`read`, `write`, `edit`, and `bash`—without creating a second planner or an untracked side-effect path. Every T2 operation must be durably bracketed, raw results must remain recoverable as bounded Artifacts, and deterministic terminal states must survive replay.

The distributability requirement is now explicit: on a clean supported macOS or Linux host, after the normal SimpleDSH npm installation, `bash` must use `/bin/bash` immediately. It must not require the user to install, configure, pin, or keep running Lima, nerdctl, containerd, runc, RootlessKit, a VM, an image, a mount, or a capability probe.

## Direction decision — 2026-08-04

This decision supersedes the Linux-VM/container product direction previously developed in this Plan.

| Kind of statement | v0.1 contract | Meaning to the user |
|---|---|---|
| **We do not do this** | SimpleDSH deliberately provides no built-in bash execution isolation, optional exec backend, capability/admission system, runtime/image tuple, or `external-required` mode. | This is a product choice, not a missing host component the user can fix. Installing more tools must not unlock a hidden path. Reintroduction requires a new product contract and fresh review. |
| **We cannot do this** | A native bash running as the same Unix user cannot guarantee that secrets are unreadable, cannot contain adversarial `setsid`/double-fork escapees, and cannot turn PGID/EOF checks into a security proof. | The command still runs, but it has the current user's authority. `descendantsReaped=false` is an honest observation and a disclosed residual limitation, not an unavailable state. |

The abandoned Linux VM mechanism did pass bounded mechanism tests for a fixed tuple. It is abandoned **solely because it is not distributable**: correctness depended on four external runtime versions, an exact image digest, fixed mount/inode properties, and host setup. That evidence is neither false nor a reason to ship the mechanism. Future isolation work must start from a new product proposal; the old evidence cannot authorize a dormant backend or configuration switch.

### Contract-only stop — completed 2026-08-04

At this completed checkpoint, the Lead edited only:

- `dev/docs/architecture-charter.md`;
- `dev/docs/dsh-spec.md`;
- this Plan.

The Lead then stopped and delivered the diff. Production code, tests, `PLANS.md`, downstream Plans, the Lima instance, and `.stage05-admission-host/` remained untouched until the user gave the second explicit approval recorded below.

## Independent P1 — `output_limit` terminal XOR

This defect is independent of the execution-isolation direction and must remain described separately.

### Pre-change audit

- `src/artifact/terminal.ts` currently accepts `output_limit` with `exitCode=null, signal=null` because it checks `!neither && !exactlyOne` instead of strict `exactlyOne`.
- `test/effects/codec.test.ts` contains both an accepted helper case with the neither shape and an explicit `doesNotThrow` assertion for it.
- No repository-owned persisted `.json`/`.jsonl` Journal sample contains an `output_limit` terminal that requires migration. Repository Journal fixtures are TypeScript data and will be updated with the tests.

### Approved correction after the second approval

1. Make generic terminal normalization require strict exactly-one exit code or signal for `output_limit`, aligned with `timeout` and `cancelled`.
2. Keep `output_limit` bash-only. A non-process `read` that reaches the raw byte limit settles as `succeeded/ok` with `hardLimitReached=true`; it must not invent an exit status.
3. Update all neither fixtures and add legal exit-only and signal-only fixtures.
4. Add normalize/read, Journal append, and replay-mutation rejection for neither and both.
5. Record this as a P1 correctness fix, not as a consequence or benefit of removing isolation.

This correction preserves tool schemas, system prompt, request serializer, provider result field order, and projection budget. It necessarily changes the provider-visible **value** for the rare read-hard-limit result from `failed/output_limit` to `succeeded/ok`; that is the only known provider-result semantic delta required to make the user's generic strict-XOR instruction coherent. It must be disclosed and reviewed rather than described as byte-identical behavior.

## Durable contracts that do not change

- Exactly four hand-written, byte-stable tool schemas in the existing order; no schema generator or fifth Core tool.
- No system-prompt, tool-schema, request-serializer, Cache ABI, or provider-result field-order change.
- One `ToolRuntime`/Effect Gateway; `read` is T1, while `write`, `edit`, and every `bash` are T2. Bash command text is never classified as pure.
- T2 order remains `effect_prepared` durable → external effect → raw Artifact durable → `effect_completed` durable → `tool_result_committed`.
- A durable prepared event without completed/reconciled remains `indeterminate`, stops the Run, and is never blindly retried.
- Raw tool output remains `application/vnd.simpledsh.tool-output.v1`, byte-exact, content-addressed, capped at 16,777,216 payload bytes, and projected to at most 32,768 fully escaped provider bytes.
- Read batching remains bounded at four and results remain committed in declared order. T2 calls remain serial.
- File-tool canonical `.env`/protected `.dsh` denies, scalar/NUL validation, same-directory atomic write/edit publication, crash matrix, and explicit metadata-preservation limits remain in force as deterministic mistake guards.
- Startup `.env` hygiene remains: Git ignored, non-symlink regular file, mode `0600`, read once with `O_NOFOLLOW`; it is not a bash admission or per-launch inode check.
- The bash child environment is built from the closed seven-name allowlist `HOME|HOSTNAME|LANG|LC_ALL|LOGNAME|PATH|USER`; no parent variable is inherited automatically.
- `BashRunReason` remains the closed runtime set `natural|timeout|cancelled|output_limit|io_error` and maps to one durable terminal classification.
- Artifact publication, Journal fsync ordering, validator/schema closure, recovery, range reads, and output framing remain single sources of truth.

## New native bash contract

On every non-Windows platform, the one production path is:

```text
/bin/bash --noprofile --norc -lc <command>
detached PGID + stdin closed + stdout/stderr pipes + closed child env
natural | timeout | cancelled | output_limit | io_error
stop when needed: TERM -> bounded grace -> KILL(original PGID)
bounded direct-child close + negative-PGID probe + double-EOF observation
```

Windows is the only platform-unavailable branch and uses the already frozen legacy unavailable code so no new provider-result vocabulary is introduced. Non-Windows spawn failure is `io_error`, not admission failure.

For every bash that entered the runner:

- a failed spawn records `io_error,null/null,descendantsReaped=true`; otherwise the direct-child terminal is recorded exactly;
- `timeout|cancelled|output_limit` requires strict XOR of `exitCode` and `signal`;
- after a successful spawn, `descendantsReaped` is `true` only when the original PGID is absent and both stdout/stderr EOF were observed inside the cleanup window;
- the same boolean is written to tool-output Artifact metadata and `effect_completed.terminal` and verified equal on replay;
- the boolean is not projected into provider-visible tool-result content;
- `false` still produces `effect_completed` and a deterministic tool result and never produces `effect_indeterminate` by itself.

This observation cannot detect a detached process that changed session/group and closed inherited pipes. README and doctor must say that bash runs with the current user's full accessible authority, including access to secret files and parent-visible resources. File path checks, closed child env, and PGID cleanup are mistake/lifecycle measures only.

## Smallest working loop

```text
complete assistant tool_calls
-> validate all calls
-> execute consecutive read-only calls in a bounded batch
-> for each write/edit/bash: durable prepared -> native effect
-> durably publish consumed raw output and cleanup observation
-> durable completed with the one terminal classification
-> emit one bounded result projection per call in declared order
```

Crash truth remains separate from cleanup truth:

| Durable facts | Recovery truth |
|---|---|
| no `effect_prepared` | not executed by the Gateway |
| prepared, no completed/reconciled | `indeterminate`; stop and do not retry |
| prepared + completed, `descendantsReaped=true|false` | settled terminal attempt; replay exactly; no indeterminate |

## In scope

- Remove the production Lima/container runner, topology inspection, admitted-runner brands, capability objects, runtime version/image/mount/inode checks, and doctor admission tri-state.
- Implement the one native non-Windows runner and the Windows-only unavailable branch.
- Preserve child-env construction, TERM→KILL, byte backpressure, hard limit, Artifact publication, terminal classification, and ordered Gateway semantics.
- Add `descendantsReaped` to durable Artifact/Effect metadata without adding it to provider projection.
- Apply the independent `output_limit` strict-XOR correction and its replay tests.
- Replace old container product tests with real native macOS/Linux-shaped tests, a no-Lima test, and honest setsid-escape observation.
- Align `PLANS.md` and downstream Stage 07/08/12 wording with this boundary before code implementation; this shared alignment was authorized with the contract diff and is part of the same change.

## Non-goals

- No sandbox, jail, VM/container runner, optional exec backend, capability registry, admission protocol, runtime/image discovery, or `external-required` state.
- No claim that child-env omission prevents a hostile command from reading files or inspecting processes.
- No attempt to chase or kill escaped processes outside the original PGID.
- No provider schema/system/request redesign, planner, router, search/glob/ls/multi-edit tool, MCP, background process manager, or parallel writer.
- No automatic reconcile, idempotency retry, exactly-once claim, rollback fiction, or post-hoc secret filtering.
- No paid live Provider call is required for Stage 05; offline and local process evidence is sufficient.

## Readiness

- [x] Stage 03 durability order and crash truth are accepted.
- [x] Stage 02 freezes four provider-visible schemas and request bytes.
- [x] Stage 01 provides Node >= 22, dependency/lifecycle checks, and startup `.env` hygiene.
- [x] The user approved the Charter/Spec/Plan direction edit and required the contract-diff stop.
- [x] The user approved the delivered contract diff on 2026-08-04 and authorized production/test work through Stage 12 within the recorded stop conditions.

## Work packages and stop gates

### C0 — Contract convergence and second stop (completed 2026-08-04)

1. Amend Charter, Spec, and this Plan only.
2. Audit the diff for stale Shield/admission/container promises and internal contradictions.
3. Run the exact contract validation commands below.
4. Stop and deliver the diff, the output-limit fixture audit, and the “do not do / cannot do” distinction.

### C1 — Shared contract alignment after approval (Lead only)

1. [x] Align `PLANS.md` and downstream Stage 07/08/12 references before implementing against the new boundary.
2. [x] Freeze the durable `descendantsReaped` field placement and migration of all in-repo TypeScript fixtures.
3. [x] Freeze the Windows-only legacy unavailable mapping and the read-hard-limit P1 consequence.

### C2 — Native process implementation

1. Delete production admission/backend/capability/topology code and imports.
2. Implement one native non-Windows `/bin/bash` runner with detached PGID, closed env, bounded stdio, AbortSignal, timeout, and TERM→KILL.
3. Bound direct-child wait, negative-PGID probe, and dual-EOF observation; return terminal plus boolean without an unbounded wait.
4. Do not add a second runner, plugin seam, config switch, dependency, or host command probe.

### C3 — Durable wiring and independent P1

1. Store/verify `descendantsReaped` in Artifact metadata and Effect terminal; omit it from provider content.
2. Change `output_limit` to strict exactly-one, update read-limit classification, fixtures, append/replay validators, and recovery reconstruction.
3. Keep prepared-without-completed crash behavior unchanged; ensure false cleanup observation is never translated to indeterminate.

### C4 — Focused tests

1. Preserve codec/framing/projection, order, file atomicity, crash matrix, child-env and output-budget coverage.
2. Replace container product tests with native natural/nonzero/signal/timeout/cancel/output-limit flows.
3. Add no-Lima execution and source/package dependency scans.
4. Add the self-expiring setsid-equivalent escape fixture below.

### C5 — Lead verification

Run every applicable command, record exact exit/count/duration/RSS/hash evidence, and investigate every failure. A prior 15-second effects pass is only a baseline, not acceptance of the new implementation.

### C6 — Fresh independent implementation review

Use a fresh independent Codex context, read `dev/docs/pi-style-reviewer-system-prompt.md` completely, remain read-only, and inspect the actual need, new contracts, diff, crash truth, native process limitations, P1, provider-byte boundary, no-host-dependency evidence, tests, and exact Lead validation. Apply every P0/P1 cut and re-review only under `AGENTS.md` rules.

The first fresh implementation review completed on 2026-08-04 with direction
`KEEP`, implementation `REWORK`, and verification `FAILED`; it found no P0 and
four P1 cuts:

1. replace the callback output pump whose queued bytes could be discarded or
   delayed indefinitely with a deterministic, byte-bounded local capture that
   drains both pipes to EOF, gives `output_limit` precedence once the exact cap
   is observed, and cannot write after completion;
2. enforce one source-aware terminal validator for Artifact/pre-effect and
   Effect/post-effect phases, including append, reopen, prefix validation, and
   recovery reconstruction;
3. once `effect_prepared` is durable, an already-aborted signal must still enter
   the real spawn path and settle as the observed cancelled process outcome (or
   `io_error` on spawn failure), never as an unexecuted synthetic terminal;
4. remove the public whole-Artifact read API and make file reads use one verified
   streaming scan instead of rehashing the entire Artifact for every range.

The selected output design owns at most 16,777,216 bytes in the native runner,
coalesces records to at most 65,536 bytes while preserving stdout/stderr event
order, starts TERM→KILL when the exact limit is reached, and continues draining
and discarding until EOF. `ToolRuntime` durably publishes those frozen records
only after the process result is complete. This bounded ownership is deliberate:
process lifecycle can no longer depend on an arbitrary async consumer, while
the existing raw Artifact and 32,768-byte provider projection remain unchanged.
The requested adversarial race tests, full source/phase matrix, sanitized-path
ToolRuntime E2E, TERM-ignoring SIGKILL fixture, single-pass scan evidence, and
peak-RSS measurement are required before the second fresh review.

### C7 — Rollback assets and final cleanup

Keep the named Lima instance `simpledsh-stage05-admission` and `.stage05-admission-host/` unchanged through contract work, code work, no-Lima verification, full Lead verification, and reviewer cut closure. The instance config SHA is `a97fdae50a89e2271bc783d4650a166d84d188afd2b60bbcc3b8ec9175099394`; rebuilding it is not assumed reproducible.

Only after all prior gates pass:

1. read-only confirm that no other task or user process uses the named instance or scratch directory;
2. explicitly stop/delete only `simpledsh-stage05-admission` and remove only `.stage05-admission-host/`;
3. verify both are absent;
4. rerun the no-Lima runtime test, production-source/package scan, effects suite, and package inventory;
5. move durable conclusions to formal docs, then remove this Plan and its `PLANS.md` row last.

No test or code path may delete these rollback assets earlier.

## Setsid-escape fixture ownership and cleanup

The escape fixture must own its lifetime. On Linux it may use `setsid sh -c 'sleep 3; exit 0'`; the portable macOS equivalent may use the current absolute Node executable to spawn `/bin/sh -c 'sleep 3; exit 0'` with `{detached:true, stdio:['ignore','inherit','inherit']}` and `unref()`.

- The cleanup observation window is shorter than the three-second self-expiry.
- The only semantic assertions are `descendantsReaped=false`, durable `effect_completed`, no `effect_indeterminate`, and replay stability.
- The test must not retain a PID for teardown, call `kill`, or require manual cleanup.
- It may passively wait through the fixed self-expiry before the test process exits; that wait is hygiene, not the correctness mechanism.
- The fixture cannot loop, daemonize indefinitely, or depend on CI cleanup.

## No-Lima distributability gate

The gate runs while the real rollback Lima instance still exists, so success cannot be inferred from its absence.

1. Launch the built test entry with an absolute Node path and a temporary `PATH` containing no `limactl`, `nerdctl`, `containerd`, `runc`, or `rootlesskit`.
2. Through the real `ToolRuntime`, execute native bash in a temporary workspace, observe stdout/stderr, write a file, and replay its settled effect.
3. Assert the runtime never resolves or spawns any of the five forbidden tools and never returns `external-required`/capability status.
4. Scan production `src/**`, `package.json`, lock/shrinkwrap, and packed inventory for runtime/backend imports, commands, dependencies, images, and admission assets. Test text may name forbidden strings only to enforce their absence.
5. Stage 12 separately performs the final `npm pack` → isolated global install → clean-workspace CLI chain; Stage 05 must not claim that release gate before the CLI exists.

## Superseded review/evidence lineage

The detailed G0–G6/PG0–PG2 tuple transcripts are not current acceptance evidence. Because those Plan additions were uncommitted when this direction changed, this compact lineage remains here rather than falsely claiming Git history already archived the full text.

| Fresh reviewer context | Old verdict | Current status |
|---|---|---|
| `019fc983-ca6f-75a2-bcdd-b2524a32f9ec` | `NEED EVIDENCE` | superseded; reviewed the abandoned Linux-supervisor direction |
| `019fca07-8667-72f1-9fdc-f028e2fcc29b` | `NEED EVIDENCE` | superseded; required product-shaped external-runner evidence |
| `019fcab1-8d9f-71e3-a805-567789b5c57b` | `NEED EVIDENCE`, verification failed | superseded; required the old tuple's Cut 10 |
| `019fcaca-e311-7603-ac18-bba0d841c89c` | Direction `KEEP`, verification passed | superseded; authorized only the old fixed VM/container design, not native implementation |

The old mechanism evidence is retained temporarily in `.stage05-admission-host/`, the named Lima instance, and the root transcript `/Users/oye/.codex/sessions/2026/08/03/rollout-2026-08-03T22-37-29-019fc80e-ed0c-7671-af1c-8c22fe9edffb.jsonl`. It proves neither distributability nor the new direction and cannot mint a v0.1 capability.

## Validation ledger

### Contract checkpoint

| Evidence | Exact command | Expected | Actual |
|---|---|---|---|
| Modified-file scope | `git diff --name-only -- dev/docs/architecture-charter.md dev/docs/dsh-spec.md plans/05-effect-gateway-four-tools.md` | exactly the three approved paths | exit 0; exactly those three paths |
| Patch hygiene | `git diff --check -- dev/docs/architecture-charter.md dev/docs/dsh-spec.md plans/05-effect-gateway-four-tools.md` | exit 0 | exit 0; no output |
| Stale-contract scan | `rg -n -i -e '必须.*credential shield' -e '必须.*descendant supervisor' -e 'bash.*external-required' -e 'sandbox\.bash' -e 'phase 1.*bash enforcement' -e seatbelt -e bubblewrap -e landlock -e 'admitted bash runner' dev/docs/architecture-charter.md dev/docs/dsh-spec.md` | only explicit abandoned/forbidden/legacy statements | exit 0; two matches, both explicit “not provided/no matrix” statements; no active promise |
| `output_limit` fixture audit | `rg -n -e 'terminal\("failed", "output_limit"\)' -e 'normalizeToolTerminal\(terminal\("failed", "output_limit", null, null\)\)' test/effects/codec.test.ts` | identify every known neither fixture | exit 0; lines 117 and 213 |
| Persisted Journal sample audit | `rg -n 'output_limit' . --glob '*.json' --glob '*.jsonl' --glob '!node_modules/**' --glob '!dist/**' --glob '!.git/**' --glob '!.stage05-admission-host/**'` | no match | exit 1; no output; searched repository JSON/JSONL files are `npm-shrinkwrap.json`, `package.json`, and `tsconfig.json` |
| Rollback assets retained | `test -d .stage05-admission-host && limactl list simpledsh-stage05-admission --json >/dev/null` | exit 0 | exit 0; scratch and named instance remain |

### Shared alignment checkpoint after approval

| Evidence | Exact command | Expected | Actual |
|---|---|---|---|
| Shared-contract patch hygiene | `git diff --check -- PLANS.md dev/docs/architecture-charter.md dev/docs/dsh-spec.md plans/05-effect-gateway-four-tools.md plans/06-session-kernel.md plans/07-recovery-observability-gate1.md plans/08-permissions-isolation-supply-chain.md plans/12-release-hardening.md` | exit 0 | exit 0; no output |
| Downstream stale active-promise scan | `rg -n -i -e 'Credential Shield' -e 'descendant supervisor' -e 'src/sandbox' -e 'external-required' -e 'admitted bash' -e 'bash admission' PLANS.md plans/06-session-kernel.md plans/07-recovery-observability-gate1.md plans/08-permissions-isolation-supply-chain.md plans/12-release-hardening.md` | exit 1; no matches | exit 1; no output |
| Stage 08 retained-scope scan | `rg -n -e 'decide\(' -e 'deny > ask > allow > fallback' -e 'Non-TTY' -e 'shell-control' -e 'fs\.realpath' -e 'path-component' -e 'supply' -e 'doctor' plans/08-permissions-isolation-supply-chain.md` | exit 0; Policy, precedence, non-TTY, prefix, component path, supply, and doctor clauses present | exit 0; every retained clause matched |

### Pre-direction implementation baseline — not acceptance

| Exact command | Recorded result |
|---|---|
| `npm run check` | exit 0; dependency count 4; lifecycle-script count 0 |
| `npm run test:protocol` | exit 0; 70 tests |
| `npm run test:journal` | exit 0; 46 tests |
| `npm run test:context` | exit 0; 59 tests |
| `npm run test:effects` | exit 0; 76 tests; approximately 15 seconds, down from the obsolete 187-second baseline |

These results were obtained before the native-direction code change. Test speed is no longer a reason to retain or reject the abandoned mechanism.

### Post-implementation commands

| Evidence | Exact command | Required result | Actual |
|---|---|---|---|
| Runtime | `/opt/homebrew/bin/node --version` | supported Node >= 22 | exit 0; `v26.0.0` |
| Reproducible install | `npm ci --ignore-scripts` | exit 0; no lifecycle scripts | exit 0; added 4/audited 5 packages; 0 vulnerabilities; no install scripts ran |
| Static/dependency/ABI | `npm run check` | exit 0; four schemas; dependency budget unchanged | exit 0; dependencies 4; lifecycle scripts 0 |
| Protocol | `npm run test:protocol` | exit 0 | exit 0; 71/71; 2967.042667 ms |
| Persistence/replay | `npm run test:journal` | exit 0; new durable field and P1 mutations enforced | exit 0; 48/48; 4851.56575 ms |
| Context/projection | `npm run test:context` | exit 0; provider key order/budget unchanged | exit 0; 63/63; 1894.765208 ms; 23 legal tool/source/phase combinations plus 16 invalid boundary cases |
| Effects/native process | `npm run test:effects` | exit 0; exact count/time/RSS recorded | exit 0; 81/81; 11637.809083 ms; exact-limit Artifact `sha256:5b3a8600b4196b8b8da72aa41bc9fa887a7a6a7c33bf1f4b6ac64f7c3b6c9db4`; payload 16,777,216; Artifact bytes 16,778,758; provider bytes 32,768; RSS 143,818,752 -> 172,392,448 (delta 28,573,696) |
| Sanitized no-Lima E2E | `env SIMPLEDSH_TEST_SANITIZED_PATH=1 /opt/homebrew/bin/node --test --test-concurrency=1 dist/test/effects/no-lima-native-bash.test.js` | exit 0; real bash/write/replay with forbidden tools unresolvable | exit 0; 1/1; 592.828417 ms; child `PATH` was an empty directory |
| Native Linux process evidence | `limactl shell simpledsh-stage05-admission -- /bin/sh -lc 'set -eu; cd /tmp/simpledsh-stage05-native-linux; ./node-v26.0.0-linux-arm64/bin/node --version; ./node-v26.0.0-linux-arm64/bin/node --test --test-concurrency=1 dist/test/effects/native-bash.test.js dist/test/effects/no-lima-native-bash.test.js'` | exit 0; same built native path on an actual Linux kernel, without any container CLI | exit 0; official Node `v26.0.0` Linux arm64 archive SHA256 `f0f94e55142149a4d34634dc3d7e103921d898512dd0cef995ecb62c5ebd3f29`; Linux `7.0.0-28-generic` aarch64; GNU bash 5.3.9; 16/16; 7277.940101 ms; no nerdctl/containerd/runc/rootlesskit invocation; exact `/tmp` payload removed after the run |
| Production dependency scan | `rg -n -i -e limactl -e nerdctl -e containerd -e '\brunc\b' -e rootlesskit -e admittedbash -e credentialshieldcapability -e descendantsupervisorcapability -e 'alpine@sha256' src package.json npm-shrinkwrap.json` | exit 1, no matches | exit 1; no output |
| Frozen request/ABI paths | `git diff --exit-code df192de -- src/bytes/system.ts src/bytes/schemas.ts src/bytes/request.ts src/lineage/cache-abi.ts` | exit 0 | exit 0; no output |
| Package inventory | `npm pack --dry-run --json` | exit 0; no `.env`, key, Lima/admission asset, test scratch, or undeclared runtime dependency | exit 0; 61 entries; 148,873 packed bytes; 593,681 unpacked bytes; shasum `1cf7fd7240bcb7836f85ba3f5b7e2b7f492677d3`; forbidden-path follow-up count 0 |
| Patch hygiene | `git diff --check` | exit 0 | exit 0; no output |

The Lead records exact exits, test counts, duration, peak/RSS delta where applicable, Artifact hashes, and failure attribution in this Plan before handoff.

## Acceptance evidence

- [x] On macOS and Linux, real bash works through the same native path without Lima/container/runtime/version/image/mount/inode prerequisites or `external-required`.
- [x] Windows is the only platform-unavailable branch; its legacy code does not imply a supervisor probe.
- [x] Crash injection preserves the three-row truth table and never re-executes prepared-without-completed.
- [x] A self-expiring setsid-equivalent escape records `descendantsReaped=false` in both durable locations, completes the Effect, produces no indeterminate, and replays identically.
- [x] Natural, timeout, cancellation, output-limit, nonzero and signal paths record one terminal; bash `timeout|cancelled|output_limit` has strict XOR exit/signal.
- [x] Generic neither/both `output_limit` terminals fail normalization, Journal append, and replay; no persisted sample is silently stranded.
- [x] Read hard limit is coherently `succeeded/ok + hardLimitReached=true` without a fake exit status; its disclosed provider-result semantic delta is reviewed.
- [x] `bash("yes")` stops at exactly 16,777,216 payload bytes, preserves exact partial Artifact bytes/hash, keeps RSS bounded, and sends only the bounded projection.
- [x] Child env contains only the seven-name allowlist and does not automatically inherit the API key; tests and docs do not claim this blocks active secret reads.
- [x] Synthetic non-secret marker tests prove bash can access current-user files and that documentation states this boundary; no test reads or emits the real `.env`/key.
- [x] File atomicity, mechanical denies, ordering, range reads, codec, projection, durability and recovery tests remain green.
- [x] System prompt, four tool schemas/order, request serializer, Cache ABI, projection field order and limits remain unchanged.
- [x] Production source/package has no Lima/container/admission/capability path, dependency, image, asset, or future config.
- [ ] Fresh independent implementation review has zero unresolved P0/P1 cuts, followed by a full Lead rerun.
- [ ] Rollback assets are deleted only at C7 and post-delete no-Lima/package/effects verification passes.

## Actual result — implementation checkpoint before second review

The native effect gateway now has exactly one non-Windows `/bin/bash` path and
the frozen Windows unavailable result. The runner owns one bounded output
capture, drains both pipes through direct-child completion, gives an observed
exact output limit precedence over timeout/cancellation races, and publishes no
bytes after completion. An abort arriving after durable prepare enters the real
spawn path and is settled as the observed process outcome; the crash gap remains
fail-closed.

Artifact and Effect terminals now pass through one pure source-aware validator
at append, reopen, prefix, reconstruction, and projection boundaries. The
independent `output_limit` defect is fixed as strict XOR, while a file read that
reaches the raw limit remains a non-process `succeeded/ok` result with
`hardLimitReached=true`. The public read-all Artifact API was removed; Artifact
backed file reads make one verified streaming scan.

The first reviewer cuts are implemented and the Lead evidence above is green on
macOS and on an actual Linux kernel. A synthetic mode-0600 file outside the
workspace confirms the same-user authority limitation without reading any real
secret. This checkpoint is not Stage completion: the second fresh independent
verdict, post-verdict full rerun, and C7 rollback-asset deletion/rerun remain
outstanding.

## Independent review

The new implementation review is not satisfied by any reviewer in the superseded table. A fresh read-only reviewer must completely read the governing reviewer prompt and judge:

- whether the product truly needs no host prerequisite;
- whether the code has exactly one non-Windows native path and one Windows unavailable branch;
- whether crash uncertainty remains fail-closed while cleanup uncertainty is only an observation;
- whether `descendantsReaped` is durably bound without leaking into provider projection;
- whether same-user secret/process/setsid limitations are stated without security theater;
- whether the independent output-limit P1 and read-limit consequence are coherent;
- whether no-Lima, side-effect, replay, install/package and cleanup evidence is sufficient and reproducible.

`KEEP` permits handoff only after all required tests pass. `ACCEPT AFTER CUTS` requires every cut. `NEED EVIDENCE` permits only its smallest experiment. `REWORK`/`REJECT` requires revision or explicit user direction.

## No-go conditions

- Any macOS/Linux path returns `external-required` or requires a host runtime, VM, image, mount, version tuple, capability, or manual setup.
- Production retains an optional/dormant Lima/container backend, admission probe, capability registry, doctor tri-state, or future config.
- Docs or UI call file guards, closed env, PGID cleanup, negative group checks, or dual EOF a sandbox/security guarantee.
- `descendantsReaped=false` creates indeterminate, suppresses completed, or triggers blind retry.
- A prepared effect without completed/reconciled is treated as safe because a process is not currently visible.
- `output_limit` accepts neither/both exit/signal, or read fabricates an exit status.
- Provider schema/system/request/field-order bytes drift without a separate Cache ABI decision and review.
- Raw evidence is truncated without an Artifact, result order changes, output/RSS becomes unbounded, or a fifth tool appears.
- Any command/test reads, prints, commits, packs, or persists the real `.env` or API key.
- Lima or `.stage05-admission-host/` is deleted before C7, or deletion targets anything broader than the named assets.
- A paid live call, push, publish, or budget expansion occurs without the applicable authorization.

## Handoff evidence

Return the integration revision, dirty-state attribution, exact changed paths, durable schema/version impact, provider-byte impact, commands with exits/counts/durations/RSS, Artifact hashes, crash matrix, no-Lima/install/package evidence, reviewer verdict/cuts, deleted rollback assets, and the disclosed same-user/setsid/Windows limits.

## Completion and cleanup

- [ ] Fill every Actual result and evidence locator; no unexplained TODO/BLOCKED/PASS remains.
- [ ] Move durable semantics into Charter/Spec and user-facing boundary into README/doctor/release notes.
- [ ] Align downstream Plans/index under the new product contract.
- [ ] Complete C7 deletion and post-delete reruns.
- [ ] Remove this Plan and its `PLANS.md` row only after accepted handoff; Git history then becomes the execution archive.
