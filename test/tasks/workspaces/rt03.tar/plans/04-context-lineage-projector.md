# Stage 04 — Context, Lineage, and Deterministic Projector

- **Status:** `ACTIVE`
- **Gate:** Gate 1 foundation
- **Depends on:** Stage 03 Journal and Artifacts
- **Lead:** `/root`
- **Baseline:** `ae5e2e4` (accepted Stage 03 evidence; implementation `3eec1ac`)
- **Review:** required because this stage changes context projection, cache lineage, and provider-visible request identity
- **Exclusive write scope:** `src/ctx/**`, `src/lineage/**`, Snapshot projection/persistence integration, context fixtures, `test:context` wiring

## Actual need

Journal facts are not model context. SimpleDSH needs one versioned pure projection that deterministically turns a selected append-only Lineage into the exact immutable request bytes sent to DeepSeek, while keeping cache identity separate from branch identity and safety boundaries separate from DeepSeek cache checkpoints.

## Contract and invariant impact

- Charter: Deterministic Projector, Cache Lineage ABI, core objects, Context/cache lifecycle.
- Engineering Spec: invariants 1 and 4; §3; §7.2–§7.3; §8; §9; golden-hash and byte-roundtrip cases 8–9.
- Protects cache ABI, append-only prefix, deterministic recovery, explicit external facts, and safe future recovery/fork semantics.
- Expected metric impact: deterministic cache eligibility and zero unplanned byte drift; no live hit-rate promise.

## Smallest working loop

```text
durable user + environment facts
→ select Lineage head
→ pure Projector(version)
→ persist full immutable Request Snapshot
→ restart process
→ reproduce exactly the same request bytes and hash
```

## In scope

- Separate identities and types for `CacheAbiId`, `LineageId`, `RunId`, `RequestSnapshotId`, `CacheCheckpointId`, and `CommitBoundaryId`.
- Cache ABI records the fixed `deepseek-v4-flash` + thinking enabled + `reasoning_effort=max` request identity, protocol/Projector versions, system/project instructions, tool definitions, and tool order. Model/preset variation is not a supported ABI mutation; it is rejected before Lineage creation.
- Cache ABI and Lineage remain distinct branded identities; v0.1 exposes only initial/ABI-change activation and no same-ABI child/branch creation API.
- Frozen Header plus append-only Tail representation with chain-hash validation.
- Pure, versioned Projector over an exact verified Journal prefix ending at the selected Commit Boundary, immutable Artifact reads supplied as inputs, and active Lineage; no hidden time/cwd/Git/env/network reads and no API-key/`.env` credential input.
- Baseline date/cwd/Git environment observations become explicit durable facts before projection; no extension-input slot exists before Stage 11 admission.
- Full model-visible Request Snapshot body bytes, not only `messages`; the body is persisted before send and reused by identity for retries, while Authorization is attached later by `src/ds`.
- Cache Checkpoint is a performance fact; Commit Boundary requires protocol closure and all effects completed or explicitly reconciled. The types are not interchangeable.
- ABI mutation matrix for supported components plus negative fixtures proving Pro/high/model/effort/endpoint overrides cannot create a Lineage; prefix diagnostics remain disposable.
- Exact canonical user/tool serializers and validators before either role blob can enter a Snapshot; tool validation binds the embedded `tool_call_id` to the Journal payload.
- Integrity checks for orphan tool results, missing reasoning state, sequence/hash gaps, unsafe boundary assertions, and unexpected cache breaks.

## Non-goals

- No tool execution or Effect execution state machine; Stage 04 only reconstructs disposable protocol/effect closure state from durable facts. No Session loop, recovery policy, compaction, fork, dynamic tool changes, Memory retrieval, or live cache optimization.
- No request-time repository scan or environment injection.
- No reserialization of frozen history and no mutation of an existing Snapshot.

## Readiness gate

- [x] Stage 03 accepted implementation `3eec1ac896bb3ce26ab472c598f9e07b940cee0e` passes `npm run test:journal` on Node 22/26 (45/45 each); accepted evidence is `ae5e2e4`, and canonical Spec SHA-256 is `77070cb66acfae15455ef6a192330ef285132f291c40ed835701e4bc57cdb867`.
- [x] Stage 00 has made all Cache ABI components normative.
- [x] Stage 02 exposes an exact-byte serializer that accepts frozen inputs without owning projection policy.
- [x] Commit Boundary prerequisites are defined even though Stage 05 will supply effect facts.
- [x] `/root` is the sole Lead for shared identity/event changes.

## Work packages

1. **Identity model:** distinct branded ids, fixed Flash/thinking/max length-delimited ABI manifest/hash, independent Lineage identity and active head.
2. **Append-only prefix:** frozen header/tail chain, integrity checks, prefix diff.
3. **Fact admission:** typed external-state facts written before they can enter context.
4. **Projector:** pure versioned function and bounded Artifact projection inputs.
5. **Snapshot:** complete request bytes, hash, provenance, durability and lookup by id.
6. **Boundaries:** distinct cache/commit records and type-level misuse tests.
7. **Mutation/purity fixtures:** cross-process determinism, supported ABI changes, and rejection of backend/model/preset overrides.

`segmentHashes` is now frozen rather than removed: v1 stores exactly `[headerHash, selectedCommitBoundary.chainHash]`. The field is constant-size, ordered, non-optional, and independently checked against the loaded ABI and selected boundary; `bodyHash` remains the full-request digest. A recovery alias copies both values exactly.

## Concrete pre-implementation design

- `src/lineage/cache-abi.ts` owns the sole v1 manifest builder/loader. Public construction accepts only optional project-instruction `FrozenBytes`; protocol `dsh-protocol-v1`, Projector `dsh-projector-v1`, the canonical JSON model tuple, canonical system serializer, and Stage 02 tool bytes are constants. Loader parses all five length-framed fields to EOF and rejects every override or non-canonical system/tools byte. Declaration append/replay and Projector entry all invoke this loader; a hash-valid but non-canonical manifest is never admitted.
- `src/lineage/prefix.ts` requires `journalFacts` to be the exact verified Journal prefix ending at the selected Commit Boundary creator event. It loads external blobs from an explicit `ReadonlyMap<BlobRef,FrozenBytes>`, and recomputes every index, byte hash, raw-digest chain, active-Lineage/ABI relation, boundary count/hash, canonical role bytes, and protocol/effect closure. It exposes no child/fork API or mutable active pointer.
- `src/ctx/user.ts` converts same-Run `[user_input,date?,cwd?,git?]` fact Artifacts into exact UTF-8 `{"role":"user","content":<JSON string>}` bytes with fixed key order and fixed fact ordering/newlines; callers persist that blob before projecting. `src/bytes/view.ts` round-trips user bytes and exact UTF-8 `{"role":"tool","tool_call_id":<JSON string>,"content":<JSON string>}` bytes with that key order; the tool id must equal its Journal payload. Neither path does I/O or accepts a generic extension fact.
- `src/ctx/projector.ts` is pure: exact ABI + verified events + explicit external blob bytes + Lineage/CommitBoundary ids produce `[system,...roleBlobs]`, the Stage 02 complete body, boundary creator `headEventId`, and the exact two segment hashes.
- `src/ctx/snapshot.ts` is the only Stage 04 I/O adapter: publish body through `SnapshotStore`, then append `request_snapshot_stored`. Recovery alias reads the stored body and copies every identity/hash field except the new Snapshot id, Run scope, and source alias id; it never calls Projector/serializer.
- Shared Journal tightening is Lead-only: schema requires literal `projectorVersion: "dsh-projector-v1"` and exactly two segment hashes; binding preflight requires `headEventId` to be the boundary creator, the first hash to equal the ABI header, the second hash to equal the boundary chain, and recovery aliases in a different recovery Run to copy Cache ABI, Projector version, head, boundary, segments, and body identity exactly.
- One closure predicate is shared by append/replay and projection. It derives, rather than trusts, `protocolClosed:true` and `effectsSettled:true`: there is no partial/open model response, all declared calls in the only pending assistant group have exactly one canonical tool result in declaration order, and every prepared effect is durably completed or reconciled. A caller-provided boolean can never make an unsafe prefix a Commit Boundary.
- No index/store/cache is added. Cross-process tests reconstruct all state from Journal + immutable CAS bytes, delete every disposable in-memory projection, and compare exact body/hash/segment tuple.

## Ownership and allowed parallelism

| Lane | Exclusive scope | May overlap |
|---|---|---|
| Lead | public ids, ABI manifest, Projector interface, Snapshot event | none on shared types |
| Projector worker | pure implementation + reserved fixtures | identity work after interface freeze |
| Integrity worker | chain/ABI mutation and corruption fixtures | Projector implementation |
| Verification worker | read-only cross-process and purity runs | after patch freeze |

Stage 05 may proceed in a separate worktree only after Stage 03 schemas freeze; it must not edit context/lineage files. Shared event changes are integrated serially by the Lead.

## Verification

| Evidence | Exact command | Expected result | Actual result |
|---|---|---|---|
| Full context suite | `npm run test:context` | exit 0 | Final implementation `0aaca9b`: Node 26.0.0 exit 0, 59/59 pass; Node 22.23.2 via `npx --yes node@22 scripts/run-node-tests.mjs dist/test/context` exit 0, 59/59 pass |
| Cross-process determinism | `npm run test:context -- --test-name-pattern="cross-process|snapshot bytes"` | identical bytes and hash | exit 0; a fresh Node process reconstructed serialized Journal + immutable manifest/external Blob bytes exactly. Golden body `sha256:da710478bc69a6ac231ca5fa7581d94004a2e951040670a49aaf3b6bd9651d91` (1,671 bytes), Tail `sha256:421273506b0fce2940698a00c73495774feb85114d4b5b884422d3292515f1a4` |
| Projector purity | `npm run test:context -- --test-name-pattern="pure projector"` | hidden fs/time/cwd/Git/env access throws and test still passes | exit 0; the fixed 18-file production dependency closure contains only deterministic local modules plus `node:crypto`, forbidden ambient/nondeterministic access is absent, injected ambient accessors remained unused, and the env-secret sentinel was absent |
| ABI mutation matrix | `npm run test:context -- --test-name-pattern="Cache ABI mutation"` | supported component changes create a new ABI; backend/model/preset overrides are rejected | exit 0; project-instruction bytes create a distinct ABI, every manifest field mutation fails, and the exact outward-object guard rejects fixed model/version/header changes or extra override keys |
| ABI/Lineage separation | `npm run test:context -- --test-name-pattern="same ABI independent lineage"` | independent initial Sessions may share one CacheAbiId while their opaque LineageIds remain distinct; no child/fork API exists | exit 0; independent Sessions share ABI `sha256:3813964e24ba27d336a87eb35e08c01091c887665e673acbe6b9bb4d3d464533`, have distinct opaque Lineage ids, identical body bytes, and export no child/fork/branch surface |
| Credential-free projection | `npm run test:context -- --test-name-pattern="credential|env secret"` | key/`.env` sentinels never enter Context or Snapshot bytes | exit 0; no env/Credential input exists and sentinel is absent from blobs/body |
| Boundary separation | `npm run test:context -- --test-name-pattern="Cache Checkpoint|Commit Boundary"` | unsafe checkpoint cannot satisfy commit type/state | exit 0; branded ids are compile-time incompatible and a real checkpoint with a pending tool call cannot satisfy derived closure |
| Retry lookup | `npm run test:context -- --test-name-pattern="immutable snapshot|recovery alias"` | lookup returns stored bytes; invalid provenance causes no I/O; no materialization path invoked | exit 0; repeated real CAS loads are byte exact, valid recovery alias performs one load and zero publish, forbidden ABI/event/payload keys perform zero CAS loads, and no alias path has a Projector input |
| Static checks | `npm run check` | exit 0; dependency direction and forbidden I/O checks pass | Final implementation `0aaca9b`, Node 26.0.0 exit 0: `check-package: ok dependencies=4 lifecycle=0`; `git diff --check` exit 0. Regression suites: Node 26 journal 46/46, protocol 70/70, bootstrap 3/3; Node 22.23.2 journal 46/46 and protocol 70/70, all exit 0 |

## Independent review

Use a fresh read-only reviewer after identities, ABI manifest, Projector signature, Snapshot record, and boundary types are concrete but before implementation spreads. Review must cover every Charter-vs-Spec gap and the mutation/purity evidence. Record verdict and cuts.

- **Design reviewer context/date:** fresh ephemeral Codex `019fc93d-afd4-7210-8529-d902f66a4c2b`, read-only sandbox, full 143-line reviewer prompt read; 2026-08-04. **Verdict:** Direction `KEEP`; Implementation `REWORK`; Verification `NOT RUN`. Four design cuts required literal Projector/head/hash/alias identity, shared derived closure, canonical user/tool round trips with tool-id binding, and fixed ABI loading.
- **Implementation reviewer context/date:** fresh independent `/root/stage04_final_review`, read-only, full reviewer prompt read; 2026-08-04. **Verdict:** Direction `KEEP`; Implementation `ACCEPT AFTER CUTS`; Verification `PASSED`. It found append/replay closure admission asymmetry and the ability to detach a completed/reconciled Effect through a null-Effect synthetic result.
- **Final cut verifier context/date:** fresh independent `/root/stage04_cuts_verifier`, no inherited context, read-only, full reviewer prompt read; 2026-08-04. **Verdict:** Direction `KEEP`; Implementation `ACCEPT`; Verification `PASSED`; `cuts=0`. It independently ran context 59/59, journal 46/46, `npm run check`, and `git diff --check`, all exit 0, and verified closure parity, terminal Effect/Artifact/source binding, canonical producer inputs, exact zero-I/O alias provenance, exact ABI loading, and the fixed pure Projector dependency closure.

## No-go conditions

- `lineageId` is derived only from header/model and cannot distinguish same-ABI branches.
- One `boundary` type is used for cache value and recovery safety.
- Projector reads live external state or an extension injects unjournaled context.
- Request Snapshot omits top-level provider-visible bytes or can be regenerated on retry.
- Snapshot/Lineage accepts Pro, high, another model, endpoint, `base_url`, or a credential value from environment/config facts.
- Any prior Tail element or Artifact projection already in history is rewritten.
- Compaction/fork behavior is implemented before its evidence-gated stage.

## Handoff evidence

Return fixed Flash/thinking/max ABI manifest/version/hash, identity diagram, Snapshot/prefix hashes, exact commands/exits, purity/mutation/rejection and credential-sentinel matrices, reviewer verdict, paths, and interfaces consumed by Stages 05–07.

## Completion and cleanup

- [x] All Stage 04 Actual result and review fields are complete at implementation `0aaca9b`.
- [x] Same facts reproduce identical bytes across restart.
- [x] All ABI mutations and boundary misuse tests fail/pass as designed; final review cuts are zero.
- [x] Durable object/projection decisions are in the Engineering Spec.
- [ ] Unblock Stage 06 only with Stage 05 effect evidence, then remove this Plan and index row.
