# Stage 09 — Compaction Admission Closure

- **Status:** `BLOCKED`
- **Gate:** evidence-gated after Stage 08
- **Depends on:** accepted Gate 2 baseline plus real Session economics
- **Lead:** unassigned
- **Baseline:** record when activated
- **Review:** required; fresh read-only reviewer judges the real evidence and admission conclusion
- **Write scope before admission:** this Plan, its `PLANS.md` row, and an ordinary user-facing availability statement in `README.md`; Session/trace evidence is read-only

## Actual need

Close the initial Compaction stage without inventing demand. The v0.1 baseline has no command, event, module, configuration, or feature test. Gate 2 must either prove a real caller and then freeze a reviewed design, or publish an auditable `unavailable` conclusion and remove this Plan/index row.

## Admission evidence

All conditions are required before any implementation scope exists:

1. One identified real Session has measured prefix `N`, proposed retained bytes/tokens `M`, `rho=M/N`, dated Flash ratio `r`, output/cold-start cost, predicted break-even `K`, and enough remaining requests to exceed `K` with margin.
2. The task is not near completion and bounded tool projections, ordinary files, Artifacts, Shell, Git, or a new Session cannot solve the observed failure more cheaply.
3. The user makes an informed request for that Session after seeing the measured tradeoff; no synthetic trace or generic roadmap desire counts.
4. Source evidence is credential-free, attributable to the frozen Gate 2 revision, and reproducible by the Lead.

## Bounded audit loop

```text
freeze Gate 2 revision
→ inspect actual Session/cost/context evidence
→ test cheaper existing primitives
→ fresh independent admission review
→ admitted design revision OR README unavailable statement
→ Lead verifies package/code presence or absence
→ delete Plan/index row
```

## Closure A — admitted

Do not implement from this Plan's name alone. First revise the Engineering Spec and this Plan with the observed caller, exact API/events/bytes, durability/recovery rules, exclusive source/test scope, deterministic fixtures, live budget, and validation commands. Obtain a fresh `KEEP` plus implementation verdict; only then may Stage 09 become `ACTIVE`. Future design must preserve complete episodes, safe Commit Boundaries, immutable old Lineages/Artifacts, fixed Flash/thinking/max, and no automatic trigger, hidden store, second model, or Gateway bypass.

## Closure B — non-admitted

Keep the audit details in this Plan/Git history. Add only a plain candidate-specific `Compaction: unavailable` statement and falsifiable re-admission trigger to `README.md`; do not create a capability registry/protocol. Do not add source, stub, CLI/config/schema, event, registry, or feature-specific test script.

## Lead verification

| Evidence | Exact command | Expected |
|---|---|---|
| Baseline health | `npm run check` | exit 0 |
| Non-admitted claim | `rg -n '^Compaction: unavailable' README.md` | exit 0; one candidate-specific statement and trigger |
| Non-admitted package | `npm pack --dry-run` | exit 0; no Compaction module/CLI/config/schema/test entry |
| Final release consistency | `npm run test:release` | deferred to Stage 12; then exit 0 and README/package agree |
| Admitted path | commands frozen in the reviewed replacement section | no implementation before review |

## No-go conditions

- A synthetic prompt, context-window percentage, or hypothetical savings is used as admission evidence.
- Implementation begins before exact design review, or modifies provider-visible bytes without a new Cache ABI/attributed planned cache break.
- A non-admitted result leaves this Plan indefinitely `BLOCKED`, or ships an empty framework/false PASS.

## Completion cleanup

Lead records revision, exact commands/exits, evidence paths, review verdict/cuts, and closure choice. Durable user-visible availability remains a normal README release statement; audit details remain in Git history. Rewrite downstream dependencies, then remove this Plan and its index row.
