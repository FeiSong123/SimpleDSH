# Stage 10 — Fork Admission Closure

- **Status:** `BLOCKED`
- **Gate:** evidence-gated after Stage 08; if Stage 09 is admitted, shared lineage design remains serial
- **Depends on:** accepted Gate 2 baseline plus one observed same-prefix branching need
- **Lead:** unassigned
- **Baseline:** record when activated
- **Review:** required; fresh read-only reviewer judges the evidence and admission conclusion
- **Write scope before admission:** this Plan, its `PLANS.md` row, and an ordinary user-facing availability statement in `README.md`; Session/trace evidence is read-only

## Actual need

Close the initial Fork stage without inventing a branch API. The v0.1 baseline has no command, event, module, configuration, or feature test. Gate 2 must either prove a real same-prefix caller and then freeze a reviewed design, or record `Fork: unavailable` for this candidate and remove this Plan/index row.

## Admission evidence

All conditions are required before any implementation scope exists:

1. One identified real workflow needs two explicit alternatives from the exact same safe prefix, with original request, pre-fix tree, branch outcomes, and verifier preserved.
2. Ordinary new Sessions, immutable Artifacts, files, Shell, or Git branches are insufficient specifically because provider-visible prefix/provenance must be shared; convenience or hypothetical cache savings do not count.
3. The source prefix is at a verified Commit Boundary with effects settled and no pending tool call; the evidence revision is credential-free and reproducible by the Lead.
4. The caller is a user operation, not a sub-agent, hidden scheduler, second model loop, fleet, or parallel-writer proposal.

## Bounded audit loop

```text
freeze Gate 2 revision
→ inspect one actual caller/trace
→ test ordinary Session/Artifact/Git alternatives
→ fresh independent admission review
→ admitted design revision OR README unavailable statement
→ Lead verifies package/code presence or absence
→ delete Plan/index row
```

## Closure A — admitted

Do not implement from this Plan's name alone. First revise the Engineering Spec and this Plan with the observed caller, exact API/events/bytes, source-boundary proof, activation and planned-break order, Run-before-Snapshot order, persistence/recovery semantics, exclusive source/test scope, deterministic fixtures, live distribution evidence, and validation commands. Obtain a fresh implementation-permitting verdict; only then may Stage 10 become `ACTIVE`.

Any future admitted design is bounded to fixed Flash/thinking/max; each branch has an independent Lineage and Run; one Session Journal and one writer remain authoritative; old Lineages/Artifacts are immutable; no cross-model branch, hidden Agent, fleet, background service, or parallel writer is allowed.

## Closure B — non-admitted

Keep the audit details in this Plan/Git history. Add only a plain candidate-specific `Fork: unavailable` statement and falsifiable re-admission trigger to `README.md`; do not create a capability registry/protocol. Do not add source, stub, CLI/config/schema, event, registry, or feature-specific test script.

## Lead verification

| Evidence | Exact command | Expected |
|---|---|---|
| Baseline health | `npm run check` | exit 0 |
| Non-admitted claim | `rg -n '^Fork: unavailable' README.md` | exit 0; one candidate-specific statement and trigger |
| Non-admitted package | `npm pack --dry-run` | exit 0; no Fork module/CLI/config/schema/test entry |
| Final release consistency | `npm run test:release` | deferred to Stage 12; then exit 0 and README/package agree |
| Admitted path | commands frozen in the reviewed replacement section | no implementation before review |

## No-go conditions

- A synthetic branch, sub-agent design, or generic roadmap preference is used as admission evidence.
- Implementation begins before exact design review, or uses Cache Checkpoint instead of Commit Boundary as its safety proof.
- A non-admitted result leaves this Plan indefinitely `BLOCKED`, ships an empty framework, or claims capability PASS.

## Completion cleanup

Lead records revision, exact commands/exits, evidence paths, review verdict/cuts, and closure choice. Durable user-visible availability remains a normal README release statement; audit details remain in Git history. Rewrite downstream dependencies, then remove this Plan and its index row.
