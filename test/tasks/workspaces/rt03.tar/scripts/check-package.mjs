import { spawnSync } from "node:child_process";
import {
  readFileSync,
  readdirSync,
} from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { lstatIfPresent } from "./env-metadata.mjs";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const failures = [];

function fail(message) {
  failures.push(message);
}

function readJson(path) {
  return JSON.parse(readFileSync(resolve(projectRoot, path), "utf8"));
}

function sourceFiles(relativeDirectory) {
  const entries = readdirSync(resolve(projectRoot, relativeDirectory), {
    withFileTypes: true,
  });
  return entries.flatMap((entry) => {
    const relativePath = `${relativeDirectory}/${entry.name}`;
    return entry.isDirectory()
      ? sourceFiles(relativePath)
      : entry.isFile() && entry.name.endsWith(".ts")
        ? [relativePath]
        : [];
  });
}

function sameRecord(actual, expected, label) {
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    fail(`${label} must equal ${JSON.stringify(expected)}`);
  }
}

const manifest = readJson("package.json");
const shrinkwrap = readJson("npm-shrinkwrap.json");

const expectedDependencies = { "smol-toml": "1.7.1" };
const expectedDevDependencies = {
  "@types/node": "22.20.1",
  typescript: "6.0.3",
};
const expectedBlockedScripts = {
  "test:session": "Stage 06",
  "test:recovery": "Stage 07",
  "test:security": "Stage 08",
  "test:acceptance": "Stage 07",
  "test:release": "Stage 12",
  "test:live:protocol": "Stage 06",
  "test:live:cache": "Stage 07",
};
const expectedReadyScripts = {
  "test:protocol":
    "npm run build --silent && node scripts/run-node-tests.mjs dist/test/protocol",
  "test:journal":
    "npm run build --silent && node scripts/run-node-tests.mjs dist/test/journal",
  "test:context":
    "npm run build --silent && node scripts/run-node-tests.mjs dist/test/context",
  "test:effects":
    "npm run build --silent && node scripts/run-node-tests.mjs dist/test/effects",
};

if (manifest.name !== "simpledsh") fail("package name must be simpledsh");
if (manifest.version !== "0.1.0-rc.0") fail("bootstrap version must be 0.1.0-rc.0");
if (manifest.private !== true) fail("bootstrap package must remain private");
if (manifest.type !== "module") fail("package type must be module");
if (manifest.license !== "UNLICENSED") fail("bootstrap license must be UNLICENSED");
if (manifest.engines?.node !== ">=22") fail("Node engine floor must be >=22");
if (manifest.bin?.dsh !== "dist/src/cli.js") fail("dsh bin path is not canonical");
sameRecord(
  manifest.files,
  ["dist/src/", "dev/docs/dsh-spec.md"],
  "package files",
);
sameRecord(manifest.dependencies, expectedDependencies, "runtime dependencies");
sameRecord(manifest.devDependencies, expectedDevDependencies, "dev dependencies");

for (const [script, stage] of Object.entries(expectedBlockedScripts)) {
  const expected = `node scripts/blocked-stage.mjs \"${stage}\"`;
  if (manifest.scripts?.[script] !== expected) {
    fail(`${script} must fail through ${stage}`);
  }
}
for (const [script, command] of Object.entries(expectedReadyScripts)) {
  if (manifest.scripts?.[script] !== command) {
    fail(`${script} must equal ${command}`);
  }
}

for (const lifecycle of [
  "preinstall",
  "install",
  "postinstall",
  "prepare",
  "prepack",
  "postpack",
]) {
  if (manifest.scripts?.[lifecycle] !== undefined) {
    fail(`root lifecycle script is forbidden: ${lifecycle}`);
  }
}

if (shrinkwrap.lockfileVersion !== 3) fail("npm shrinkwrap lockfileVersion must be 3");
if (shrinkwrap.name !== manifest.name || shrinkwrap.version !== manifest.version) {
  fail("shrinkwrap root identity must match package.json");
}
sameRecord(
  shrinkwrap.packages?.[""]?.dependencies,
  expectedDependencies,
  "shrinkwrap runtime dependencies",
);
sameRecord(
  shrinkwrap.packages?.[""]?.devDependencies,
  expectedDevDependencies,
  "shrinkwrap dev dependencies",
);

const installedEntries = Object.entries(shrinkwrap.packages ?? {}).filter(
  ([path]) => path.startsWith("node_modules/"),
);
const dependencyCountBaseline = 4;
if (installedEntries.length > dependencyCountBaseline) {
  fail(
    `dependency count ${installedEntries.length} exceeds ratchet ${dependencyCountBaseline}`,
  );
}
for (const [path, entry] of installedEntries) {
  if (entry.hasInstallScript === true) fail(`${path} has an install lifecycle script`);
  if (typeof entry.integrity !== "string" || !entry.integrity.startsWith("sha512-")) {
    fail(`${path} lacks a sha512 registry integrity`);
  }
  if (typeof entry.resolved !== "string" || !entry.resolved.startsWith("https://")) {
    fail(`${path} lacks an HTTPS registry resolution`);
  }
}

const gitignore = readFileSync(resolve(projectRoot, ".gitignore"), "utf8");
for (const line of [
  ".env",
  ".env.*",
  "!.env.example",
  ".dsh/",
  "node_modules/",
  "dist/",
  "*.tgz",
]) {
  if (!gitignore.split("\n").includes(line)) fail(`.gitignore missing ${line}`);
}

const envExample = readFileSync(resolve(projectRoot, ".env.example"), "utf8");
if (envExample !== "DEEPSEEK_API_KEY=\n") {
  fail(".env.example must be the value-free canonical template");
}

const sourceInventory = sourceFiles("src");
const jsonParseAllowlist = new Set([
  "src/bytes/tool-result.ts",
  "src/bytes/view.ts",
  "src/ds/sse.ts",
  "src/journal/recovery.ts",
  "src/journal/schema.ts",
  "src/tool/validate.ts",
]);
for (const path of sourceInventory) {
  const source = readFileSync(resolve(projectRoot, path), "utf8");
  if (/JSON\.parse\s*\(/u.test(source) && !jsonParseAllowlist.has(path)) {
    fail(`JSON.parse is outside an approved read-only/invariant path: ${path}`);
  }
  if (/\bfetch\s*\(/u.test(source)) {
    fail(`global fetch is forbidden in the DeepSeek-native runtime: ${path}`);
  }
  if (/import\s*\{[^}]*\brequest\b[^}]*\}\s*from\s*["']node:https["']/su.test(source)) {
    fail(`default node:https outbound is blocked until Stage 06: ${path}`);
  }
  if (/\b(?:Provider|Backend)(?:Factory|Registry|Router|Adapter)\b/u.test(source)) {
    fail(`provider abstraction is forbidden: ${path}`);
  }
}

const forbiddenBashRuntimePatterns = [
  [/\blimactl\b/iu, "Lima control path"],
  [/\bnerdctl\b/iu, "nerdctl runtime path"],
  [/\bcontainerd\b/iu, "containerd runtime path"],
  [/\brunc\b/iu, "runc runtime path"],
  [/\brootlesskit\b/iu, "RootlessKit runtime path"],
  [/\bAdmittedBash\w*/u, "admitted bash capability"],
  [/\bCredentialShield\w*/u, "Credential Shield capability"],
  [/\bDescendantSupervisor\w*/u, "descendant supervisor capability"],
  [/alpine@sha256/iu, "pinned bash image"],
  [/external-required/iu, "external runtime capability state"],
];
for (const path of sourceInventory) {
  const source = readFileSync(resolve(projectRoot, path), "utf8");
  for (const [pattern, label] of forbiddenBashRuntimePatterns) {
    if (pattern.test(source)) fail(`${label} is forbidden in production source: ${path}`);
  }
}

for (const path of sourceInventory) {
  if (path === "src/ds/credential.ts") continue;
  const source = readFileSync(resolve(projectRoot, path), "utf8");
  if (/process\.env|readFileSync\([^\n]*\.env/u.test(source)) {
    fail(`credential source access is outside CredentialLoader: ${path}`);
  }
}

const envPath = resolve(projectRoot, ".env");
const envInfo = lstatIfPresent(envPath);
if (envInfo !== undefined) {
  if (envInfo.isSymbolicLink() || !envInfo.isFile()) {
    fail(".env must be a regular non-symlink file");
  }
  if ((envInfo.mode & 0o777) !== 0o600) fail(".env mode must be 0600");
}
const ignored = spawnSync("git", ["check-ignore", "--quiet", "--no-index", ".env"], {
  cwd: projectRoot,
  stdio: "ignore",
});
if (ignored.status !== 0) fail(".env must be ignored by Git");
const tracked = spawnSync("git", ["ls-files", "--error-unmatch", ".env"], {
  cwd: projectRoot,
  stdio: "ignore",
});
if (tracked.status === 0) fail(".env must not be tracked by Git");
if (tracked.status !== 0 && tracked.status !== 1) {
  fail("cannot determine whether .env is tracked by Git");
}

const packed = spawnSync(
  "npm",
  ["pack", "--dry-run", "--json", "--ignore-scripts"],
  { cwd: projectRoot, encoding: "utf8" },
);
if (packed.error !== undefined || packed.status !== 0) {
  fail(`npm pack --dry-run failed: ${packed.stderr.trim()}`);
} else {
  try {
    const result = JSON.parse(packed.stdout);
    const paths = result[0]?.files?.map((file) => file.path) ?? [];
    for (const required of ["package.json", "dist/src/cli.js", "dev/docs/dsh-spec.md"]) {
      if (!paths.includes(required)) fail(`packed files missing ${required}`);
    }
    for (const path of paths) {
      if (
        path === ".env" ||
        path.startsWith(".env.") ||
        path.startsWith(".dsh/") ||
        path.startsWith("node_modules/") ||
        path.startsWith("src/") ||
        path.startsWith("test/") ||
        path.startsWith("scripts/")
      ) {
        fail(`forbidden packed path: ${path}`);
      }
    }
  } catch (error) {
    fail(`cannot parse npm pack JSON: ${String(error)}`);
  }
}

if (failures.length > 0) {
  for (const failure of failures) process.stderr.write(`check-package: ${failure}\n`);
  process.exitCode = 1;
} else {
  process.stdout.write(
    `check-package: ok dependencies=${installedEntries.length} lifecycle=0\n`,
  );
}
