import { spawnSync } from "node:child_process";
import { readdirSync } from "node:fs";
import { resolve } from "node:path";

const [relativeDirectory, ...nodeOptions] = process.argv.slice(2);
if (relativeDirectory === undefined || relativeDirectory.length === 0) {
  process.stderr.write("run-node-tests: missing compiled test directory\n");
  process.exitCode = 2;
} else {
  const directory = resolve(relativeDirectory);
  const testFiles = readdirSync(directory)
    .filter((name) => name.endsWith(".test.js"))
    .sort()
    .map((name) => resolve(directory, name));
  if (testFiles.length === 0) {
    process.stderr.write("run-node-tests: no compiled tests found\n");
    process.exitCode = 2;
  } else {
    const result = spawnSync(
      process.execPath,
      ["--test", ...nodeOptions, ...testFiles],
      { stdio: "inherit" },
    );
    if (result.error !== undefined) throw result.error;
    process.exitCode = result.status ?? 1;
  }
}
