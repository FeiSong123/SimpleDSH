#!/usr/bin/env node

process.stderr.write("BLOCKED: Stage 06\n");
process.exitCode = 2;
