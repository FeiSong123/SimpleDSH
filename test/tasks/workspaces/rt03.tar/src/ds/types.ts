import type { FrozenBytes } from "../bytes/types.js";

export interface ToolCall {
  readonly id: string;
  readonly type: "function";
  readonly function: {
    readonly name: string;
    readonly arguments: string;
  };
}

export interface AssistantView {
  readonly role: "assistant";
  readonly content: string;
  readonly reasoningContent: string;
  readonly toolCalls: readonly ToolCall[];
}

export interface DeepSeekUsage {
  readonly promptTokens: number;
  readonly promptCacheHitTokens: number;
  readonly promptCacheMissTokens: number;
  readonly completionTokens: number;
  readonly reasoningTokens: number;
  readonly rawFinishReason: string;
}

export type SemanticDeltaKind = "reasoning" | "content" | "tool_call";

export interface StreamHooks {
  readonly onSemanticDelta?: (
    kind: SemanticDeltaKind,
  ) => void | Promise<void>;
}

export interface CompletedDeepSeekResponse {
  readonly assistantBytes: FrozenBytes;
  readonly content: string;
  readonly reasoningContent: string;
  readonly toolCalls: readonly ToolCall[];
  readonly usage: DeepSeekUsage;
  readonly providerRequestId: string;
  readonly responseModel: string;
  readonly systemFingerprint: string | null;
  readonly semanticDeltaCount: number;
}
