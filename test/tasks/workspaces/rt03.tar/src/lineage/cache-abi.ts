import {
  bytesEqual,
  concatBytes,
  lengthPrefix,
  sha256Hex,
  utf8Bytes,
} from "../bytes/ops.js";
import { CANONICAL_TOOLS_BYTES } from "../bytes/schemas.js";
import {
  BASE_SYSTEM_PROMPT,
  materializeSystemMessage,
} from "../bytes/system.js";
import { freezeBytes, FrozenBytes } from "../bytes/types.js";
import { viewSystem } from "../bytes/view.js";
import type { CacheAbiId, Sha256 } from "../journal/types.js";

export const PROTOCOL_VERSION_V1 = "dsh-protocol-v1" as const;
export const PROJECTOR_VERSION_V1 = "dsh-projector-v1" as const;

export const MODEL_TUPLE_BYTES = utf8Bytes(
  '{"model":"deepseek-v4-flash","thinking":{"type":"enabled"},"reasoning_effort":"max"}',
);

const MANIFEST_DOMAIN_BYTES = utf8Bytes("dsh-cache-abi-v1\0");
const PROTOCOL_VERSION_BYTES = utf8Bytes(PROTOCOL_VERSION_V1);
const PROJECTOR_VERSION_BYTES = utf8Bytes(PROJECTOR_VERSION_V1);

export interface FrozenCacheAbiManifest {
  readonly manifestBytes: FrozenBytes;
  readonly cacheAbiId: CacheAbiId;
  readonly protocolVersion: typeof PROTOCOL_VERSION_V1;
  readonly projectorVersion: typeof PROJECTOR_VERSION_V1;
  readonly modelTupleBytes: FrozenBytes;
  readonly systemBlob: FrozenBytes;
  readonly toolsBlob: FrozenBytes;
  readonly headerHash: Sha256;
}

const CACHE_ABI_KEYS = Object.freeze([
  "manifestBytes",
  "cacheAbiId",
  "protocolVersion",
  "projectorVersion",
  "modelTupleBytes",
  "systemBlob",
  "toolsBlob",
  "headerHash",
] as const);

interface ParsedManifestFields {
  readonly protocolVersionBytes: FrozenBytes;
  readonly projectorVersionBytes: FrozenBytes;
  readonly modelTupleBytes: FrozenBytes;
  readonly systemBlob: FrozenBytes;
  readonly toolsBlob: FrozenBytes;
}

function cacheAbiId(bytes: FrozenBytes): CacheAbiId {
  return `sha256:${sha256Hex(bytes)}` as CacheAbiId;
}

function sha256(bytes: FrozenBytes): Sha256 {
  return `sha256:${sha256Hex(bytes)}` as Sha256;
}

function copyFrozen(bytes: FrozenBytes): FrozenBytes {
  return freezeBytes(bytes.copy());
}

function freezeManifest(
  manifestBytes: FrozenBytes,
  fields: Pick<
    ParsedManifestFields,
    "modelTupleBytes" | "systemBlob" | "toolsBlob"
  >,
): FrozenCacheAbiManifest {
  const headerBytes = concatBytes([
    lengthPrefix(fields.systemBlob),
    lengthPrefix(fields.toolsBlob),
  ]);

  return Object.freeze({
    manifestBytes: copyFrozen(manifestBytes),
    cacheAbiId: cacheAbiId(manifestBytes),
    protocolVersion: PROTOCOL_VERSION_V1,
    projectorVersion: PROJECTOR_VERSION_V1,
    modelTupleBytes: copyFrozen(fields.modelTupleBytes),
    systemBlob: copyFrozen(fields.systemBlob),
    toolsBlob: copyFrozen(fields.toolsBlob),
    headerHash: sha256(headerBytes),
  });
}

function manifestBytesFor(
  systemBlob: FrozenBytes,
  toolsBlob: FrozenBytes,
): FrozenBytes {
  return concatBytes([
    MANIFEST_DOMAIN_BYTES,
    lengthPrefix(PROTOCOL_VERSION_BYTES),
    lengthPrefix(PROJECTOR_VERSION_BYTES),
    lengthPrefix(MODEL_TUPLE_BYTES),
    lengthPrefix(systemBlob),
    lengthPrefix(toolsBlob),
  ]);
}

function assertCanonicalSystemBlob(systemBlob: FrozenBytes): void {
  let content: string;
  try {
    content = viewSystem(systemBlob).content;
  } catch {
    throw new TypeError("Cache ABI system blob does not round-trip canonically");
  }

  const marker = `${BASE_SYSTEM_PROMPT}\n\nProject instructions:\n`;
  let projectInstructions: FrozenBytes | undefined;
  if (content !== BASE_SYSTEM_PROMPT) {
    if (!content.startsWith(marker)) {
      throw new TypeError("Cache ABI system blob has non-canonical content");
    }
    const instructions = content.slice(marker.length);
    if (instructions.length === 0) {
      throw new TypeError("Cache ABI system blob has empty project instructions");
    }
    projectInstructions = utf8Bytes(instructions);
  }

  const rematerialized = materializeSystemMessage(projectInstructions);
  if (!bytesEqual(systemBlob, rematerialized)) {
    throw new TypeError("Cache ABI system blob does not round-trip canonically");
  }
}

function parseManifest(bytes: FrozenBytes): ParsedManifestFields {
  const source = bytes.copy();
  const domain = MANIFEST_DOMAIN_BYTES.copy();
  if (
    source.byteLength < domain.byteLength ||
    !Uint8Array.prototype.every.call(
      domain,
      (value: number, index: number) => source[index] === value,
    )
  ) {
    throw new TypeError("Cache ABI manifest has the wrong domain");
  }

  let offset = domain.byteLength;
  const readFrame = (label: string): FrozenBytes => {
    if (source.byteLength - offset < 8) {
      throw new TypeError(`Cache ABI ${label} length prefix is truncated`);
    }
    const length = new DataView(
      source.buffer,
      source.byteOffset + offset,
      8,
    ).getBigUint64(0, false);
    offset += 8;
    if (length > BigInt(Number.MAX_SAFE_INTEGER)) {
      throw new TypeError(`Cache ABI ${label} length is unsafe`);
    }
    const byteLength = Number(length);
    if (byteLength > source.byteLength - offset) {
      throw new TypeError(`Cache ABI ${label} payload is truncated`);
    }
    const value = freezeBytes(source.slice(offset, offset + byteLength));
    offset += byteLength;
    return value;
  };

  const fields: ParsedManifestFields = {
    protocolVersionBytes: readFrame("protocol version"),
    projectorVersionBytes: readFrame("projector version"),
    modelTupleBytes: readFrame("model tuple"),
    systemBlob: readFrame("system blob"),
    toolsBlob: readFrame("tools blob"),
  };
  if (offset !== source.byteLength) {
    throw new TypeError("Cache ABI manifest has trailing bytes");
  }
  return fields;
}

export function buildCacheAbiV1(
  projectInstructions?: FrozenBytes,
): FrozenCacheAbiManifest {
  const systemBlob = materializeSystemMessage(projectInstructions);
  const toolsBlob = copyFrozen(CANONICAL_TOOLS_BYTES);
  const manifestBytes = manifestBytesFor(systemBlob, toolsBlob);
  return freezeManifest(manifestBytes, {
    modelTupleBytes: MODEL_TUPLE_BYTES,
    systemBlob,
    toolsBlob,
  });
}

export function loadCacheAbiV1(
  bytes: FrozenBytes,
  expectedCacheAbiId: CacheAbiId,
): FrozenCacheAbiManifest {
  const fields = parseManifest(bytes);

  if (!bytesEqual(fields.protocolVersionBytes, PROTOCOL_VERSION_BYTES)) {
    throw new TypeError("Cache ABI protocol version is not canonical v1");
  }
  if (!bytesEqual(fields.projectorVersionBytes, PROJECTOR_VERSION_BYTES)) {
    throw new TypeError("Cache ABI projector version is not canonical v1");
  }
  if (!bytesEqual(fields.modelTupleBytes, MODEL_TUPLE_BYTES)) {
    throw new TypeError("Cache ABI model tuple is not canonical v1");
  }
  assertCanonicalSystemBlob(fields.systemBlob);
  if (!bytesEqual(fields.toolsBlob, CANONICAL_TOOLS_BYTES)) {
    throw new TypeError("Cache ABI tools blob is not canonical v1");
  }

  const actualCacheAbiId = cacheAbiId(bytes);
  if (actualCacheAbiId !== expectedCacheAbiId) {
    throw new TypeError("Cache ABI manifest hash does not match its identity");
  }

  return freezeManifest(bytes, fields);
}

function sameBytes(left: unknown, right: FrozenBytes): boolean {
  return left instanceof FrozenBytes && bytesEqual(left, right);
}

export function loadAndAssertCacheAbiV1(
  candidate: FrozenCacheAbiManifest,
): FrozenCacheAbiManifest {
  if (
    typeof candidate !== "object" ||
    candidate === null ||
    Reflect.ownKeys(candidate).length !== CACHE_ABI_KEYS.length ||
    !CACHE_ABI_KEYS.every((key) =>
      Object.prototype.hasOwnProperty.call(candidate, key),
    ) ||
    !(candidate.manifestBytes instanceof FrozenBytes) ||
    typeof candidate.cacheAbiId !== "string"
  ) {
    throw new TypeError("Cache ABI object does not match its manifest");
  }

  const loaded = loadCacheAbiV1(
    candidate.manifestBytes,
    candidate.cacheAbiId,
  );
  if (
    !sameBytes(candidate.manifestBytes, loaded.manifestBytes) ||
    candidate.cacheAbiId !== loaded.cacheAbiId ||
    candidate.protocolVersion !== loaded.protocolVersion ||
    candidate.projectorVersion !== loaded.projectorVersion ||
    !sameBytes(candidate.modelTupleBytes, loaded.modelTupleBytes) ||
    !sameBytes(candidate.systemBlob, loaded.systemBlob) ||
    !sameBytes(candidate.toolsBlob, loaded.toolsBlob) ||
    candidate.headerHash !== loaded.headerHash
  ) {
    throw new TypeError("Cache ABI object does not match its manifest");
  }
  return loaded;
}
