import { concatBytes, utf8Bytes } from "./ops.js";
import type { FrozenBytes } from "./types.js";

export const BASE_SYSTEM_PROMPT =
  "You are SimpleDSH, a coding agent. Work directly with the user using read, write, edit, and bash. Keep plans and durable state in visible files. Treat tool results as the only evidence that an action occurred.";

const fatalDecoder = new TextDecoder("utf-8", { fatal: true });

function jsonString(value: string): FrozenBytes {
  return utf8Bytes(JSON.stringify(value));
}

export function materializeSystemMessage(
  projectInstructions?: FrozenBytes,
): FrozenBytes {
  let content = BASE_SYSTEM_PROMPT;
  if (projectInstructions !== undefined && projectInstructions.byteLength > 0) {
    content += `\n\nProject instructions:\n${fatalDecoder.decode(projectInstructions.copy())}`;
  }

  return concatBytes([
    utf8Bytes('{"role":"system","content":'),
    jsonString(content),
    utf8Bytes("}"),
  ]);
}

export const BASE_SYSTEM_MESSAGE_BYTES = materializeSystemMessage();
