import { concatBytes, joinBytes, lengthPrefix, sha256Hex, utf8Bytes } from "./ops.js";
import { CANONICAL_TOOLS_BYTES } from "./schemas.js";
import { BASE_SYSTEM_MESSAGE_BYTES } from "./system.js";
import type { FrozenBytes } from "./types.js";

export const DEEPSEEK_MODEL = "deepseek-v4-flash";
export const DEEPSEEK_ENDPOINT = "https://api.deepseek.com/chat/completions";

const REQUEST_PREFIX = utf8Bytes(
  '{"model":"deepseek-v4-flash","messages":[',
);
const REQUEST_SUFFIX_PREFIX = utf8Bytes('],"tools":');
const REQUEST_SUFFIX = utf8Bytes(
  ',"stream":true,"stream_options":{"include_usage":true},"thinking":{"type":"enabled"},"reasoning_effort":"max","max_tokens":65536}',
);
const COMMA = utf8Bytes(",");

export interface DeepSeekRequestSnapshot {
  readonly body: FrozenBytes;
  readonly bodySha256: string;
  readonly byteCount: number;
}

function snapshotFromBody(body: FrozenBytes): DeepSeekRequestSnapshot {
  return Object.freeze({
    body,
    bodySha256: sha256Hex(body),
    byteCount: body.byteLength,
  });
}

export function buildDeepSeekRequestSnapshot(
  messages: readonly FrozenBytes[],
): DeepSeekRequestSnapshot {
  if (messages.length === 0) {
    throw new TypeError("at least one frozen message is required");
  }

  const body = concatBytes([
    REQUEST_PREFIX,
    joinBytes(messages, COMMA),
    REQUEST_SUFFIX_PREFIX,
    CANONICAL_TOOLS_BYTES,
    REQUEST_SUFFIX,
  ]);
  return snapshotFromBody(body);
}

export function restoreDeepSeekRequestSnapshot(
  body: FrozenBytes,
  expected: { readonly bodySha256: string; readonly byteCount: number },
): DeepSeekRequestSnapshot {
  const restored = snapshotFromBody(body);
  if (
    restored.bodySha256 !== expected.bodySha256 ||
    restored.byteCount !== expected.byteCount
  ) {
    throw new TypeError("durable DeepSeek request snapshot integrity mismatch");
  }
  return restored;
}

export const BASE_FROZEN_ZONE_BYTES = concatBytes([
  lengthPrefix(BASE_SYSTEM_MESSAGE_BYTES),
  lengthPrefix(CANONICAL_TOOLS_BYTES),
]);

// Changing this value is an explicit Cache ABI change and requires review.
export const BASE_FROZEN_ZONE_SHA256 =
  "33a24d401390430f87efef9f9136c8200ec6998ad53266ec85102349f8de2ef1";

// Request containing only the canonical base system message.
export const BASE_REQUEST_GOLDEN_SHA256 =
  "08d4f3c292718aa87a9c7b31d24d69bc9c2f48e8ebabe1dd4b5c38f4a7e8c29d";
