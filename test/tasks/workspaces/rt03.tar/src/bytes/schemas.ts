import { utf8Bytes } from "./ops.js";

// This literal is provider-visible Cache ABI. Keep tool names sorted and never
// regenerate it from objects or a schema library.
const CANONICAL_TOOLS_JSON =
  '[{"type":"function","function":{"name":"bash","description":"Run one shell command in the workspace.","parameters":{"type":"object","properties":{"command":{"type":"string"},"timeout":{"type":"number","exclusiveMinimum":0}},"required":["command"],"additionalProperties":false}}},{"type":"function","function":{"name":"edit","description":"Replace exact text in a file.","parameters":{"type":"object","properties":{"path":{"type":"string"},"old_string":{"type":"string"},"new_string":{"type":"string"},"replace_all":{"type":"boolean"}},"required":["path","old_string","new_string","replace_all"],"additionalProperties":false}}},{"type":"function","function":{"name":"read","description":"Read a bounded file slice with line numbers.","parameters":{"type":"object","properties":{"path":{"type":"string"},"offset":{"type":"integer","minimum":0},"limit":{"type":"integer","minimum":1}},"required":["path"],"additionalProperties":false}}},{"type":"function","function":{"name":"write","description":"Write complete content to a file.","parameters":{"type":"object","properties":{"path":{"type":"string"},"content":{"type":"string"}},"required":["path","content"],"additionalProperties":false}}}]';

export const CANONICAL_TOOLS_BYTES = utf8Bytes(CANONICAL_TOOLS_JSON);
