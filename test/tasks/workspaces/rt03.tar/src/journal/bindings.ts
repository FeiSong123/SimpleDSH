import {
  bytesEqual,
  concatBytes,
  fromBase64,
  lengthPrefix,
  sha256Hex,
  utf8Bytes,
} from "../bytes/ops.js";
import {
  materializeToolResultMessage,
  parseToolResultContent,
  TOOL_RESULT_PROJECTION_LIMIT_BYTES,
} from "../bytes/tool-result.js";
import type { StaticToolResultContent } from "../bytes/tool-result.js";
import type { FrozenBytes } from "../bytes/types.js";
import { viewAssistant, viewTool, viewUser } from "../bytes/view.js";
import { createToolOutputFrameParser } from "../artifact/tool-output.js";
import type { ToolOutputFrameSummary } from "../artifact/tool-output.js";
import type { ToolTerminalSource } from "../artifact/tool-terminal-source.js";
import { loadCacheAbiV1 } from "../lineage/cache-abi.js";
import { createArtifactToolResultProjector } from "../tool/result.js";
import {
  validateToolArguments,
} from "../tool/validate.js";
import type {
  StaticToolValidationCode,
  ToolName,
  ValidatedToolArguments,
} from "../tool/validate.js";
import { isCommitClosureV1 } from "./closure.js";
import { journalError } from "./errors.js";
import type { JournalAppendPreflight, PreparedJournalAppend } from "./writer.js";
import type {
  AnyVerifiedJournalEvent,
  BlobPayload,
  BlobRef,
  JournalEventType,
  JournalPayloadByType,
  Sha256,
  SnapshotRef,
  ToolTerminal,
} from "./types.js";

interface EventBinding {
  readonly type: JournalEventType;
  readonly event: AnyVerifiedJournalEvent;
}

type ObjectKind =
  | "cache_abi"
  | "lineage"
  | "run"
  | "artifact"
  | "artifact_version"
  | "request_snapshot"
  | "attempt"
  | "cache_checkpoint"
  | "commit_boundary"
  | "effect";

interface ObjectBinding {
  readonly kind: ObjectKind;
  readonly eventId: string;
}

interface RunScopedBinding extends ObjectBinding {
  readonly lineageId: string;
  readonly runId: string;
}

interface RunBinding extends ObjectBinding {
  readonly kind: "run";
  readonly lineageId: string;
  readonly cause: "user" | "recovery";
  readonly previousRunId: string | null;
}

interface CacheAbiBinding extends ObjectBinding {
  readonly kind: "cache_abi";
  readonly headerHash: Sha256;
}

interface LineageBinding extends ObjectBinding {
  readonly kind: "lineage";
  readonly cacheAbiId: string;
}

interface ArtifactBinding extends ObjectBinding {
  readonly kind: "artifact";
  readonly lineageId: string | undefined;
  readonly runId: string | undefined;
  readonly payload: JournalPayloadByType["artifact_published"];
}

interface SnapshotBinding extends RunScopedBinding {
  readonly kind: "request_snapshot";
  readonly payload: JournalPayloadByType["request_snapshot_stored"];
}

interface AttemptBinding extends RunScopedBinding {
  readonly kind: "attempt";
  readonly requestSnapshotId: string;
}

interface CheckpointBinding extends RunScopedBinding {
  readonly kind: "cache_checkpoint";
}

interface BoundaryBinding extends RunScopedBinding {
  readonly kind: "commit_boundary";
  readonly payload: JournalPayloadByType["commit_boundary_created"];
}

interface ToolCallBinding {
  readonly id: string;
  readonly assistantEventId: string;
  readonly lineageId: string;
  readonly runId: string;
  readonly ordinal: number;
  readonly groupSize: number;
  readonly name: string;
  readonly argumentsHash: Sha256;
  readonly validatedArguments: ValidatedToolArguments | undefined;
  readonly validationCode: StaticToolValidationCode | undefined;
  readonly resultEventId: string | undefined;
}

interface ToolGroupBinding {
  readonly assistantEventId: string;
  readonly callIds: readonly string[];
  readonly nextResultOrdinal: number;
}

interface PermissionBinding {
  readonly eventId: string;
  readonly finalDecision: "allow" | "deny";
}

interface EffectBinding extends RunScopedBinding {
  readonly kind: "effect";
  readonly toolCallId: string;
  readonly toolName: Exclude<ToolName, "read">;
  readonly status:
    | "prepared"
    | "completed"
    | "indeterminate"
    | "reconciled_completed"
    | "reconciled_not_executed";
  readonly outputArtifactId: string | undefined;
  readonly terminalEventId: string | undefined;
}

interface LineagePrefix {
  readonly nextBlobIndex: number;
  readonly chainHash: Sha256 | null;
}

type ProjectInstructionsChange =
  | Readonly<{ readonly phase: "awaiting_abi" }>
  | Readonly<{
      readonly phase: "awaiting_activation";
      readonly cacheAbiId: string;
    }>;

interface BindingState {
  sessionId: string | undefined;
  activeLineageId: string | undefined;
  pendingAbiChange:
    | Readonly<{ fromLineageId: string; toLineageId: string }>
    | undefined;
  projectInstructionsChange: ProjectInstructionsChange | undefined;
  readonly events: Map<string, EventBinding>;
  readonly objects: Map<string, ObjectBinding>;
  readonly artifacts: Map<string, ArtifactBinding>;
  readonly artifactVersions: Map<
    string,
    JournalPayloadByType["artifact_version_created"]
  >;
  readonly attempts: Map<string, AttemptBinding>;
  readonly effects: Map<string, EffectBinding>;
  readonly activeEffectsByCall: Map<string, string>;
  readonly permissions: Map<string, PermissionBinding>;
  readonly semanticAttempts: Set<string>;
  readonly terminalAttempts: Set<string>;
  readonly checkpointSources: Set<string>;
  readonly recoveryHashes: Set<string>;
  readonly toolCalls: Map<string, ToolCallBinding>;
  readonly pendingToolGroups: Map<string, ToolGroupBinding>;
  readonly snapshotOrdinals: Map<string, number>;
  readonly lineagePrefixes: Map<string, LineagePrefix>;
}

export interface JournalReferenceVerifier {
  loadBlob(ref: BlobRef): Promise<FrozenBytes>;
  loadArtifact(
    payload: JournalPayloadByType["artifact_published"],
  ): Promise<FrozenBytes>;
  scanArtifact(
    payload: JournalPayloadByType["artifact_published"],
    visit: (bytes: FrozenBytes) => void,
  ): Promise<void>;
  verifyArtifact(
    payload: JournalPayloadByType["artifact_published"],
  ): Promise<void>;
  verifySnapshot(
    ref: SnapshotRef,
    hash: Sha256,
    byteCount: number,
  ): Promise<void>;
  verifyRecovery(
    payload: JournalPayloadByType["journal_tail_recovered"],
    sessionId: string,
    validPrefixByteCount: number,
  ): Promise<void>;
}

export interface JournalPhysicalContext {
  readonly validPrefixByteCount: number;
}

export interface BindingProjectionSnapshot {
  readonly sessionId: string | undefined;
  readonly eventCount: number;
  readonly objectCount: number;
  readonly blobCount: number;
  readonly chainHash: Sha256 | null;
  readonly eventIds: readonly string[];
  readonly objectIds: readonly string[];
}

function referenceFailure(): never {
  throw journalError("JOURNAL_REFERENCE");
}

function cloneState(state: BindingState): BindingState {
  return {
    sessionId: state.sessionId,
    activeLineageId: state.activeLineageId,
    pendingAbiChange: state.pendingAbiChange,
    projectInstructionsChange: state.projectInstructionsChange,
    events: new Map(state.events),
    objects: new Map(state.objects),
    artifacts: new Map(state.artifacts),
    artifactVersions: new Map(state.artifactVersions),
    attempts: new Map(state.attempts),
    effects: new Map(state.effects),
    activeEffectsByCall: new Map(state.activeEffectsByCall),
    permissions: new Map(state.permissions),
    semanticAttempts: new Set(state.semanticAttempts),
    terminalAttempts: new Set(state.terminalAttempts),
    checkpointSources: new Set(state.checkpointSources),
    recoveryHashes: new Set(state.recoveryHashes),
    toolCalls: new Map(state.toolCalls),
    pendingToolGroups: new Map(state.pendingToolGroups),
    snapshotOrdinals: new Map(state.snapshotOrdinals),
    lineagePrefixes: new Map(
      [...state.lineagePrefixes].map(([lineageId, prefix]) => [
        lineageId,
        Object.freeze({ ...prefix }),
      ]),
    ),
  };
}

function emptyState(): BindingState {
  return {
    sessionId: undefined,
    activeLineageId: undefined,
    pendingAbiChange: undefined,
    projectInstructionsChange: undefined,
    events: new Map(),
    objects: new Map(),
    artifacts: new Map(),
    artifactVersions: new Map(),
    attempts: new Map(),
    effects: new Map(),
    activeEffectsByCall: new Map(),
    permissions: new Map(),
    semanticAttempts: new Set(),
    terminalAttempts: new Set(),
    checkpointSources: new Set(),
    recoveryHashes: new Set(),
    toolCalls: new Map(),
    pendingToolGroups: new Map(),
    snapshotOrdinals: new Map(),
    lineagePrefixes: new Map(),
  };
}

function requireEvent(
  state: BindingState,
  id: string,
  allowedTypes?: readonly JournalEventType[],
): EventBinding {
  const binding = state.events.get(id);
  if (
    binding === undefined ||
    (allowedTypes !== undefined && !allowedTypes.includes(binding.type))
  ) {
    referenceFailure();
  }
  return binding;
}

function createObject(
  state: BindingState,
  id: string,
  binding: ObjectBinding,
): void {
  if (state.objects.has(id)) referenceFailure();
  state.objects.set(id, binding);
}

function requireObject(
  state: BindingState,
  id: string,
  kind: ObjectKind,
): ObjectBinding {
  const binding = state.objects.get(id);
  if (binding === undefined || binding.kind !== kind) referenceFailure();
  return binding;
}

function requireRunScope(event: AnyVerifiedJournalEvent): {
  readonly lineageId: string;
  readonly runId: string;
} {
  if (event.lineageId === undefined || event.runId === undefined) {
    referenceFailure();
  }
  return { lineageId: event.lineageId, runId: event.runId };
}

function requireSameLineage(
  lineageId: string,
  event: AnyVerifiedJournalEvent,
): void {
  if (event.lineageId !== lineageId) referenceFailure();
}

function requireSameRun(
  binding: RunScopedBinding,
  event: AnyVerifiedJournalEvent,
): void {
  if (
    event.lineageId !== binding.lineageId ||
    event.runId !== binding.runId
  ) {
    referenceFailure();
  }
}

function requireEventSameRun(
  source: AnyVerifiedJournalEvent,
  event: AnyVerifiedJournalEvent,
): void {
  if (
    source.lineageId === undefined ||
    source.runId === undefined ||
    source.lineageId !== event.lineageId ||
    source.runId !== event.runId
  ) {
    referenceFailure();
  }
}

function requireBindingLineage(
  binding: { readonly lineageId: string },
  event: AnyVerifiedJournalEvent,
): void {
  if (event.lineageId !== binding.lineageId) referenceFailure();
}

function activePrefix(
  state: BindingState,
  lineageId: string | undefined,
): { readonly lineageId: string; readonly prefix: LineagePrefix } {
  if (lineageId === undefined || state.activeLineageId !== lineageId) {
    referenceFailure();
  }
  if (
    state.projectInstructionsChange !== undefined ||
    state.pendingAbiChange !== undefined
  ) {
    referenceFailure();
  }
  const prefix = state.lineagePrefixes.get(lineageId);
  if (prefix === undefined) referenceFailure();
  return { lineageId, prefix };
}

function requireArtifact(
  state: BindingState,
  id: string,
): ArtifactBinding {
  const object = requireObject(state, id, "artifact") as ArtifactBinding;
  const artifact = state.artifacts.get(id);
  if (artifact === undefined || artifact !== object) referenceFailure();
  return artifact;
}

function requireArtifactScope(
  artifact: ArtifactBinding,
  event: AnyVerifiedJournalEvent,
): void {
  if (
    artifact.lineageId !== event.lineageId ||
    artifact.runId !== event.runId
  ) {
    referenceFailure();
  }
}

function rawDigest(hash: Sha256): Uint8Array {
  return Uint8Array.from(Buffer.from(hash.slice("sha256:".length), "hex"));
}

async function resolveBlob(
  payload:
    | BlobPayload<"user">
    | BlobPayload<"assistant">
    | BlobPayload<"tool">,
  verifier: JournalReferenceVerifier,
): Promise<FrozenBytes> {
  let bytes: FrozenBytes;
  if (payload.enc === "b64") {
    try {
      bytes = fromBase64(payload.bytes);
    } catch {
      referenceFailure();
    }
  } else {
    try {
      bytes = await verifier.loadBlob(payload.blobRef);
    } catch {
      referenceFailure();
    }
  }
  if (
    bytes.byteLength !== payload.byteCount ||
    `sha256:${sha256Hex(bytes)}` !== payload.byteHash
  ) {
    referenceFailure();
  }
  return bytes;
}

async function applyBlob(
  state: BindingState,
  lineageId: string | undefined,
  payload:
    | BlobPayload<"user">
    | BlobPayload<"assistant">
    | BlobPayload<"tool">,
  verifier: JournalReferenceVerifier,
): Promise<FrozenBytes> {
  const active = activePrefix(state, lineageId);
  const prefix = active.prefix;
  if (payload.blobIndex !== prefix.nextBlobIndex) referenceFailure();
  const bytes = await resolveBlob(payload, verifier);
  const expected =
    prefix.chainHash === null
      ? (`sha256:${sha256Hex(bytes)}` as Sha256)
      : (`sha256:${sha256Hex(
          concatBytes([
            lengthPrefix(rawDigest(prefix.chainHash)),
            lengthPrefix(bytes),
          ]),
        )}` as Sha256);
  if (payload.chainHash !== expected) referenceFailure();
  state.lineagePrefixes.set(
    active.lineageId,
    Object.freeze({
      nextBlobIndex: prefix.nextBlobIndex + 1,
      chainHash: expected,
    }),
  );
  return bytes;
}

function verifyScopes(
  state: BindingState,
  event: AnyVerifiedJournalEvent,
): void {
  if (event.parentId !== undefined) requireEvent(state, event.parentId);
  if (event.lineageId !== undefined && event.type !== "lineage_started") {
    requireObject(state, event.lineageId, "lineage");
  }
  if (event.runId !== undefined && event.type !== "run_started") {
    const run = requireObject(state, event.runId, "run") as RunBinding;
    if (run.lineageId !== event.lineageId) referenceFailure();
  }
}

function requireSourceEvents(
  state: BindingState,
  ids: readonly string[],
  allowedTypes?: readonly JournalEventType[],
): readonly EventBinding[] {
  return ids.map((id) => requireEvent(state, id, allowedTypes));
}

function hasCommitClosure(state: BindingState, lineageId: string): boolean {
  let openModelResponses = 0;
  for (const [attemptId, attempt] of state.attempts) {
    if (
      attempt.lineageId === lineageId &&
      !state.terminalAttempts.has(attemptId)
    ) {
      openModelResponses += 1;
    }
  }
  const group = state.pendingToolGroups.get(lineageId);
  const pendingToolCalls =
    group === undefined ? 0 : group.callIds.length - group.nextResultOrdinal;
  let unsettledEffects = 0;
  for (const effect of state.effects.values()) {
    if (
      effect.lineageId === lineageId &&
      (effect.status === "prepared" || effect.status === "indeterminate")
    ) {
      unsettledEffects += 1;
    }
  }
  return isCommitClosureV1({
    openModelResponses,
    pendingToolCalls,
    unsettledEffects,
  });
}

function lastAcceptedEvent(state: BindingState): AnyVerifiedJournalEvent | undefined {
  return [...state.events.values()].at(-1)?.event;
}

function isCanonicalPermission(
  payload: JournalPayloadByType["permission_decided"],
): boolean {
  if (payload.policyDecision === "allow") {
    return payload.finalDecision === "allow" && payload.resolution === "policy";
  }
  if (payload.policyDecision === "deny") {
    return payload.finalDecision === "deny" && payload.resolution === "policy";
  }
  if (payload.resolution === "policy") return false;
  if (payload.resolution === "yes_flag") return payload.finalDecision === "allow";
  if (payload.resolution === "non_interactive") {
    return payload.finalDecision === "deny";
  }
  return payload.resolution === "interactive";
}

function requireToolOutputArtifact(
  state: BindingState,
  artifactId: string,
): ArtifactBinding {
  const artifact = requireArtifact(state, artifactId);
  if (artifact.payload.artifactType !== "tool_output") referenceFailure();
  return artifact;
}

function requiredToolName(call: ToolCallBinding): ToolName {
  const name = call.validatedArguments?.name;
  if (name === undefined) referenceFailure();
  return name;
}

function readOffset(call: ToolCallBinding): number | undefined {
  return call.validatedArguments?.name === "read"
    ? call.validatedArguments.value.offset
    : undefined;
}

async function validateToolArtifactBytes(
  call: ToolCallBinding,
  artifact: ArtifactBinding,
  verifier: JournalReferenceVerifier,
  terminal: ToolTerminal | null,
  terminalSource: ToolTerminalSource,
): Promise<void> {
  const toolName = requiredToolName(call);
  const streamBytes = artifact.payload.streamBytes;
  const hardLimitReached = artifact.payload.hardLimitReached;
  const descendantsReaped = artifact.payload.descendantsReaped;
  if (
    streamBytes === null ||
    hardLimitReached === null ||
    artifact.payload.toolCallId !== callIdOf(call)
  ) {
    referenceFailure();
  }
  if (terminal === null) {
    if (
      (toolName === "bash" && typeof descendantsReaped !== "boolean") ||
      (toolName !== "bash" && descendantsReaped !== null)
    ) {
      referenceFailure();
    }
  } else if (artifact.payload.terminal === null && toolName === "bash") {
    if (
      typeof descendantsReaped !== "boolean" ||
      terminal.descendantsReaped !== descendantsReaped
    ) {
      referenceFailure();
    }
  } else if (
    descendantsReaped !== null ||
    terminal.descendantsReaped !== null
  ) {
    referenceFailure();
  }
  if (terminal !== null) {
    try {
      const offset = readOffset(call);
      const projector = createArtifactToolResultProjector({
        toolCallId: callIdOf(call),
        toolName,
        terminalSource,
        ...(offset === undefined ? {} : { readOffset: offset }),
        artifact: {
          artifactId: artifactIdOf(artifact),
          artifactRef: artifact.payload.artifactRef,
          artifactSha256: artifact.payload.artifactHash,
          byteCount: artifact.payload.byteCount,
          payloadBytes: streamBytes,
          hardLimitReached,
        },
        terminal,
      });
      await verifier.scanArtifact(
        artifact.payload,
        (bytes) => projector.push(bytes),
      );
      projector.finish();
    } catch {
      referenceFailure();
    }
    return;
  }
  let invalidStream = false;
  const parser = createToolOutputFrameParser({
    data(stream) {
      if (
        (toolName === "read" && stream !== "read") ||
        (toolName === "bash" && stream === "read") ||
        toolName === "write" ||
        toolName === "edit"
      ) {
        invalidStream = true;
      }
    },
    hardLimit(stream) {
      if (
        (toolName !== "read" && toolName !== "bash") ||
        (toolName === "read" && stream !== "read") ||
        (toolName === "bash" && stream === "read")
      ) {
        invalidStream = true;
      }
    },
  });
  let summary: ToolOutputFrameSummary;
  try {
    await verifier.scanArtifact(
      artifact.payload,
      (bytes) => parser.push(bytes),
    );
    summary = parser.finish();
  } catch {
    referenceFailure();
  }
  if (
    invalidStream ||
    summary.byteCount !== artifact.payload.byteCount ||
    summary.payloadBytes.read !== streamBytes.read ||
    summary.payloadBytes.stdout !== streamBytes.stdout ||
    summary.payloadBytes.stderr !== streamBytes.stderr ||
    summary.hardLimitReached !== artifact.payload.hardLimitReached
  ) {
    referenceFailure();
  }
}

function callIdOf(call: ToolCallBinding): string {
  return call.id;
}

function artifactIdOf(artifact: ArtifactBinding): string {
  return artifact.payload.artifactId;
}

function replaceEffect(
  state: BindingState,
  effectId: string,
  binding: EffectBinding,
): void {
  state.effects.set(effectId, binding);
  state.objects.set(effectId, binding);
}

async function applyEvent(
  state: BindingState,
  event: AnyVerifiedJournalEvent,
  verifier: JournalReferenceVerifier,
  physical: JournalPhysicalContext | undefined,
): Promise<void> {
  if (state.events.has(event.id)) referenceFailure();
  if (state.events.size === 0) {
    if (event.type !== "session_started") referenceFailure();
    state.sessionId = event.sessionId;
  } else if (
    event.type === "session_started" ||
    event.sessionId !== state.sessionId
  ) {
    referenceFailure();
  }
  verifyScopes(state, event);

  switch (event.type) {
    case "session_started":
      break;
    case "artifact_published": {
      try {
        await verifier.verifyArtifact(event.payload);
      } catch {
        referenceFailure();
      }
      const binding: ArtifactBinding = {
        kind: "artifact",
        eventId: event.id,
        lineageId: event.lineageId,
        runId: event.runId,
        payload: event.payload,
      };
      if (event.payload.artifactType === "tool_output") {
        const scope = requireRunScope(event);
        const callId = event.payload.toolCallId;
        const call = callId === null ? undefined : state.toolCalls.get(callId);
        const permission = callId === null ? undefined : state.permissions.get(callId);
        if (
          callId === null ||
          call === undefined ||
          call.resultEventId !== undefined ||
          call.validatedArguments === undefined ||
          permission?.finalDecision !== "allow" ||
          call.lineageId !== scope.lineageId
        ) {
          referenceFailure();
        }
        const effectId = state.activeEffectsByCall.get(callId);
        const effect = effectId === undefined ? undefined : state.effects.get(effectId);
        if (event.payload.terminal === null) {
          if (
            effect === undefined ||
            (effect.status !== "prepared" && effect.status !== "indeterminate") ||
            (effect.status === "prepared" && effect.runId !== scope.runId)
          ) {
            referenceFailure();
          }
          if (effect.status === "indeterminate") {
            const run = requireObject(state, scope.runId, "run") as RunBinding;
            if (run.cause !== "recovery") referenceFailure();
          }
        } else if (
          effect !== undefined &&
          effect.status !== "reconciled_not_executed"
        ) {
          referenceFailure();
        }
        await validateToolArtifactBytes(
          call,
          binding,
          verifier,
          event.payload.terminal,
          "artifact",
        );
      }
      createObject(state, event.payload.artifactId, binding);
      state.artifacts.set(event.payload.artifactId, binding);
      break;
    }
    case "cache_abi_declared": {
      const manifest = requireArtifact(state, event.payload.manifestArtifactId);
      if (
        manifest.lineageId !== undefined ||
        manifest.runId !== undefined ||
        String(manifest.payload.artifactHash) !==
          String(event.payload.cacheAbiId) ||
        manifest.payload.byteCount !== event.payload.manifestByteCount ||
        manifest.payload.artifactType !== "cache_abi_manifest"
      ) {
        referenceFailure();
      }
      let headerHash: Sha256;
      try {
        const manifestBytes = await verifier.loadArtifact(manifest.payload);
        const loaded = loadCacheAbiV1(
          manifestBytes,
          event.payload.cacheAbiId,
        );
        if (loaded.manifestBytes.byteLength !== event.payload.manifestByteCount) {
          referenceFailure();
        }
        headerHash = loaded.headerHash;
      } catch {
        referenceFailure();
      }
      const binding: CacheAbiBinding = {
        kind: "cache_abi",
        eventId: event.id,
        headerHash,
      };
      createObject(state, event.payload.cacheAbiId, binding);
      if (state.projectInstructionsChange?.phase === "awaiting_abi") {
        state.projectInstructionsChange = Object.freeze({
          phase: "awaiting_activation",
          cacheAbiId: event.payload.cacheAbiId,
        });
      }
      break;
    }
    case "lineage_started":
      requireObject(state, event.payload.cacheAbiId, "cache_abi");
      if (event.lineageId === undefined) referenceFailure();
      createObject(state, event.lineageId, {
        kind: "lineage",
        eventId: event.id,
        cacheAbiId: event.payload.cacheAbiId,
      } as LineageBinding);
      state.lineagePrefixes.set(
        event.lineageId,
        Object.freeze({ nextBlobIndex: 0, chainHash: null }),
      );
      break;
    case "lineage_activated": {
      const next = requireObject(
        state,
        event.payload.nextLineageId,
        "lineage",
      ) as LineageBinding;
      if (state.projectInstructionsChange?.phase === "awaiting_abi") {
        referenceFailure();
      }
      if (
        state.projectInstructionsChange?.phase === "awaiting_activation" &&
        state.projectInstructionsChange.cacheAbiId !== next.cacheAbiId
      ) {
        referenceFailure();
      }
      if (event.payload.reason === "initial") {
        if (
          state.activeLineageId !== undefined ||
          state.pendingAbiChange !== undefined
        ) {
          referenceFailure();
        }
      } else {
        if (
          state.activeLineageId === undefined ||
          event.payload.previousLineageId !== state.activeLineageId
        ) {
          referenceFailure();
        }
        const previous = requireObject(
          state,
          state.activeLineageId,
          "lineage",
        ) as LineageBinding;
        if (
          previous.cacheAbiId === next.cacheAbiId ||
          state.pendingAbiChange?.fromLineageId !==
            event.payload.previousLineageId ||
          state.pendingAbiChange.toLineageId !== event.payload.nextLineageId
        ) {
          referenceFailure();
        }
        state.pendingAbiChange = undefined;
      }
      state.activeLineageId = event.payload.nextLineageId;
      state.projectInstructionsChange = undefined;
      break;
    }
    case "run_started": {
      if (event.lineageId === undefined || event.runId === undefined) {
        referenceFailure();
      }
      requireObject(state, event.lineageId, "lineage");
      if (
        state.activeLineageId !== event.lineageId ||
        state.pendingAbiChange !== undefined ||
        state.projectInstructionsChange !== undefined
      ) {
        referenceFailure();
      }
      if (event.payload.previousRunId !== null) {
        const previous = requireObject(
          state,
          event.payload.previousRunId,
          "run",
        ) as RunBinding;
        if (previous.lineageId !== event.lineageId) referenceFailure();
      } else if (event.payload.cause === "recovery") {
        referenceFailure();
      }
      const binding: RunBinding = {
        kind: "run",
        eventId: event.id,
        lineageId: event.lineageId,
        cause: event.payload.cause,
        previousRunId: event.payload.previousRunId,
      };
      createObject(state, event.runId, binding);
      break;
    }
    case "fact_recorded": {
      const artifact = requireArtifact(state, event.payload.artifactId);
      requireArtifactScope(artifact, event);
      const expectedArtifactType =
        event.payload.kind === "project_instructions"
          ? "project_instructions"
          : "fact";
      if (
        artifact.payload.byteCount !== event.payload.byteCount ||
        artifact.payload.artifactType !== expectedArtifactType ||
        (event.payload.kind === "project_instructions" &&
          (event.lineageId !== undefined || event.runId !== undefined))
      ) {
        referenceFailure();
      }
      if (event.payload.kind === "project_instructions") {
        state.projectInstructionsChange = Object.freeze({
          phase: "awaiting_abi",
        });
      }
      break;
    }
    case "user_committed": {
      const scope = requireRunScope(event);
      if (!hasCommitClosure(state, scope.lineageId)) referenceFailure();
      const sources = requireSourceEvents(
        state,
        event.payload.sourceFactEventIds,
        ["fact_recorded"],
      );
      const expectedOrder = ["user_input", "date", "cwd", "git"] as const;
      const kinds = sources.map((source) => {
        requireEventSameRun(source.event, event);
        return (source.event.payload as JournalPayloadByType["fact_recorded"]).kind;
      });
      const positions = kinds.map((kind) =>
        expectedOrder.indexOf(kind as (typeof expectedOrder)[number]),
      );
      if (
        kinds[0] !== "user_input" ||
        positions.some(
          (position, index) =>
            position < 0 ||
            (index > 0 && position <= (positions[index - 1] ?? -1)),
        )
      ) {
        referenceFailure();
      }
      const bytes = await applyBlob(state, event.lineageId, event.payload, verifier);
      try {
        viewUser(bytes);
      } catch {
        referenceFailure();
      }
      break;
    }
    case "artifact_version_created":
      requireArtifact(state, event.payload.oldArtifactId);
      requireArtifact(state, event.payload.newArtifactId);
      if (event.payload.parentArtifactVersionId !== null) {
        requireObject(
          state,
          event.payload.parentArtifactVersionId,
          "artifact_version",
        );
        const parent = state.artifactVersions.get(
          event.payload.parentArtifactVersionId,
        );
        if (parent?.newArtifactId !== event.payload.oldArtifactId) {
          referenceFailure();
        }
      }
      createObject(state, event.payload.artifactVersionId, {
        kind: "artifact_version",
        eventId: event.id,
      });
      state.artifactVersions.set(
        event.payload.artifactVersionId,
        event.payload,
      );
      break;
    case "request_snapshot_stored": {
      if (
        state.projectInstructionsChange !== undefined ||
        state.pendingAbiChange !== undefined
      ) {
        referenceFailure();
      }
      const scope = requireRunScope(event);
      if (!hasCommitClosure(state, scope.lineageId)) referenceFailure();
      const lineage = requireObject(
        state,
        scope.lineageId,
        "lineage",
      ) as LineageBinding;
      if (lineage.cacheAbiId !== event.payload.cacheAbiId) referenceFailure();
      const cacheAbi = requireObject(
        state,
        event.payload.cacheAbiId,
        "cache_abi",
      ) as CacheAbiBinding;
      const boundary = requireObject(
        state,
        event.payload.commitBoundaryId,
        "commit_boundary",
      ) as BoundaryBinding;
      if (
        boundary.lineageId !== scope.lineageId ||
        event.parentId !== boundary.eventId ||
        event.payload.headEventId !== boundary.eventId ||
        event.payload.segmentHashes[0] !== cacheAbi.headerHash ||
        event.payload.segmentHashes[1] !== boundary.payload.chainHash
      ) {
        referenceFailure();
      }
      if (event.payload.recoveryFromSnapshotId === null) {
        if (
          boundary.runId !== scope.runId ||
          lastAcceptedEvent(state)?.id !== boundary.eventId
        ) {
          referenceFailure();
        }
      } else {
        const source = requireObject(
          state,
          event.payload.recoveryFromSnapshotId,
          "request_snapshot",
        ) as SnapshotBinding;
        const targetRun = requireObject(state, scope.runId, "run") as RunBinding;
        if (
          source.lineageId !== scope.lineageId ||
          source.runId === scope.runId ||
          targetRun.cause !== "recovery" ||
          source.payload.bodyRef !== event.payload.bodyRef ||
          source.payload.bodyHash !== event.payload.bodyHash ||
          source.payload.byteCount !== event.payload.byteCount ||
          source.payload.cacheAbiId !== event.payload.cacheAbiId ||
          source.payload.projectorVersion !== event.payload.projectorVersion ||
          source.payload.headEventId !== event.payload.headEventId ||
          source.payload.commitBoundaryId !== event.payload.commitBoundaryId ||
          source.payload.segmentHashes[0] !== event.payload.segmentHashes[0] ||
          source.payload.segmentHashes[1] !== event.payload.segmentHashes[1]
        ) {
          referenceFailure();
        }
      }
      try {
        await verifier.verifySnapshot(
          event.payload.bodyRef,
          event.payload.bodyHash,
          event.payload.byteCount,
        );
      } catch {
        referenceFailure();
      }
      const binding: SnapshotBinding = {
        kind: "request_snapshot",
        eventId: event.id,
        lineageId: scope.lineageId,
        runId: scope.runId,
        payload: event.payload,
      };
      createObject(state, event.payload.requestSnapshotId, binding);
      break;
    }
    case "request_attempt_started": {
      if (
        state.projectInstructionsChange !== undefined ||
        state.pendingAbiChange !== undefined
      ) {
        referenceFailure();
      }
      const scope = requireRunScope(event);
      if (!hasCommitClosure(state, scope.lineageId)) referenceFailure();
      const snapshot = requireObject(
        state,
        event.payload.requestSnapshotId,
        "request_snapshot",
      ) as SnapshotBinding;
      requireSameRun(snapshot, event);
      const expected =
        (state.snapshotOrdinals.get(event.payload.requestSnapshotId) ?? 0) + 1;
      if (event.payload.ordinal !== expected) referenceFailure();
      state.snapshotOrdinals.set(event.payload.requestSnapshotId, expected);
      const binding: AttemptBinding = {
        kind: "attempt",
        eventId: event.id,
        lineageId: scope.lineageId,
        runId: scope.runId,
        requestSnapshotId: event.payload.requestSnapshotId,
      };
      createObject(state, event.payload.attemptId, binding);
      state.attempts.set(event.payload.attemptId, binding);
      break;
    }
    case "request_semantic_started": {
      const attempt = requireObject(
        state,
        event.payload.attemptId,
        "attempt",
      ) as AttemptBinding;
      requireSameRun(attempt, event);
      if (
        state.semanticAttempts.has(event.payload.attemptId) ||
        state.terminalAttempts.has(event.payload.attemptId)
      ) {
        referenceFailure();
      }
      state.semanticAttempts.add(event.payload.attemptId);
      break;
    }
    case "assistant_committed": {
      const attempt = requireObject(
        state,
        event.payload.attemptId,
        "attempt",
      ) as AttemptBinding;
      const snapshot = requireObject(
        state,
        event.payload.requestSnapshotId,
        "request_snapshot",
      ) as SnapshotBinding;
      if (
        attempt.requestSnapshotId !== event.payload.requestSnapshotId ||
        !(
          attempt.lineageId === snapshot.lineageId &&
          attempt.runId === snapshot.runId
        )
      ) {
        referenceFailure();
      }
      requireSameRun(attempt, event);
      if (
        state.terminalAttempts.has(event.payload.attemptId) ||
        (event.payload.semanticDeltaCount > 0) !==
          state.semanticAttempts.has(event.payload.attemptId)
      ) {
        referenceFailure();
      }
      const bytes = await applyBlob(
        state,
        event.lineageId,
        event.payload,
        verifier,
      );
      let toolCalls: ReturnType<typeof viewAssistant>["toolCalls"];
      try {
        toolCalls = viewAssistant(bytes).toolCalls;
      } catch {
        referenceFailure();
      }
      if (state.pendingToolGroups.has(attempt.lineageId)) referenceFailure();
      const callIds = toolCalls.map((call) => call.id);
      for (const [ordinal, call] of toolCalls.entries()) {
        if (state.toolCalls.has(call.id)) referenceFailure();
        const validation = validateToolArguments(
          call.function.name,
          call.function.arguments,
        );
        state.toolCalls.set(
          call.id,
          Object.freeze({
            id: call.id,
            assistantEventId: event.id,
            lineageId: attempt.lineageId,
            runId: attempt.runId,
            ordinal,
            groupSize: toolCalls.length,
            name: call.function.name,
            argumentsHash: `sha256:${sha256Hex(
              utf8Bytes(call.function.arguments),
            )}` as Sha256,
            validatedArguments: validation.ok ? validation.arguments : undefined,
            validationCode: validation.ok ? undefined : validation.code,
            resultEventId: undefined,
          }),
        );
      }
      if (callIds.length > 0) {
        state.pendingToolGroups.set(
          attempt.lineageId,
          Object.freeze({
            assistantEventId: event.id,
            callIds: Object.freeze(callIds),
            nextResultOrdinal: 0,
          }),
        );
      }
      state.terminalAttempts.add(event.payload.attemptId);
      break;
    }
    case "request_interrupted": {
      const attempt = requireObject(
        state,
        event.payload.attemptId,
        "attempt",
      ) as AttemptBinding;
      const snapshot = requireObject(
        state,
        event.payload.requestSnapshotId,
        "request_snapshot",
      ) as SnapshotBinding;
      if (
        attempt.requestSnapshotId !== event.payload.requestSnapshotId ||
        attempt.lineageId !== snapshot.lineageId ||
        attempt.runId !== snapshot.runId
      ) {
        referenceFailure();
      }
      requireSameRun(attempt, event);
      if (state.terminalAttempts.has(event.payload.attemptId)) referenceFailure();
      const semanticStarted = state.semanticAttempts.has(event.payload.attemptId);
      if (
        (event.payload.semanticState === "pre_semantic" && semanticStarted) ||
        (event.payload.semanticState === "post_semantic" && !semanticStarted)
      ) {
        referenceFailure();
      }
      state.terminalAttempts.add(event.payload.attemptId);
      break;
    }
    case "cache_checkpoint_created": {
      const scope = requireRunScope(event);
      const snapshot = requireObject(
        state,
        event.payload.requestSnapshotId,
        "request_snapshot",
      ) as SnapshotBinding;
      requireSameRun(snapshot, event);
      const sourceBinding = requireEvent(
        state,
        event.payload.sourceAssistantEventId,
        ["assistant_committed"],
      );
      requireEventSameRun(sourceBinding.event, event);
      {
        const source = sourceBinding.event
          .payload as JournalPayloadByType["assistant_committed"];
        if (
          source.requestSnapshotId !== event.payload.requestSnapshotId ||
          source.providerRequestId !== event.payload.providerRequestId ||
          source.usage.promptTokens !== event.payload.promptTokens ||
          source.blobIndex + 1 !== event.payload.blobCount ||
          source.chainHash !== event.payload.chainHash ||
          state.checkpointSources.has(event.payload.sourceAssistantEventId)
        ) {
          referenceFailure();
        }
      }
      const prefix = activePrefix(state, scope.lineageId).prefix;
      if (
        event.payload.blobCount !== prefix.nextBlobIndex ||
        event.payload.chainHash !== prefix.chainHash
      ) {
        referenceFailure();
      }
      const binding: CheckpointBinding = {
        kind: "cache_checkpoint",
        eventId: event.id,
        lineageId: scope.lineageId,
        runId: scope.runId,
      };
      createObject(state, event.payload.cacheCheckpointId, binding);
      state.checkpointSources.add(event.payload.sourceAssistantEventId);
      break;
    }
    case "commit_boundary_created": {
      const scope = requireRunScope(event);
      if (event.payload.cacheCheckpointId !== null) {
        const checkpoint = requireObject(
          state,
          event.payload.cacheCheckpointId,
          "cache_checkpoint",
        ) as CheckpointBinding;
        if (checkpoint.lineageId !== scope.lineageId) referenceFailure();
      }
      const sources = requireSourceEvents(state, event.payload.sourceEventIds);
      for (const source of sources) {
        requireSameLineage(scope.lineageId, source.event);
      }
      const prefix = activePrefix(state, scope.lineageId).prefix;
      if (
        event.payload.blobCount !== prefix.nextBlobIndex ||
        event.payload.chainHash !== prefix.chainHash ||
        !hasCommitClosure(state, scope.lineageId)
      ) {
        referenceFailure();
      }
      const binding: BoundaryBinding = {
        kind: "commit_boundary",
        eventId: event.id,
        lineageId: scope.lineageId,
        runId: scope.runId,
        payload: event.payload,
      };
      createObject(state, event.payload.commitBoundaryId, binding);
      break;
    }
    case "cache_break":
      if (event.payload.classification === "planned") {
        const from = requireObject(
          state,
          event.payload.fromLineageId,
          "lineage",
        ) as LineageBinding;
        const to = requireObject(
          state,
          event.payload.toLineageId,
          "lineage",
        ) as LineageBinding;
        if (
          state.pendingAbiChange !== undefined ||
          state.activeLineageId !== event.payload.fromLineageId ||
          from.cacheAbiId === to.cacheAbiId ||
          state.projectInstructionsChange?.phase === "awaiting_abi" ||
          (state.projectInstructionsChange?.phase === "awaiting_activation" &&
            state.projectInstructionsChange.cacheAbiId !== to.cacheAbiId)
        ) {
          referenceFailure();
        }
        state.pendingAbiChange = Object.freeze({
          fromLineageId: event.payload.fromLineageId,
          toLineageId: event.payload.toLineageId,
        });
      } else {
        requireArtifact(state, event.payload.diffArtifactId);
      }
      break;
    case "integrity_violation":
      if (event.payload.relatedEventId !== null) {
        requireEvent(state, event.payload.relatedEventId);
      }
      break;
    case "permission_decided": {
      const toolCall = state.toolCalls.get(event.payload.toolCallId);
      if (
        toolCall === undefined ||
        toolCall.resultEventId !== undefined ||
        toolCall.validatedArguments === undefined ||
        state.permissions.has(event.payload.toolCallId) ||
        !isCanonicalPermission(event.payload)
      ) {
        referenceFailure();
      }
      requireBindingLineage(toolCall, event);
      state.permissions.set(
        event.payload.toolCallId,
        Object.freeze({
          eventId: event.id,
          finalDecision: event.payload.finalDecision,
        }),
      );
      break;
    }
    case "effect_prepared": {
      const scope = requireRunScope(event);
      const toolCall = state.toolCalls.get(event.payload.toolCallId);
      const permission = state.permissions.get(event.payload.toolCallId);
      const previousEffectId = state.activeEffectsByCall.get(
        event.payload.toolCallId,
      );
      const previousEffect =
        previousEffectId === undefined
          ? undefined
          : state.effects.get(previousEffectId);
      if (
        toolCall === undefined ||
        toolCall.resultEventId !== undefined ||
        toolCall.validatedArguments === undefined ||
        toolCall.validatedArguments.name === "read" ||
        toolCall.validatedArguments.name !== event.payload.toolName ||
        toolCall.argumentsHash !== event.payload.argumentsHash ||
        permission?.finalDecision !== "allow" ||
        (previousEffect !== undefined &&
          !(
            previousEffect.status === "reconciled_not_executed" &&
            previousEffect.runId !== scope.runId
          ))
      ) {
        referenceFailure();
      }
      requireBindingLineage(toolCall, event);
      const binding: EffectBinding = {
        kind: "effect",
        eventId: event.id,
        lineageId: scope.lineageId,
        runId: scope.runId,
        toolCallId: event.payload.toolCallId,
        toolName: event.payload.toolName,
        status: "prepared",
        outputArtifactId: undefined,
        terminalEventId: undefined,
      };
      createObject(state, event.payload.effectId, binding);
      state.effects.set(event.payload.effectId, binding);
      state.activeEffectsByCall.set(
        event.payload.toolCallId,
        event.payload.effectId,
      );
      break;
    }
    case "effect_completed": {
      const effect = requireObject(
        state,
        event.payload.effectId,
        "effect",
      ) as EffectBinding;
      if (
        effect.toolCallId !== event.payload.toolCallId ||
        effect.status !== "prepared"
      ) {
        referenceFailure();
      }
      requireSameRun(effect, event);
      const artifact = requireToolOutputArtifact(
        state,
        event.payload.artifactId,
      );
      requireArtifactScope(artifact, event);
      const call = state.toolCalls.get(event.payload.toolCallId);
      if (
        call === undefined ||
        artifact.payload.toolCallId !== event.payload.toolCallId ||
        artifact.payload.terminal !== null ||
        effect.toolName !== requiredToolName(call)
      ) {
        referenceFailure();
      }
      await validateToolArtifactBytes(
        call,
        artifact,
        verifier,
        event.payload.terminal,
        "effect",
      );
      replaceEffect(
        state,
        event.payload.effectId,
        Object.freeze({
          ...effect,
          status: "completed",
          outputArtifactId: event.payload.artifactId,
          terminalEventId: event.id,
        }),
      );
      break;
    }
    case "effect_indeterminate": {
      const effect = requireObject(
        state,
        event.payload.effectId,
        "effect",
      ) as EffectBinding;
      if (effect.status !== "prepared") referenceFailure();
      requireBindingLineage(effect, event);
      replaceEffect(
        state,
        event.payload.effectId,
        Object.freeze({ ...effect, status: "indeterminate" }),
      );
      break;
    }
    case "effect_reconciled": {
      const effect = requireObject(
        state,
        event.payload.effectId,
        "effect",
      ) as EffectBinding;
      if (effect.status !== "indeterminate") referenceFailure();
      requireBindingLineage(effect, event);
      const recoveryScope = requireRunScope(event);
      const recoveryRun = requireObject(
        state,
        recoveryScope.runId,
        "run",
      ) as RunBinding;
      if (recoveryRun.cause !== "recovery") referenceFailure();
      const evidence = requireArtifact(state, event.payload.evidenceArtifactId);
      requireArtifactScope(evidence, event);
      if (evidence.payload.artifactType !== "operator_evidence") {
        referenceFailure();
      }
      if (event.payload.resolution === "completed") {
        const output = requireToolOutputArtifact(
          state,
          event.payload.outputArtifactId,
        );
        requireArtifactScope(output, event);
        const call = state.toolCalls.get(effect.toolCallId);
        if (
          call === undefined ||
          output.payload.toolCallId !== effect.toolCallId ||
          output.payload.terminal !== null ||
          effect.toolName !== requiredToolName(call)
        ) {
          referenceFailure();
        }
        await validateToolArtifactBytes(
          call,
          output,
          verifier,
          event.payload.terminal,
          "effect",
        );
      }
      replaceEffect(
        state,
        event.payload.effectId,
        Object.freeze({
          ...effect,
          status:
            event.payload.resolution === "completed"
              ? "reconciled_completed"
              : "reconciled_not_executed",
          outputArtifactId:
            event.payload.resolution === "completed"
              ? event.payload.outputArtifactId
              : undefined,
          terminalEventId: event.id,
        }),
      );
      break;
    }
    case "tool_result_committed": {
      const toolCall = state.toolCalls.get(event.payload.toolCallId);
      const group =
        toolCall === undefined
          ? undefined
          : state.pendingToolGroups.get(toolCall.lineageId);
      if (
        toolCall === undefined ||
        group === undefined ||
        toolCall.resultEventId !== undefined ||
        group.assistantEventId !== toolCall.assistantEventId ||
        group.callIds[group.nextResultOrdinal] !== event.payload.toolCallId ||
        toolCall.ordinal !== group.nextResultOrdinal
      ) {
        referenceFailure();
      }
      requireBindingLineage(toolCall, event);
      const source = requireEvent(state, event.payload.sourceEventId);
      const activeEffectId = state.activeEffectsByCall.get(
        event.payload.toolCallId,
      );
      let resultArtifact: ArtifactBinding | undefined;
      let resultTerminal: ToolTerminal | undefined;
      let staticContent: StaticToolResultContent | undefined;
      if (event.payload.effectId !== null) {
        const effect = requireObject(
          state,
          event.payload.effectId,
          "effect",
        ) as EffectBinding;
        if (
          effect.toolCallId !== event.payload.toolCallId ||
          activeEffectId !== event.payload.effectId ||
          (effect.status !== "completed" &&
            effect.status !== "reconciled_completed") ||
          event.payload.artifactId === null ||
          effect.outputArtifactId !== event.payload.artifactId ||
          effect.terminalEventId !== event.payload.sourceEventId ||
          (effect.status === "completed" &&
            (source.type !== "effect_completed" ||
              (source.event.payload as JournalPayloadByType["effect_completed"])
                .effectId !== event.payload.effectId)) ||
          (effect.status === "reconciled_completed" &&
            (source.type !== "effect_reconciled" ||
              (source.event.payload as JournalPayloadByType["effect_reconciled"])
                .effectId !== event.payload.effectId))
        ) {
          referenceFailure();
        }
        requireBindingLineage(effect, event);
        resultArtifact = requireToolOutputArtifact(
          state,
          event.payload.artifactId,
        );
        if (
          resultArtifact.payload.toolCallId !== event.payload.toolCallId ||
          resultArtifact.payload.terminal !== null
        ) {
          referenceFailure();
        }
        if (source.type === "effect_completed") {
          resultTerminal = (
            source.event.payload as JournalPayloadByType["effect_completed"]
          ).terminal;
        } else if (
          source.type === "effect_reconciled" &&
          (source.event.payload as JournalPayloadByType["effect_reconciled"])
            .resolution === "completed"
        ) {
          resultTerminal = (
            source.event.payload as Extract<
              JournalPayloadByType["effect_reconciled"],
              { readonly resolution: "completed" }
            >
          ).terminal;
        } else {
          referenceFailure();
        }
      } else if (event.payload.artifactId !== null) {
        const activeEffect =
          activeEffectId === undefined ? undefined : state.effects.get(activeEffectId);
        if (
          activeEffect !== undefined &&
          activeEffect.status !== "reconciled_not_executed"
        ) {
          referenceFailure();
        }
        resultArtifact = requireToolOutputArtifact(
          state,
          event.payload.artifactId,
        );
        if (
          source.type !== "artifact_published" ||
          (source.event.payload as JournalPayloadByType["artifact_published"])
            .artifactId !== event.payload.artifactId ||
          resultArtifact.payload.toolCallId !== event.payload.toolCallId ||
          resultArtifact.payload.terminal === null
        ) {
          referenceFailure();
        }
        requireArtifactScope(resultArtifact, event);
        resultTerminal = resultArtifact.payload.terminal;
      } else {
        const activeEffect =
          activeEffectId === undefined ? undefined : state.effects.get(activeEffectId);
        if (
          activeEffect !== undefined &&
          activeEffect.status !== "reconciled_not_executed"
        ) {
          referenceFailure();
        }
        if (
          source.type === "permission_decided" &&
          (source.event.payload as JournalPayloadByType["permission_decided"])
            .toolCallId === event.payload.toolCallId &&
          (source.event.payload as JournalPayloadByType["permission_decided"])
            .finalDecision === "deny" &&
          toolCall.validationCode === undefined
        ) {
          staticContent = Object.freeze({
            kind: "static",
            status: "denied",
            code: "permission_denied",
          });
        } else if (
          source.type === "assistant_committed" &&
          source.event.id === toolCall.assistantEventId &&
          toolCall.validationCode !== undefined
        ) {
          staticContent = Object.freeze({
            kind: "static",
            status: "invalid",
            code: toolCall.validationCode,
          });
        } else {
          referenceFailure();
        }
      }
      const bytes = await applyBlob(state, event.lineageId, event.payload, verifier);
      try {
        if (bytes.byteLength > TOOL_RESULT_PROJECTION_LIMIT_BYTES) {
          referenceFailure();
        }
        const view = viewTool(bytes);
        if (view.toolCallId !== event.payload.toolCallId) {
          referenceFailure();
        }
        parseToolResultContent(view.content);
        let expected: FrozenBytes;
        if (staticContent !== undefined) {
          expected = materializeToolResultMessage(
            event.payload.toolCallId,
            staticContent,
          );
        } else {
          if (resultArtifact === undefined || resultTerminal === undefined) {
            referenceFailure();
          }
          const streamBytes = resultArtifact.payload.streamBytes;
          const hardLimitReached = resultArtifact.payload.hardLimitReached;
          if (streamBytes === null || hardLimitReached === null) referenceFailure();
          const offset = readOffset(toolCall);
          const projector = createArtifactToolResultProjector({
            toolCallId: event.payload.toolCallId,
            toolName: requiredToolName(toolCall),
            terminalSource: event.payload.effectId === null
              ? "artifact"
              : "effect",
            ...(offset === undefined ? {} : { readOffset: offset }),
            artifact: {
              artifactId: resultArtifact.payload.artifactId,
              artifactRef: resultArtifact.payload.artifactRef,
              artifactSha256: resultArtifact.payload.artifactHash,
              byteCount: resultArtifact.payload.byteCount,
              payloadBytes: streamBytes,
              hardLimitReached,
            },
            terminal: resultTerminal,
          });
          await verifier.scanArtifact(
            resultArtifact.payload,
            (artifactBytes) => projector.push(artifactBytes),
          );
          expected = projector.finish().messageBytes;
        }
        if (!bytesEqual(bytes, expected)) referenceFailure();
      } catch {
        referenceFailure();
      }
      state.toolCalls.set(
        event.payload.toolCallId,
        Object.freeze({ ...toolCall, resultEventId: event.id }),
      );
      const nextResultOrdinal = group.nextResultOrdinal + 1;
      if (nextResultOrdinal === group.callIds.length) {
        state.pendingToolGroups.delete(toolCall.lineageId);
      } else {
        state.pendingToolGroups.set(
          toolCall.lineageId,
          Object.freeze({ ...group, nextResultOrdinal }),
        );
      }
      break;
    }
    case "run_completed": {
      const boundary = requireObject(
        state,
        event.payload.commitBoundaryId,
        "commit_boundary",
      ) as BoundaryBinding;
      requireSameRun(boundary, event);
      const source = requireEvent(state, event.payload.sourceAssistantEventId, [
        "assistant_committed",
      ]).event;
      requireEventSameRun(source, event);
      break;
    }
    case "run_interrupted":
      requireEvent(state, event.payload.sourceEventId);
      break;
    case "journal_tail_recovered":
      if (
        event.payload.validPrefixSeq !== event.seq - 1 ||
        event.payload.validPrefixHash !== event.prevHash
      ) {
        referenceFailure();
      }
      if (state.recoveryHashes.has(event.payload.recoveryHash)) {
        referenceFailure();
      }
      if (physical === undefined) referenceFailure();
      try {
        await verifier.verifyRecovery(
          event.payload,
          event.sessionId,
          physical.validPrefixByteCount,
        );
      } catch {
        referenceFailure();
      }
      state.recoveryHashes.add(event.payload.recoveryHash);
      break;
  }

  state.events.set(event.id, { type: event.type, event });
}

export class JournalBindingProjection implements JournalAppendPreflight {
  readonly #verifier: JournalReferenceVerifier;
  #state: BindingState;
  #generation = 0;

  constructor(verifier: JournalReferenceVerifier) {
    this.#verifier = verifier;
    this.#state = emptyState();
  }

  async prepare(
    event: AnyVerifiedJournalEvent,
    physical?: JournalPhysicalContext,
  ): Promise<PreparedJournalAppend> {
    const generation = this.#generation;
    const candidate = cloneState(this.#state);
    await applyEvent(candidate, event, this.#verifier, physical);
    let committed = false;
    return {
      commit: () => {
        if (committed || this.#generation !== generation) referenceFailure();
        committed = true;
        this.#state = candidate;
        this.#generation += 1;
      },
    };
  }

  async accept(
    event: AnyVerifiedJournalEvent,
    physical?: JournalPhysicalContext,
  ): Promise<void> {
    const prepared = await this.prepare(event, physical);
    prepared.commit();
  }

  snapshot(): BindingProjectionSnapshot {
    const prefix =
      this.#state.activeLineageId === undefined
        ? undefined
        : this.#state.lineagePrefixes.get(this.#state.activeLineageId);
    return Object.freeze({
      sessionId: this.#state.sessionId,
      eventCount: this.#state.events.size,
      objectCount: this.#state.objects.size,
      blobCount: prefix?.nextBlobIndex ?? 0,
      chainHash: prefix?.chainHash ?? null,
      eventIds: Object.freeze([...this.#state.events.keys()]),
      objectIds: Object.freeze([...this.#state.objects.keys()]),
    });
  }
}
