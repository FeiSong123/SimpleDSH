import assert from "node:assert/strict";
import test from "node:test";

import { sha256Hex } from "../../src/bytes/ops.js";
import { CANONICAL_TOOLS_BYTES } from "../../src/bytes/schemas.js";
import { utf8View } from "../../src/bytes/view.js";
import {
  toolNames,
  validateToolArguments,
  validateToolCall,
} from "../../src/tool/validate.js";
import type {
  StaticToolValidationCode,
  ToolName,
  ValidatedToolArguments,
} from "../../src/tool/validate.js";

function json(value: unknown): string {
  const encoded = JSON.stringify(value);
  if (encoded === undefined) throw new TypeError("test value is not JSON");
  return encoded;
}

function expectSuccess(
  name: ToolName,
  argumentsText: string,
): ValidatedToolArguments {
  const result = validateToolArguments(name, argumentsText);
  if (!result.ok) {
    assert.fail(`${name} unexpectedly failed with ${result.code}`);
  }
  assert.equal(result.arguments.name, name);
  assert.equal(Object.isFrozen(result), true);
  assert.equal(Object.isFrozen(result.arguments), true);
  assert.equal(Object.isFrozen(result.arguments.value), true);
  return result.arguments;
}

function expectFailure(
  name: string,
  argumentsText: string,
  code: StaticToolValidationCode = "invalid_arguments",
): void {
  const result = validateToolArguments(name, argumentsText);
  if (result.ok) assert.fail(`${name} unexpectedly accepted ${argumentsText}`);
  assert.equal(result.code, code);
  assert.equal(Object.isFrozen(result), true);
}

function providerToolName(value: unknown): string {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    assert.fail("provider tool must be an object");
  }
  const providerFunction = (value as Record<string, unknown>)["function"];
  if (
    typeof providerFunction !== "object" ||
    providerFunction === null ||
    Array.isArray(providerFunction)
  ) {
    assert.fail("provider function must be an object");
  }
  const name = (providerFunction as Record<string, unknown>)["name"];
  if (typeof name !== "string") assert.fail("provider tool name must be a string");
  return name;
}

test("provider-visible tool schema bytes and sorted validator order stay frozen", () => {
  assert.deepEqual(toolNames, ["bash", "edit", "read", "write"]);
  assert.equal(Object.isFrozen(toolNames), true);
  assert.equal(CANONICAL_TOOLS_BYTES.byteLength, 1_190);
  assert.equal(
    sha256Hex(CANONICAL_TOOLS_BYTES),
    "2cab77d4184a9839e7c432d160b2edb39a0fdfa69fb8b56754d67c89765fae12",
  );

  const providerTools: unknown = JSON.parse(utf8View(CANONICAL_TOOLS_BYTES));
  if (!Array.isArray(providerTools)) assert.fail("provider tools must be an array");
  assert.deepEqual(providerTools.map(providerToolName), toolNames);
});

test("failure codes distinguish JSON syntax from arguments and unknown tool wins first", () => {
  for (const name of toolNames) {
    expectFailure(name, "{", "invalid_json");
    expectFailure(name, "null");
    expectFailure(name, "[]");
    expectFailure(name, json("scalar"));
  }

  expectFailure("unknown", "{", "unknown_tool");
  expectFailure("unknown", json({}), "unknown_tool");
  expectFailure("", "not JSON", "unknown_tool");

  const validCall = validateToolCall({
    id: "call-validator-1",
    function: { name: "read", arguments: json({ path: "README.md" }) },
  });
  assert.deepEqual(validCall, {
    ok: true,
    toolCallId: "call-validator-1",
    arguments: {
      name: "read",
      value: { path: "README.md", offset: 0, limit: 200 },
    },
  });
  assert.equal(Object.isFrozen(validCall), true);

  assert.deepEqual(
    validateToolCall({
      id: "call-validator-2",
      function: { name: "read", arguments: "{" },
    }),
    { ok: false, toolCallId: "call-validator-2", code: "invalid_json" },
  );
  assert.deepEqual(
    validateToolCall({
      id: "call-validator-3",
      function: { name: "missing", arguments: "{" },
    }),
    { ok: false, toolCallId: "call-validator-3", code: "unknown_tool" },
  );
  assert.throws(
    () =>
      validateToolCall({
        id: "",
        function: { name: "missing", arguments: "{" },
      }),
    /tool call id/u,
  );
});

test("read validator closes keys, applies defaults, and enforces integer bounds", () => {
  assert.deepEqual(expectSuccess("read", json({ path: "目录/🙂.txt" })), {
    name: "read",
    value: { path: "目录/🙂.txt", offset: 0, limit: 200 },
  });
  assert.deepEqual(
    expectSuccess(
      "read",
      json({
        limit: 2_000,
        path: "file.txt",
        offset: Number.MAX_SAFE_INTEGER,
      }),
    ),
    {
      name: "read",
      value: {
        path: "file.txt",
        offset: Number.MAX_SAFE_INTEGER,
        limit: 2_000,
      },
    },
  );
  assert.deepEqual(
    expectSuccess("read", json({ path: "file.txt", offset: 0, limit: 1 })),
    {
      name: "read",
      value: { path: "file.txt", offset: 0, limit: 1 },
    },
  );

  for (const value of [
    {},
    { offset: 0 },
    { path: "file.txt", extra: true },
    { path: "file.txt", offset: 0, limit: 1, extra: true },
  ]) {
    expectFailure("read", json(value));
  }
  for (const offset of [
    -1,
    0.5,
    Number.MAX_SAFE_INTEGER + 1,
    "0",
    null,
  ]) {
    expectFailure("read", json({ path: "file.txt", offset }));
  }
  for (const limit of [
    -1,
    0,
    1.5,
    2_001,
    Number.MAX_SAFE_INTEGER + 1,
    "1",
    null,
  ]) {
    expectFailure("read", json({ path: "file.txt", limit }));
  }
  for (const path of ["", "a\0b", "\ud800", "\udfff", 1, null]) {
    expectFailure("read", json({ path }));
  }
});

test("write validator requires exact keys while allowing empty scalar content", () => {
  assert.deepEqual(
    expectSuccess("write", '{"content":"","path":"目录/🙂.txt"}'),
    {
      name: "write",
      value: { path: "目录/🙂.txt", content: "" },
    },
  );
  assert.deepEqual(
    expectSuccess("write", json({ path: "file.txt", content: "内容🙂" })),
    {
      name: "write",
      value: { path: "file.txt", content: "内容🙂" },
    },
  );

  for (const value of [
    {},
    { path: "file.txt" },
    { content: "content" },
    { path: "file.txt", content: "content", extra: false },
  ]) {
    expectFailure("write", json(value));
  }
  for (const path of ["", "a\0b", "\ud800", "\udfff", 1, null]) {
    expectFailure("write", json({ path, content: "content" }));
  }
  for (const content of ["a\0b", "\ud800", "\udfff", 1, null]) {
    expectFailure("write", json({ path: "file.txt", content }));
  }
});

test("edit validator maps exact snake-case keys and enforces field-specific emptiness", () => {
  assert.deepEqual(
    expectSuccess(
      "edit",
      json({
        path: "目录/🙂.txt",
        old_string: "old🙂",
        new_string: "",
        replace_all: false,
      }),
    ),
    {
      name: "edit",
      value: {
        path: "目录/🙂.txt",
        oldString: "old🙂",
        newString: "",
        replaceAll: false,
      },
    },
  );

  const base = {
    path: "file.txt",
    old_string: "old",
    new_string: "new",
    replace_all: true,
  };
  for (const value of [
    {},
    { ...base, old_string: undefined },
    { ...base, extra: true },
  ]) {
    expectFailure("edit", json(value));
  }
  for (const path of ["", "a\0b", "\ud800", "\udfff", 1, null]) {
    expectFailure("edit", json({ ...base, path }));
  }
  for (const old_string of ["", "a\0b", "\ud800", "\udfff", 1, null]) {
    expectFailure("edit", json({ ...base, old_string }));
  }
  for (const new_string of ["a\0b", "\ud800", "\udfff", 1, null]) {
    expectFailure("edit", json({ ...base, new_string }));
  }
  for (const replace_all of [0, 1, "true", null]) {
    expectFailure("edit", json({ ...base, replace_all }));
  }
});

test("bash validator closes keys, defaults timeout, and accepts only finite 0 < t <= 600", () => {
  assert.deepEqual(expectSuccess("bash", json({ command: "pwd🙂" })), {
    name: "bash",
    value: { command: "pwd🙂", timeoutSeconds: 120 },
  });
  assert.deepEqual(
    expectSuccess("bash", json({ timeout: 0.25, command: "pwd" })),
    {
      name: "bash",
      value: { command: "pwd", timeoutSeconds: 0.25 },
    },
  );
  assert.deepEqual(
    expectSuccess("bash", json({ command: "pwd", timeout: 600 })),
    {
      name: "bash",
      value: { command: "pwd", timeoutSeconds: 600 },
    },
  );

  for (const value of [
    {},
    { timeout: 1 },
    { command: "pwd", extra: true },
  ]) {
    expectFailure("bash", json(value));
  }
  for (const command of ["", "a\0b", "\ud800", "\udfff", 1, null]) {
    expectFailure("bash", json({ command }));
  }
  for (const timeout of [-1, 0, 600.000_001, "1", null]) {
    expectFailure("bash", json({ command: "pwd", timeout }));
  }
  expectFailure("bash", '{"command":"pwd","timeout":1e309}');
});
