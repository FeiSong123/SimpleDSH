import { strictEqual } from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { dirname, resolve } from "node:path";
import { test } from "node:test";
import { fileURLToPath } from "node:url";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..", "..");

function runNode(args: readonly string[]) {
  return spawnSync(process.execPath, args, {
    cwd: projectRoot,
    encoding: "utf8",
    env: {},
    timeout: 5_000,
  });
}

test("compiled CLI remains blocked until Stage 06", () => {
  const result = runNode([resolve(projectRoot, "dist/src/cli.js")]);

  strictEqual(result.error, undefined);
  strictEqual(result.signal, null);
  strictEqual(result.status, 2);
  strictEqual(result.stdout, "");
  strictEqual(result.stderr, "BLOCKED: Stage 06\n");
});

test("blocked-stage helper reports the requested stage", () => {
  const result = runNode([
    resolve(projectRoot, "scripts/blocked-stage.mjs"),
    "Stage 02",
  ]);

  strictEqual(result.error, undefined);
  strictEqual(result.signal, null);
  strictEqual(result.status, 2);
  strictEqual(result.stdout, "");
  strictEqual(result.stderr, "BLOCKED: Stage 02\n");
});
