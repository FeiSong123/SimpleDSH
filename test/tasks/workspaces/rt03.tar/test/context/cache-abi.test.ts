import assert from "node:assert/strict";
import test from "node:test";

import {
  buildCacheAbiV1,
  loadCacheAbiV1,
  MODEL_TUPLE_BYTES,
  PROJECTOR_VERSION_V1,
  PROTOCOL_VERSION_V1,
} from "../../src/lineage/cache-abi.js";
import {
  bytesEqual,
  concatBytes,
  lengthPrefix,
  sha256Hex,
  utf8Bytes,
} from "../../src/bytes/ops.js";
import { CANONICAL_TOOLS_BYTES } from "../../src/bytes/schemas.js";
import {
  BASE_SYSTEM_MESSAGE_BYTES,
  BASE_SYSTEM_PROMPT,
} from "../../src/bytes/system.js";
import { freezeBytes, type FrozenBytes } from "../../src/bytes/types.js";
import { utf8View } from "../../src/bytes/view.js";
import type { CacheAbiId } from "../../src/journal/types.js";

const DOMAIN = new TextEncoder().encode("dsh-cache-abi-v1\0");

function idFor(bytes: FrozenBytes): CacheAbiId {
  return `sha256:${sha256Hex(bytes)}` as CacheAbiId;
}

function framePayloadOffsets(bytes: FrozenBytes): readonly number[] {
  const source = bytes.copy();
  const offsets: number[] = [];
  let offset = DOMAIN.byteLength;
  for (let index = 0; index < 5; index += 1) {
    const length = Number(
      new DataView(source.buffer, source.byteOffset + offset, 8).getBigUint64(
        0,
        false,
      ),
    );
    offset += 8;
    offsets.push(offset);
    offset += length;
  }
  return Object.freeze(offsets);
}

test("base Cache ABI manifest freezes exact v1 fields and outward bytes", () => {
  const built = buildCacheAbiV1();
  const rebuilt = buildCacheAbiV1();
  const loaded = loadCacheAbiV1(built.manifestBytes, built.cacheAbiId);

  assert.equal(built.protocolVersion, PROTOCOL_VERSION_V1);
  assert.equal(built.projectorVersion, PROJECTOR_VERSION_V1);
  assert.equal(
    utf8View(MODEL_TUPLE_BYTES),
    '{"model":"deepseek-v4-flash","thinking":{"type":"enabled"},"reasoning_effort":"max"}',
  );
  assert.equal(bytesEqual(built.systemBlob, BASE_SYSTEM_MESSAGE_BYTES), true);
  assert.equal(bytesEqual(built.toolsBlob, CANONICAL_TOOLS_BYTES), true);
  assert.equal(bytesEqual(loaded.manifestBytes, built.manifestBytes), true);
  assert.equal(loaded.cacheAbiId, built.cacheAbiId);
  assert.equal(loaded.headerHash, built.headerHash);
  assert.equal(rebuilt.cacheAbiId, built.cacheAbiId);
  assert.equal(bytesEqual(rebuilt.manifestBytes, built.manifestBytes), true);
  assert.equal(
    built.cacheAbiId,
    "sha256:3813964e24ba27d336a87eb35e08c01091c887665e673acbe6b9bb4d3d464533",
  );
  assert.equal(
    built.headerHash,
    "sha256:33a24d401390430f87efef9f9136c8200ec6998ad53266ec85102349f8de2ef1",
  );
  assert.equal(built.manifestBytes.byteLength, 1_601);
  assert.equal(buildCacheAbiV1(utf8Bytes("")).cacheAbiId, built.cacheAbiId);
  assert.equal(Object.isFrozen(built), true);

  const exposed = built.manifestBytes.copy();
  exposed[0] = exposed[0] === 0 ? 1 : 0;
  assert.equal(loadCacheAbiV1(built.manifestBytes, built.cacheAbiId).cacheAbiId, built.cacheAbiId);
});

test("Unicode project instructions deterministically create a distinct Cache ABI", () => {
  const projectInstructions = utf8Bytes("规则🙂\ne\u0301 与 中\n不要改写历史");
  const first = buildCacheAbiV1(projectInstructions);
  const second = buildCacheAbiV1(projectInstructions);
  const base = buildCacheAbiV1();

  assert.equal(first.cacheAbiId, second.cacheAbiId);
  assert.equal(first.headerHash, second.headerHash);
  assert.equal(bytesEqual(first.manifestBytes, second.manifestBytes), true);
  assert.notEqual(first.cacheAbiId, base.cacheAbiId);
  assert.notEqual(first.headerHash, base.headerHash);
  assert.equal(
    first.cacheAbiId,
    "sha256:50727208a2e5e4cf24fbf3bd310be89284a4446eff3d154477ab195858f1f2f4",
  );
  assert.match(utf8View(first.systemBlob), /规则🙂\\né 与 中/u);
  assert.equal(
    loadCacheAbiV1(first.manifestBytes, first.cacheAbiId).cacheAbiId,
    first.cacheAbiId,
  );
});

test("Cache ABI mutation rejects hash-valid non-canonical system JSON", () => {
  const nonCanonicalSystem = utf8Bytes(
    `{"role":"system", "content":${JSON.stringify(BASE_SYSTEM_PROMPT)}}`,
  );
  const bytes = concatBytes([
    DOMAIN,
    lengthPrefix(utf8Bytes(PROTOCOL_VERSION_V1)),
    lengthPrefix(utf8Bytes(PROJECTOR_VERSION_V1)),
    lengthPrefix(MODEL_TUPLE_BYTES),
    lengthPrefix(nonCanonicalSystem),
    lengthPrefix(CANONICAL_TOOLS_BYTES),
  ]);

  assert.throws(
    () => loadCacheAbiV1(bytes, idFor(bytes)),
    /does not round-trip canonically/u,
  );
});

test("Cache ABI mutation rejects hash-valid non-canonical domain and fields", () => {
  const built = buildCacheAbiV1();
  const offsets = framePayloadOffsets(built.manifestBytes);
  for (const [label, offset] of [
    ["protocol", offsets[0]],
    ["projector", offsets[1]],
    ["model", offsets[2]],
    ["system", offsets[3]],
    ["tools", offsets[4]],
  ] as const) {
    assert.notEqual(offset, undefined);
    const mutated = built.manifestBytes.copy();
    const concreteOffset = offset as number;
    mutated[concreteOffset] = (mutated[concreteOffset] ?? 0) ^ 1;
    const bytes = freezeBytes(mutated);
    assert.throws(() => loadCacheAbiV1(bytes, idFor(bytes)), TypeError, label);
  }

  const wrongDomain = built.manifestBytes.copy();
  wrongDomain[0] = (wrongDomain[0] ?? 0) ^ 1;
  const wrongDomainBytes = freezeBytes(wrongDomain);
  assert.throws(
    () => loadCacheAbiV1(wrongDomainBytes, idFor(wrongDomainBytes)),
    /wrong domain/u,
  );
});

test("Cache ABI loader rejects identity mismatch, every truncation, and trailing bytes", () => {
  const built = buildCacheAbiV1();
  assert.throws(
    () =>
      loadCacheAbiV1(
        built.manifestBytes,
        `sha256:${"0".repeat(64)}` as CacheAbiId,
      ),
    /hash does not match/u,
  );

  const source = built.manifestBytes.copy();
  for (let byteLength = 0; byteLength < source.byteLength; byteLength += 1) {
    const truncated = freezeBytes(source.slice(0, byteLength));
    assert.throws(
      () => loadCacheAbiV1(truncated, idFor(truncated)),
      TypeError,
      `truncation at ${byteLength}`,
    );
  }

  const trailing = concatBytes([built.manifestBytes, new Uint8Array([0])]);
  assert.throws(
    () => loadCacheAbiV1(trailing, idFor(trailing)),
    /trailing bytes/u,
  );
});

test("Cache ABI loader rejects unsafe u64 lengths before allocation", () => {
  const built = buildCacheAbiV1();
  const unsafe = built.manifestBytes.copy();
  unsafe.fill(0xff, DOMAIN.byteLength, DOMAIN.byteLength + 8);
  const bytes = freezeBytes(unsafe);
  assert.throws(() => loadCacheAbiV1(bytes, idFor(bytes)), /length is unsafe/u);
});

test("Cache ABI builder and loader reject invalid UTF-8 system instructions", () => {
  assert.throws(
    () => buildCacheAbiV1(freezeBytes(new Uint8Array([0xff]))),
    TypeError,
  );
});
