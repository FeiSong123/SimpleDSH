# dsh Engineering Spec

**DeepSeek 专属 Agent Harness · 设计契约 v0.1**

> 这份文档是契约，代码跟随它。要改行为，先改契约。
>
> 开发期唯一模型：`deepseek-v4-flash`
> 固定推理元组：`thinking = enabled`，`reasoning_effort = max`
> 唯一目标端点：`POST https://api.deepseek.com/chat/completions`（OpenAI 格式）
> 事实核对日期：2026-08-03（价格与能力见附录 A，全部带日期）
> DeepSeek 同时存在 Responses API、Anthropic API 与 Pro 产品，但它们都不属于 SimpleDSH v0.1 的可达路径。

---

## 0. 一句话架构命题

> **系统里最重要的对象不是 agent loop，不是 tool registry，而是「发给 DeepSeek 的那串字节」。**
>
> 核心复杂性只花在三件事上：**字节前缀的只追加性**、**reasoning_content 的原样往返**、**turn 的字节级可恢复性**。其余一切——plan、todo、sub-agent、routing、bot、gateway、桌面端——都不进核心。

这不是「极简主义偏好」，而是 DeepSeek V4 的价格结构与 API 契约共同强制的结果。第 1、2 节给出强制的依据。

**设计哲学的三条来源，各取其一：**

- 来自 Pi：harness 不是第二个智能体；提供原语而非 feature；状态外置为 artifact；只为通用不变量支付核心复杂性。
- 来自 Reasonix：cache-first 作为架构第一约束；单静态二进制、依赖近零；DeepSeek 原生协议与前缀稳定性优先。
- 来自 Maka：LLM Backend、运行时与日志之间保持清晰边界；认证、传输、流、取消、错误与 usage 集中收口；append-only 日志是唯一真相、其余皆为投影；遥测 best-effort，永不阻塞关键路径。

三者都被大幅裁剪。第 15 节列出明确拒绝的部分及理由。

---

## 1. 设计前提：DeepSeek V4 的硬约束

这一节是全部设计的事实基线。每一条都直接推出一条架构决策。

| # | 事实 | 推出的决策 |
|---|---|---|
| F1 | 上下文 1M，最大输出 384K | **压缩不是容量问题，是成本问题**。见 §2.1 |
| F2 | 开发期固定模型 flash 的缓存命中 / 未命中价差为 **50×** | 前缀稳定性是第一成本杠杆，压倒任何 prompt 优化 |
| F3 | 因 Sliding Window Attention，每个缓存前缀是**独立完整单元**，命中要求**完全匹配**某个单元 | 只追加，不改写。中途改历史 = 该点之后全部作废 |
| F4 | 每个请求在「用户输入结束位置」与「模型输出结束位置」各产生一个缓存前缀单元；另有跨请求公共前缀检测、长文本按固定 token 间隔切分 | 完整请求结束可记录 **Cache Checkpoint**；它只表示 best-effort 复用资格，不等于可恢复或可供未来 lineage capability 使用的 **Commit Boundary**（§3、§8.3） |
| F5 | 缓存构建需要**数秒**；best-effort，不保证命中；不用时数小时到数天后清除 | 工具循环里的子请求可能来不及命中新单元 → 少而大的往返优于多而小的往返；不为未准入的 fan-out 预写调度器 |
| F6 | v0.1 不假设不同模型之间可复用缓存；Cache ABI 保守地包含 wire model id | 开发期模型是冻结常量；不实现模型切换、路由或跨模型 fork（§2.2），因此无需也不得用 Pro 做跨模型探测 |
| F7 | 思考模式下，若该 assistant 轮**执行过 tool call**，其 `reasoning_content` 必须完整回传，否则 **HTTP 400** | 这是唯一值得进核心的 DeepSeek 专属正确性不变量（不变量 2） |
| F8 | 思考模式不支持 `temperature` / `top_p` / `presence_penalty` / `frequency_penalty`，设置了不报错也无效 | 这些参数不出现在代码里。见 §6.1 |
| F9 | flash 官方支持 `low` / `high` / `max`，默认 `thinking=enabled`、effort=high；SimpleDSH 开发期仍显式发送 enabled + max | 不依赖 Provider 默认值，不在 prompt 里写推理脚手架，不提供 effort 配置 |
| F10 | 高压时不一定返回 429，而是保持连接：非流式持续返回空行，流式持续返回 SSE 注释 `: keep-alive`；若 10 分钟仍未开始推理，服务端关闭连接；自行解析 HTTP 的客户端必须处理 | 连接、首个语义 delta 与流内语义 idle 分开计时（不变量 6）。这是「不用 SDK」的明码标价 |
| F11 | flash 账号级并发上限为 2500；超限返回 429 | 每 Session provider attempt 串行；进程级有界 semaphore 遇 429 收紧，不追逐账号上限 |
| F12 | 即将实施高峰/低谷定价：高峰期（北京时间 9:00–12:00、14:00–18:00）价格翻倍，生效日期待官方公告 | 价格表是带日期的配置数据，永不硬编码 |

---

## 2. 成本与血统模型

这三条是本设计与「通用 harness 移植到 DeepSeek」的全部差异所在。

### 2.1 未来 Compaction 的经济准入下界

设 `r = P_miss / P_hit`，压缩后保留比例 `ρ = M / N`。压缩每轮省下 `(N−M) × P_hit`，一次性代价是新前缀冷启动 `M × P_miss`。盈亏平衡所需的后续请求数：

```
K ≥ ρ(r − 1) / (1 − ρ)
```

| 固定模型 | 保留 20% | 保留 30% | 保留 50% |
|---|---|---|---|
| `deepseek-v4-flash`（r = 50） | K ≥ 12 | K ≥ 21 | K ≥ 49 |

这只是 Stage 09 是否值得立项的经济模型，不是 v0.1 baseline 的功能契约。准入审计使用以下规则：

1. 压缩阈值由「剩余工作量估计」驱动，**不是**固定的窗口占用比例。1M 窗口下你几乎永远不会被容量迫使压缩。
2. 任务接近结束时**永不压缩**。
3. 一个 session 里压缩超过一次，基本都是设计失败，应触发告警。
4. v0.1 baseline 没有 `/compact`、自动 trigger 或配置；证据满足后必须先冻结具体交互与 bytes，再实现。

参照量级：一个 300K 前缀的会话跑 100 次请求，按 flash 当前价格，全部命中约 **$0.084**，全部未命中约 **$4.20**。这个 50 倍差距是整个缓存架构的经济基础。

### 2.2 固定模型元组，而不是模型路由

开发期的 Provider 可见模型元组冻结为：

```text
model = deepseek-v4-flash
thinking.type = enabled
reasoning_effort = max
```

这三个值是 Cache ABI 的一部分，是代码中的冻结常量，不是 TOML、CLI、环境变量或 Extension 配置。运行时没有模型选择、preset、自动路由、升级按钮或跨模型 fork。

`deepseek-v4-flash` 是当前官方 wire model ID；“latest”指始终发送这个官方维护的 ID，而不是在客户端抓取模型列表后动态改写请求。事实核对日官方显示其 resolved version 为 `DeepSeek-V4-Flash-0731`，但该 resolved version 不写入请求。每次响应都记录 `response.model` 与 `system_fingerprint`，用于识别官方 ID 背后的版本漂移，但绝不据此自动路由或修改当前血统。

**推论 A：压缩摘要必须使用同一模型元组在同一血统上生成。** 这样读取整段旧历史仍走命中价；摘要完成后才建立新血统。

**推论 B：不存在“临时切 Pro”或“降低 effort 省钱”。** 这类变化会改变输出分布、实验基线和缓存身份，开发期在数据模型里不可表达。

**推论 C：未来若改变任一值，必须先修订本契约、更新 golden request 与 Cache ABI 版本，再创建新血统。** 这不是一次普通配置变更。

### 2.3 「极简 system prompt」的成本理由不成立，稳定性理由成立

5K tokens 的 system prompt 在 flash 命中价下是 `5000 × 2.8e-9 ≈ $0.000014/请求`。**省不出钱。**

所以 Pi 的两条理由里，「省 token」这条在 DeepSeek 上死掉了，「认知税」这条活着，并且多了一条更硬的：**字节稳定性**。由此得到最高杠杆的 prompt 布局规则（§9）：

```
冻结区（永不变，在最前）: system + tool schemas
易变区（每轮新增，在最后）: 日期 / cwd / git status / 环境摘要
```

**关键区分：「易变」不等于「可变」。** 每轮的环境摘要是一个**新的、追加的、此后不再变**的块。放在开头会让整个前缀每轮重算；在本轮新 user blob 的唯一首次 materialization 时把它放在尾部，得到的是一次追加而不是对既有消息的修改，完全不破坏缓存。

### 2.4 工具输出的真实代价

> 工具输出不是一条消息，它是一笔永久账单。一旦追加，此后每次请求都被重新计价，且**无法在不破坏缓存的情况下撤回**。

诚实地说：钱不多。50K tokens 的输出，在 flash 上后续 100 轮的命中成本约 $0.014，加一次 miss 约 $0.007。**真正的代价是它把你推向压缩事件，而压缩才是唯一昂贵的事**，其次是延迟与注意力稀释。

这是 §10.3「工具输出预算」存在的理由——执行边界按 bytes 硬限制，模型投影按 bytes 有界；Provider token 用量事后观测。它是稳定性与上下文成本不变量，不是便利功能。

---

## 3. 核心概念

四个词，整个系统都由它们定义。

### blob（冻结字节块）

provider 可见的 messages 数组的一个元素，**以它产生那一刻的最终序列化字节形式存储，此后永不重新序列化**。

```
请求体的 messages 字段 = "[" + join(blob.bytes, ",") + "]"
```

语义视图（TUI 渲染、搜索、投影）**只解析，从不重新生成**。

这一个决策同时消灭四类 bug：

| 问题 | 为什么消失 |
|---|---|
| `reasoning_content` 回传导致 400 | SSE 累计 semantic value 只 canonical materialize 一次；此后复用同一 FrozenBytes，字段值与 JSON 转义形式都不再漂移 |
| 意外前缀抖动（map 顺序、浮点格式、字段顺序） | 结构上不可能发生，不依赖纪律 |
| 恢复后重建出不同字节，静默丢缓存 | 恢复 = 重放 blob |
| 前缀哈希计算 | 就是 blob 的滚动哈希 |

### Cache ABI 与 lineage（血统）

```text
project_instruction_snapshot = lineage 创建前登记的 exact bytes（没有时是固定空块）
system blob = canonical_system(base_system_bytes, project_instruction_snapshot)
LP(x) = u64be(byte_length(x)) ‖ x
header_bytes = LP(system blob) ‖ LP(tools blob)（顺序确定、字节冻结）
cache_abi_manifest_bytes =
  "dsh-cache-abi-v1\0" ‖
  LP(protocol_version) ‖ LP(projector_version) ‖
  LP(canonical_development_model_tuple) ‖
  LP(system blob) ‖ LP(tools blob)
cache_abi_id = H(cache_abi_manifest_bytes)

lineage = {
  lineage_id,              # lineage_started 写入的唯一 opaque id；不从 ABI 推导
  cache_abi_id
}
```

v1 的三个版本字段不是配置，exact bytes 固定为：

```text
protocol_version = "dsh-protocol-v1"
projector_version = "dsh-projector-v1"
canonical_development_model_tuple =
  {"model":"deepseek-v4-flash","thinking":{"type":"enabled"},"reasoning_effort":"max"}
```

`LP` 的长度是其后 payload 的 unsigned 64-bit big-endian **byte** count；域标签和长度前缀使相邻字段不可通过重新分割产生同一 hash 输入。manifest loader 必须按上述域序解析至 EOF，拒绝 trailing bytes、错误版本/模型元组、非 canonical system message 或不同的 tools bytes；恢复不能只相信文件名 hash。项目指令由 Session Kernel 在创建 ABI/Lineage 前读取为 exact UTF-8 bytes，先作为 immutable Artifact/fact durable，再由唯一 canonical system serializer 放进 system blob；Projector 不自行读取项目文件。v0.1 baseline 没有 Skills index 字段或空占位。**Cache ABI 与 Lineage 是不同 branded identity**；baseline 只暴露 initial/ABI-change activation，不暴露 same-ABI child/branch API。未来若获准复用同一 ABI，Lineage id 仍必须独立并由显式事实创建。

修改 system/project 指令、工具 schema/顺序、协议或 Projector，会产生新的 `cache_abi_id`、attributed planned `cache_break` 与新 Lineage；未来经契约修订后的模型元组同理，但模型元组在 v0.1 运行时没有修改入口。不变量 1 因此由独立的 ABI 身份、唯一 Lineage 身份与只追加事实共同保证。

血统内的 blob 列表**只能追加**。

### Cache Checkpoint 与 Commit Boundary

二者是不同类型，不能互换：

```text
cache_checkpoint = {
  id, lineage_id, request_snapshot_id, blob_count, chain_hash,
  prompt_tokens, provider_request_id, at
}

commit_boundary = {
  id, lineage_id, cache_checkpoint_id?, blob_count, chain_hash,
  protocol_closed: true, effects_settled: true, at
}
```

完整 Provider 请求结束后可记录 `CacheCheckpoint`。由 F4，它标识一段可能被 DeepSeek best-effort 复用的前缀，只是性能事实；它可能仍位于 tool-call episode 中间，不能单独用于恢复或任何未来 lineage-changing capability。

只有当所选前缀不存在 partial response 或未配对 tool call、所有 Effect 均 `completed` 或已显式 reconcile 后，才能记录 `CommitBoundary`。它与 Provider 请求是否刚结束无关：新 user blob 首次提交后、完整 tool-result 批次提交后，以及无 tool call 的最终 assistant 提交后，都应立即在安全条件成立时记录。尚无对应 Provider 结果时 `cache_checkpoint_id` 为空；这正是两种边界不能混同的原因。恢复只以 `CommitBoundaryId` 证明安全；任何未来获准的 lineage-changing capability 也只能引用这种边界，并可声明更强前置条件。这与 Architecture Charter 对缓存价值和副作用安全的区分完全一致。

### cache break（缓存断裂）

一次请求的前缀不是上一次请求前缀的追加扩展。每个 discontinuity 都必须在发送前 durable 追加一个 `cache_break`，payload 固定区分：

- `classification=planned`：已审查的冻结区/ABI 变化或未来已获准能力。顺序固定为需要时先 `cache_abi_declared` → `lineage_started` 分配 to-Lineage id → `cache_break(planned, from/to, reason, authorizedRevision)` → `lineage_activated` → `run_started`；event 不引用尚未创建的身份。
- `classification=unplanned`：serializer/Projector/恢复漂移等 bug，记录 diff 摘要与 `run_interrupted` 后**拒绝发送**，不得把它伪装成新 Session 或 provider miss。

成本账本分别计数；CI 固定会话只断言 `unplanned_cache_break_count == 0`，planned break 保留可见事实而不与 bug 混算。模型元组变更不属于 v0.1 运行时操作。

### 核心身份与生命周期

以下身份都是不可互换的 opaque id；除 `CacheAbiId` 外都由对应的 start/create 事实分配，不能从内容哈希推导：

| 对象 | 创建事实 | 生命周期与硬规则 |
|---|---|---|
| `Session` | `session_started` | 用户可见持久任务容器；恰有一个权威 Journal，可包含多个 Lineage 和 Run |
| `CacheAbi` | `cache_abi_declared` | 冻结模型元组、协议/Projector 版本、system/project 指令和工具 schema/顺序的内容身份 |
| `Lineage` | `lineage_started` | 独立、只追加的活动历史；引用一个 Cache ABI；v0.1 baseline 不含 parent/fork 字段 |
| `Run` | `run_started` | 一次具体执行尝试；恰好属于一个 Session/Lineage；以 `run_completed` 或 `run_interrupted` 闭合；恢复总是新建 Run，同一 Lineage 上继续 durable pending tail |
| `RequestSnapshot` | `request_snapshot_stored` | 某个 Run 的一次完整、模型可见 HTTP body 字节；发送前持久化；normal physical retry 只按原 id 读回同一字节。恢复进入新 Run 时，若旧 Snapshot 已存在，只能创建逐字段复用旧 body/hash 的 alias，不能重新 materialize；若安全 Commit Boundary 后从未产生 Snapshot，恢复 Run 可从该 Boundary 首次调用 Projector 恰好一次并写入 `recoveryFromSnapshotId=null` 的普通 Snapshot，此后任何再次恢复都转入前述 alias 规则 |
| `Artifact` | `artifact_published` | content-addressed 原始证据；在引用事件之前 durable；不可改写 |
| `ArtifactVersion` | `artifact_version_created` | 用户编辑显式产生的新 Artifact 与父版本引用；旧版本保持可回放 |
| `Effect` | `effect_prepared` | 仅 T2；一次可能改变外部世界的尝试；由 `effect_completed` 或显式 reconcile 闭合 |

父子关系固定为：`Session → {Lineage, Run}`、`Lineage → Run`、`Run → RequestSnapshot/physical attempts/Effects`。不同的初始 Session 可以各自创建引用同一 Cache ABI 的独立 Lineage，但 Cache ABI 不是它们的父对象；v0.1 不提供从既有 Lineage 创建 child/sibling 的操作。任何投影、UI 或内存对象都不是额外身份来源。

---

## 4. 八条核心不变量

> 除这八条，什么都不进核心。每一条都必须满足：几乎所有工作流都需要、无法用已有原语或 extension 合理实现、涉及顺序/持久化/恢复/协议兼容等系统级正确性。

**不变量 1 — 字节只追加。**
血统内 blob 列表严格只追加。Cache ABI 身份由冻结区、版本与完整 `development_model_tuple` 决定；Lineage 身份来自唯一 `lineage_started` 事实。同 ABI 可以创建多个不同 Lineage，冻结区改变则必须创建新 ABI 与新 Lineage；开发期模型元组没有修改入口。任何非「新血统」的前缀断裂都是显式 `cache_break` 事件，可计数、CI 可断言为 0。

**不变量 2 — reasoning 原子性。**
带 `tool_calls` 的 assistant blob 与其 `reasoning_content` **同生共死**：要么作为一个完整 blob 提交，要么只丢弃尚未提交的 staging bytes。已经进入 Journal 的事实绝不删除、截断或改写；绝不拆开、绝不摘要、绝不重新序列化。
推论：任何未来获准的 compaction 只能落在完整 episode 边界；episode 从一个 user blob 起，到下一个 user blob 之前结束，不能切开 assistant/tool-call/results 原子组。

**不变量 3 — 工具结果完备有序。**
完整 assistant 可以先作为 durable 非 Commit tail 提交。每个 `tool_call` 必须在**下一次模型请求或 Commit Boundary 之前**有且仅有一条 `tool_call_id` 匹配的 tool blob，顺序与 `tool_calls` 一致；pending call 是恢复状态，不是允许跳过的闭合状态。

**不变量 4 — 可恢复到字节级。**
日志必须足以重建**逐字节相同**的请求，而非仅重建语义历史。恢复后字节不同 = 静默丢缓存，或直接 400。

**不变量 5 — 中断一致性。**
取消/崩溃时，一轮的产物要么作为完整单元提交，要么只放弃未提交 staging，并以 `request_interrupted` 闭合 physical attempt。pre-semantic 且可重试的 attempt 可以在同一 Run 内启动下一 physical attempt；其他失败追加 `run_interrupted`。完整 assistant 的 pending tool calls 留在同一 append-only Lineage，由恢复的新 Run 按 Effect 事实继续；绝不回退或跳过 durable tail。不得在结果未齐时创建下一 Request Snapshot/Commit Boundary，绝不提交半条 blob。

**不变量 6 — 排队语义与 keep-alive 解析（双超时）。**
由 F10。SSE 解析器必须跳过空行与 `:` 开头的注释行且不计入 idle。必须区分两种超时：

```
connect / TTFB 超时       — 上界较大（排队可能很久）；keep-alive 不延长绝对上界
流内 semantic idle 超时   — 上界较小；只由语义 delta 重置，keep-alive 不重置任何产品计时器
```

单一超时值在这里必错：把排队当挂死，会在高峰期（也就是价格翻倍、你最需要它稳定的时段）把 harness 变成不可用。

**不变量 7 — 按错误码分类的重试，且 payload 字节不变。**

```
400 / 422  → 请求本身错，绝不重试。
             必须触发一次「前缀完整性自检」（§7.3）并写入日志。
             reasoning_content 缺失、tool_call_id 不匹配、孤儿 tool blob
             全部落在这里。这是唯一需要盯的类别。
401 / 402  → 凭据 / 余额。立刻停。
429        → 并发闸门收紧 + 指数退避 + jitter；有 Retry-After 则尊重。
500 / 503  → 有界退避重试。
timeout    → 只有尚无任何语义 delta 时才可把它当软信号并重试同一 Snapshot。
```

**重试必须重发完全相同的字节，永不重新构造请求。** 冻结字节设计免费给了这个性质；而在 DeepSeek 上它还有额外好处——重发的 payload 是完整前缀，极可能整段命中，所以固定 flash 基线下的命中输入单价约为未命中的 1/50。任何「重试时顺手重建一下 messages」的实现，都会把便宜的重试变成一次全额 miss。

`reasoning_content`、`content` 或任意 tool-call delta 都是语义 delta。接收第一份语义 delta 时，必须先 durable 追加 `request_semantic_started`，再把该 delta 放入 staging 或暴露 preview。出现第一份语义 delta 后，任何断流、timeout 或取消都必须追加 `request_interrupted` 与 `run_interrupted`，不得在同一 Run 内透明重放；后续继续只能创建新 Run，从已证明安全的 Commit Boundary 投影。进程崩溃留下未闭合 attempt 时，无论是否已看到 `request_semantic_started` 都保守地闭合旧 attempt/Run 并创建新 Run；这不是同 Run 的透明重试。

**不变量 8 — 副作用失败关闭。**
`write`、`edit` 与任意 `bash` 都是 T2 effect，不做命令文本“看起来只读”的猜测。它们只能按模型声明顺序串行经过：

```text
validated + allowed
→ durable effect_prepared
→ external effect
→ raw Artifact durable
→ durable effect_completed + tool_result_committed
```

`effect_prepared` 已 durable 但没有 `effect_completed` 时，恢复只能追加 `effect_indeterminate` 并停止。只有带操作者证据的 `effect_reconciled` 才能把它判为 `completed` 或 `proven_not_executed`；Harness 不声称 rollback 或 exactly-once，也不因“可能幂等”而盲重试。`read` 是唯一 T1 observational primitive；它不写 `effect_prepared`，但仍必须产生 Artifact 与恰好一个有界 tool result。

`bash` 的进程清理观察不改变这条 crash truth：一旦直接子进程终态和原始输出已经取得并 durable，`effect_completed` 必须记录该终态；原进程组/双 stdio EOF 的有界观察另记为 `descendantsReaped:boolean`。`false` 说明 Harness 没有观察到完整回收，不等于 effect 结果未知，也不得产生 `effect_indeterminate`。只有 prepared 后缺 completed、文件发布状态未知、Artifact/Journal durability 失败或 integrity failure 才保持 fail closed；同用户原生执行本来就不承诺收容 `setsid`、double-fork 或对抗性进程。

### 4.1 验收与优化顺序

所有设计和发布决策固定按以下字典序比较，不能混成总分：

1. 协议、恢复、Journal、Artifact、Effect、凭据处理与诚实执行边界全部通过；
2. 固定真实任务 suite 的 pass@1；
3. 质量相同时的 uncached input tokens/task；
4. 质量与 token 成本相同时的 wall-clock，queue wait 单列。

低优先级改善永远不能抵偿高优先级退化。

---

## 5. 系统结构与技术选型

### 5.1 语言：TypeScript

**选择 TypeScript。理由是团队与生态，不是技术表达力。**

三个参考项目的语言构成本身就是最好的论据：**Pi 是 TypeScript**（npm `@earendil-works/pi-coding-agent`，扩展就是 TS 模块），**Maka 是 TypeScript**（Electron + npm workspaces），**Reasonix 从 TypeScript 重写成了 Go**（0.x 的 TS 代码库退到 `v1` 分支仅维护，1.0 起是 Go 的 `main-v2`）。

从这三个事实里能读出的结论：

1. **这份 spec 打底的哲学（Pi）是用 TypeScript 实现的。** 四个工具、最短 system prompt、artifact 外置状态、extension 承载偏好——全部在 TS 上做到了。
2. **Reasonix 的 Go 重写没有阻止功能膨胀，反而加速了**（Go 版内建了 subagents、plan mode、CodeGraph、三档 approval posture——正是 §15 逐条拒绝的东西）。语言不保护你，纪律保护你。
3. **分发不构成 Go 的独占优势。** Reasonix 自己的迁移文档说明：npm 仍是主渠道，包只是包裹预编译二进制，npm 只是安装器而非运行时依赖。反向同样成立——Bun `--compile` 让 TS 也能出单文件可执行。

所以承重的决策不是语言，是 §4 的八条不变量。**语言选择的唯一意义是：谁能维护它、多快能改。** 既然团队是 TS-first，并且给 Pi 写扩展的经验可以直接迁移，TS 是对的。

代价是真实的，见 §5.4。它们不是抽象风险，是六个具体的、会破坏具体不变量的坑，必须逐个用测试钉住。

### 5.2 运行时与分发契约

```
运行时     Node ≥ 22 LTS（依赖的能力：node:https / AbortSignal /
           TextDecoder / node:test / structuredClone）
类型       严格模式，noUncheckedIndexedAccess，exactOptionalPropertyTypes
构建       tsc → ESM，target 与运行时对齐；不打包（唯一 TOML 依赖由 npm 精确锁定）
分发       主渠道 npm；可选 bun build --compile 产出单文件可执行
测试       node:test，零测试框架依赖
```

**运行时依赖：一个：精确锁定的 `smol-toml@1.7.1`。** 2026-08-03 从 npm registry 核对为零传递依赖、无 install lifecycle script；Stage 01 必须把 registry integrity 与 shrinkwrap 一起锁定。开发依赖只有精确锁定的 `typescript`、`@types/node`。HTTP/SSE、schema、进程和测试不再引入依赖。

刻意没有的依赖，每条都有具体理由：

| 不用 | 理由 |
|---|---|
| OpenAI SDK / Vercel AI SDK / 任何 LLM SDK | 我们需要 `reasoning_content` 字节级原样往返、`thinking` 作为顶层字段、`prompt_cache_hit_tokens` 直读、自己处理 keep-alive。Maka 的多 Provider SDK 层服务于不同产品目标，不进入本项目 |
| 任何 SSE / eventsource 库 | 不变量 6 要求解析器**看见**空行与 `:` 注释；库会替你吞掉（§5.4 坑 2、3） |
| **Zod 或任何 schema 生成器** | tool schema 在冻结区。生成器版本升级会改字节 → cache break。四个 schema 手写为冻结字面量，校验器手写（§5.4 坑 4） |
| Ink / 任何 TUI 框架 | v1 的 TUI 只需要三件事：流式追加、底部状态行、模态审批。为此引入 reconciler 不划算。手写 ANSI + `node:readline` |
| tree-kill / execa / 任何进程库 | PGID TERM→KILL、stdio 背压与 cleanup observation 是不变量 5 的核心，必须自己拿在手里并测试（§5.4 坑 5） |

### 5.3 目录结构

```
dsh/
├── package.json              # 运行时依赖：仅 TOML 解析
├── npm-shrinkwrap.json       # 随包发布，锁定传递依赖（照抄 Pi 的做法）
├── tsconfig.json
├── dsh.example.toml
├── dev/docs/dsh-spec.md      # 唯一 canonical Engineering Spec；不得复制第二份
└── src/
    ├── cli/         # 子命令、TUI、退出码
    ├── session/     # 唯一 Run/模型—工具闭环与 Commit Boundary 协调
    ├── ds/          # 唯一的 DeepSeek 客户端：请求契约 / SSE / 错误码 / usage
    ├── bytes/       # FrozenBytes、字节拼接/哈希；Stage 02 建立并拥有协议期接口
    ├── journal/     # 单 writer、append/fsync、replay、torn-tail/corruption
    ├── artifact/    # content-addressed 原始证据与显式版本
    ├── blob/        # Stage 03 接管的冻结 blob 存储 + 前缀账本
    ├── lineage/     # 事件、CacheCheckpoint/CommitBoundary、活动 Lineage 与恢复
    ├── ctx/         # 冻结区构造、易变尾块、纯 Projector
    ├── tool/        # 四原语 + ToolRuntime 单一收口
    ├── proc/        # 子进程生命周期：PGID cleanup/观察、stdio 背压   ← TS 新增模块
    ├── permission/  # 纯策略：规则即数据，无 I/O
    └── cost/        # 价格表、账本、SLI
```

依赖方向（无环，用检查脚本强制）：

```
cli → session → {lineage, ctx, tool, cost, ds}
{session, lineage, ctx, tool, cost, ds} → {journal, artifact, blob, bytes}
tool → {permission, proc}
permission / proc / journal / artifact / blob / bytes 不反向依赖任何上层模块
```

共享字节所有权也按阶段冻结：Stage 02 在 `src/bytes/**` 建立 `FrozenBytes`、request serializer、system/tool schema bytes 与 golden hash；Stage 03 不改这些 provider-visible bytes，只在 `src/blob/**`、`src/journal/**`、`src/artifact/**` 持久化它们；Stage 05 只实现与 Stage 02 schema 一致的 validator/runtime。任何 schema byte 变化都回到 Cache ABI 契约与独立审查，不由 Stage 05 顺手修改。

`src/proc/` 是相对 Go 版本新增的模块——在 Go 里 `context.Context` → `exec.CommandContext` 是一条直线，在 Node 里 PGID TERM→KILL、cleanup observation 与 stdio 背压必须自己写，所以它值得独立成模块并单独测试（§16 用例 7）。

### 5.4 TypeScript 特有的六个坑

> 每一个都会破坏一条具体的不变量。每一个都必须有对应的测试或 lint 规则。这一节是把 §5.1 承认的代价明码标价。

**坑 1 — 任何 `JSON.parse` → `JSON.stringify` 往返都会破坏不变量 4。**

这是最容易犯、后果最重的一个。缓解手段是双层的：

```ts
// src/bytes/types.ts
export class FrozenBytes {
  readonly #bytes: Uint8Array;
  private constructor(source: Uint8Array);
  static copyOf(source: Uint8Array): FrozenBytes;
  get byteLength(): number;
  copy(): Uint8Array; // 永远返回 defensive copy
}
```

**blob 的规范形式是拥有私有 `Uint8Array` backing 的 opaque `FrozenBytes`，不是 `string`，也不是带 brand 后继续外泄的可变 typed-array。** 构造时复制 source；对象不暴露 `buffer` / `subarray` / `set` 等共享或可变入口；需要交给 `node:https`、hash 或 durable store 时只取得 defensive copy。仅冻结外层 Snapshot 对象不够，因为 `Object.freeze` 不会冻结内部 typed-array 元素。这既是 Go `json.RawMessage` 的字节语义，也是 JS 上真正保证重试 payload 不漂移的必要边界，并顺带消掉坑 3 的一半（JS 字符串是 UTF-16，孤立代理项经 `TextEncoder` 会被替换成 U+FFFD，哈希与字节双双漂移）。

配套的检查规则：**`src/bytes/view.ts` 与显式命名的只读 view/invariant 文件之外，任何文件禁止对 `FrozenBytes` 调用 `JSON.parse`。** 解析只用于渲染与不变量检查，永不用于重建请求。

请求体的组装因此是**字节拼接，不是对象序列化**：

```ts
// 正确：messages 数组以原始字节拼接
const body = concatBytes([
  enc('{"model":"deepseek-v4-flash","messages":['),
  joinBytes(blobs, enc(',')),
  enc('],"tools":'), frozenToolsBytes,
  enc(',"stream":true,"stream_options":{"include_usage":true},"thinking":{"type":"enabled"},"reasoning_effort":"max","max_tokens":65536}'),
]);

// 错误：这会把所有 blob 重新序列化一遍
const body = JSON.stringify({ model, messages: blobs.map(b => JSON.parse(dec(b))), ... });
```

**坑 2 — Node 全局 `fetch` 的隐含 undici 超时不可作为本项目契约。**

Node 的全局 `fetch` 由内置 undici 实现，但内置版本随 Node patch 变化，而且不能作为 `node:` 模块导入来配置 dispatcher；2026-08-03 在本机 Node v26.0.0 上 `process.versions.undici == 8.0.2`，而 `import('undici')` 仍以 `ERR_MODULE_NOT_FOUND` 失败。另装 undici 会同时违反单一运行时依赖预算，并把 300 秒级 `headersTimeout` / `bodyTimeout` 默认带进 F10 的最长 10 分钟排队窗口。

因此 v0.1 的唯一 transport 是 `src/ds` 内直接使用 `node:https.request` 的一个具体函数；不使用全局 `fetch`，也不增加 HTTP client abstraction 或依赖。它显式拥有：

```text
connect_timeout       — TCP/TLS 建连上界；到点 destroy request
ttfb_timeout          — 从发送到第一个语义 delta 的绝对上界，默认 620s；
                        空行与 : keep-alive 都不重置
semantic_idle_timeout — 第一个语义 delta 后启用，默认 90s；
                        仅 reasoning/content/tool-call delta 重置
AbortSignal           — abort 时 destroy request/socket；错误归因到调用者取消
```

Node 文档明确 `request.setTimeout()` 只发出事件、不会自动 abort，所以实现必须在 timer callback 主动 `destroy()`；测试使用本地 TLS/HTTP fixture 和注入到同一具体 transport seam 的 request function，不引入第二种 backend。Stage 02 只开放必须显式注入 request function 的离线 fixture seam；默认 `node:https.request` 的真实出站入口不可调用。Stage 06 只有在 durable `request_snapshot_stored` / `request_attempt_started` 与下述 semantic barrier 接好后，才把这个同一具体实现接到默认官方发送路径。这个决定消除了 undici blocker，同时保留不变量 6 必需的全部字节可见性和 Stage 06 前的零生产出站。

**坑 3 — `TextDecoder` 在 chunk 边界切断多字节字符。**

SSE 必须按**字节**切行（`0x0A`），而不是先 decode 成字符串再 split。多字节 UTF-8 字符会跨 chunk 边界，一次性 decode 会产出替换字符。若确实要 decode，必须用 `new TextDecoder('utf-8')` 并全程 `{ stream: true }`。

同时必须处理 `\r\n` 与 `\n` 两种行尾。§16 用例 4 的 fixture 必须包含「在一个中文字符中间切开」的 chunk。

**坑 4 — schema 生成器的版本升级 = cache break。**

tool schema 在冻结区（§9.1），字节变了就是新血统。Zod → JSON Schema 的转换结果依赖 Zod 与转换器的版本；一次 `npm update` 就可能悄悄改掉 `additionalProperties` 的位置或 `required` 的顺序，于是所有人的会话缓存在某次升级后集体归零，而且没人知道为什么。

**四个工具的 JSON Schema 手写为冻结字面量，参数校验器手写。** 四个工具的校验逻辑总共一百行量级，比引入这个风险便宜。

并且加一条测试：**冻结区字节的 golden hash 断言。** 任何改动 system prompt 或 tool schema 的 PR 都必须显式更新这个 hash——让「我要开一条新血统」成为一个需要签字的动作，而不是副作用。

**坑 5 — 子进程组清理与 stdio 背压。**

不变量 5 最脏的部分。macOS 与 Linux 的 v0.1 只使用同一个原生 PGID runner：

```ts
const child = spawn('/bin/bash', ['--noprofile', '--norc', '-lc', cmd], {
  detached: true,          // 建立进程组，便于 TERM→KILL；不能阻止 setsid 逃逸
  stdio: ['ignore', 'pipe', 'pipe'],
  env: closedChildEnvironment,
});
// 超时 / abort 时：
process.kill(-child.pid!, 'SIGTERM');
setTimeout(() => process.kill(-child.pid!, 'SIGKILL'), graceMs);
```

停止顺序固定为 TERM → bounded grace → KILL；随后在有界观察窗内做 negative-PGID probe 并等待 stdout/stderr 双 EOF。两项都观察到时记 `descendantsReaped=true`，否则为 `false`；无论哪一种，直接子进程已有终态后都按其真实 terminal 完成 Effect。这个字段只描述 Harness 对**原进程组与继承 pipe**的观察，不能探测已经 `setsid`/double-fork 且关闭 stdio 的进程，因此不得表述为 descendant containment 或安全保证。Windows v0.1 的 `bash` 明确 unavailable，不实现或宣称 `taskkill` 隔离路径。

macOS/Linux 的这条路径不得探测或依赖 Lima、containerd、nerdctl、runc、RootlessKit、镜像 digest、mount/inode admission 或任何可选 backend。受支持平台安装后直接调用 `/bin/bash`；此前验证过的 Linux 虚拟机方案因不可分发而放弃，见 §11.2。

背压与输出预算是同一件事：**必须按字节计数读 stdout/stderr，达到 `raw_output_hard_limit_bytes` 立刻杀进程并落盘**，否则一条 `yes` 或一个刷屏的构建就能把 harness 拖到 OOM。这把 §10.3 从「成本不变量」升级为「同时也是稳定性不变量」。

**坑 6 — 依赖树是需要主动维护的预算，不是自然状态。**

§11.3 已经承认：这个进程持有 API key、有 shell 权限、能读整个仓库。在这种权限画像下供应链风险的权重比普通 CLI 高一档。Go 里「唯一依赖是 TOML」是自然状态；npm 上必须把它做成 CI 断言。

**照抄 Pi 的供应链加固方案**（它是这套 spec 里唯一可以整体搬过来的现成工程实践）：

```
直接依赖精确锁定（不用 ^ / ~），由 npm run check 校验
随包发布 npm-shrinkwrap.json，从根 lockfile 生成，锁定传递依赖
CI 用 npm ci --ignore-scripts 安装
生命周期脚本走显式 allowlist，新增带脚本的依赖直接让检查失败
定时任务跑 npm audit --omit=dev 与 npm audit signatures --omit=dev
发布前的 smoke test 在仓库之外做隔离的 npm 与 Bun 安装
额外加一条：传递依赖总数上限断言（初始值 = 当前值，只能降不能升）
```

最后一条是我们加的，也是最关键的：**把依赖数变成一个只能下降的棘轮**，否则它一定会涨。

---

## 6. `src/ds` — 唯一的 DeepSeek 官方 LLM Backend

后端边界参考 Maka 的做法：Session Kernel 只交付不可变 Request Snapshot，并接收规范化为 DeepSeek 原生事件的流；认证、官方端点、HTTP 生命周期、SSE、取消、错误分类、finish reason、usage 与 best-effort transport telemetry 全部在 `src/ds` 收口。

这里是**一个具体实现的模块边界**，不是通用 Provider abstraction。代码中不得出现 Provider interface / Factory / registry / router / ModelAdapter；不得引入 Vercel AI SDK、OpenAI SDK 或其他模型 SDK；不得支持 OpenAI、Anthropic 等其他 Provider、第三方 DeepSeek-compatible 服务或可配置 `base_url`。唯一网络目标是本契约顶部声明的 DeepSeek 官方端点。

**Maka 参考面固定到 commit `99f13113a6c4602eaa50bbcd285d0708cb007a5e`，只借以下语义：**

- [`model-protocol.ts`](https://github.com/maka-agent/maka-agent/blob/99f13113a6c4602eaa50bbcd285d0708cb007a5e/packages/runtime/src/model-protocol.ts)：Harness 自己拥有 typed model events；SimpleDSH 将 seam 收窄为 DeepSeek 原生事件和一个具体实现，不创建 provider-neutral union、interface 或 kind。
- [`model-adapter.ts`](https://github.com/maka-agent/maka-agent/blob/99f13113a6c4602eaa50bbcd285d0708cb007a5e/packages/runtime/src/model-adapter.ts)：raw stream 翻译、取消与单一终态只归具体 adapter 所有；SimpleDSH 直接解析 DeepSeek SSE，并关闭任何隐藏 SDK retry。
- [`request-shape.ts`](https://github.com/maka-agent/maka-agent/blob/99f13113a6c4602eaa50bbcd285d0708cb007a5e/packages/runtime/src/request-shape.ts)：借 send 前捕获 request identity 的时机；SimpleDSH 记录 bit-exact FrozenBytes/hash/segments，**不得**照搬对象 `JSON.stringify` 或“近似 wire”表示。
- [`provider-request-telemetry.ts`](https://github.com/maka-agent/maka-agent/blob/99f13113a6c4602eaa50bbcd285d0708cb007a5e/packages/runtime/src/provider-request-telemetry.ts)：physical attempt 与语义 Run 分离，记录 request hash/bytes、outcome、TTFB/latency、raw finish reason 与 usage；诊断写入仍是 best-effort，不得改变请求结果。

Maka 的 `ProviderRuntimeAdapter`、`AgentBackend`、`BackendRegistry`、`AiSdkFlow`、`provider-registry.ts`、`model-runtime.ts`、`model-factory.ts`、provider discovery/auth、models.dev、AI SDK adapters/factory、`ProviderOptions`、可配置 provider/model/base URL 全部明确砍掉。测试通过本地 HTTP fixture 或注入同一 `node:https.request` 形状的窄 request function 完成，不为测试引入第二种 backend kind。

### 6.1 请求契约

没有 SDK 就没有 `extra_body`——那是 OpenAI Python SDK 的逃生舱，不是 DeepSeek 的 wire format。手写 HTTP 时它们就是顶层字段：

```json
{
  "model": "deepseek-v4-flash",
  "messages": [ /* blob 字节拼接 */ ],
  "tools": [ /* 冻结区，顺序确定 */ ],
  "stream": true,
  "stream_options": { "include_usage": true },
  "thinking": { "type": "enabled" },
  "reasoning_effort": "max",
  "max_tokens": 65536
}
```

`model`、`thinking.type` 与 `reasoning_effort` 来自冻结常量，调用方不能传入或覆盖。`stream_options.include_usage=true` 同样固定，确保 `[DONE]` 前存在一次完整 usage chunk；缺失或为 false 都是协议错误。golden request 必须逐字节断言这些值；出现 Pro、thinking disabled、`high` 或其他模型值时，测试必须失败。

SimpleDSH 不调用 DeepSeek Responses API、Anthropic API、`/beta` 路径或任何其他 URL。Chat Completions 文档即使列出 `user_id`、`tool_choice`、`strict` 等可选字段，v0.1 body 也不发送它们；未使用字段不是待配置扩展点。

**不发送的参数**（F8）：`temperature`、`top_p`、`presence_penalty`、`frequency_penalty`。这些字段**不出现在类型定义里**，否则将来一定有人以为它们有用。

**哪些字节参与前缀**——需要明确边界，否则会有人去给 HTTP body 排序：

| 影响前缀 | 不影响前缀 |
|---|---|
| `messages` 各条的内容字节 | body 顶层字段顺序 |
| `tools` 数组的**顺序**与每个 schema 的**字节** | `stream`、`max_tokens` |
| `model`（缓存按模型隔离，F6） | — |

### 6.2 Assistant 消息是四个字段，不是三个

Reasonix 的 `Message` 结构体是 `{Role, Content, ToolCalls, ToolCallID, Name}`——**没有 `reasoning_content`**。在思考模式 + 工具调用下这是一个必然触发的 400（F7）。本设计的解析视图：

```ts
// 仅用于渲染与不变量检查。存储形式永远是 FrozenBytes。
export interface AssistantView {
  role: 'assistant';
  content: string;              // tool turn 必须物化为非 null；provider 缺失/null 只在首次提交时规范成 ""
  reasoningContent: string;     // F7：有 toolCalls 时字段必须存在，并与累计语义 UTF-8 字节完全一致
  toolCalls: ToolCall[];
}

// 唯一合法的获取方式，且只允许在 view / 不变量检查中调用
export function viewAssistant(b: FrozenBytes): AssistantView;
```

**存储形式永远是首次提交时唯一 materialize 的 canonical FrozenBytes。** SSE 不提供一份完整 assistant-message wire blob，因此不能虚构“保存原始完整 JSON”；解析只用于渲染和不变量检查，不用于重建请求。带 `tool_calls` 的 assistant 若没有 `reasoning_content` 字段即协议失败；不能补造 reasoning。`content` 的缺失/null 只允许在这次唯一 materialization 时规范成空字符串，以满足 thinking tool turn 的非 null assistant content 兼容约束，之后该 FrozenBytes 永不重写。

### 6.3 SSE 读取器（不变量 6 的实现）

按**字节**切行（`0x0A`），处理 `\r\n` 与 `\n`；跨 chunk 的多字节字符必须用 `TextDecoder` 的 `{ stream: true }` 累积（坑 3）。

```
for 每一行（字节级切分）:
    if 空行            → 忽略；不重置任何计时器；仅首个 semantic delta 前累加 queue_wait
    if 以 ':' 开头      → keep-alive 注释；忽略；不重置任何计时器；仅首个 semantic delta 前累加 queue_wait
    if "data: [DONE]"  → 结束
    if "data: {...}"   → 解析；只有 reasoning/content/tool-call semantic delta 才结束 queue_wait、标记 request_semantic_started 并重置 semantic idle；usage/finish/空 delta 不重置

计时器（三层，全部必须一致，见坑 2）：
    connect_timeout 默认  30s   （仅 TCP/TLS 建连）
    ttfb_timeout    默认 620s   （官方 10 分钟未开始推理会关连接；留终态余量）
    idle_timeout   默认  90s   （仅在收到过第一个 delta 之后生效）
```

流式 tool_call delta 按 `index` 在客户端内累积，**只向上层发出完整的 ToolCall**。

首个 semantic delta 的 hook 是一个**必须 await 的 durability barrier**，不是 fire-and-forget 通知：解析器先把 retry classification 保守切到 `post_semantic`，再 await `request_semantic_started` 的 durable acknowledgement；只有 acknowledgement 成功后才能把该 reasoning/content/tool-call fragment 复制进 staging 或暴露 preview。barrier rejection 立即失败关闭、不得 staging、不得透明重试。后续 semantic hooks 同样按序 await，以免 async rejection 变成未处理 Promise。纯 parser fixture 可以不提供 durability hook；任何真实 transport caller 必须提供。

取消路径：`AbortSignal` 从 CLI 一路传到 `node:https` request 的 `destroy()` 和当前 bash runner；中断后由 §8.2 对当前 durable tail 分类并创建新 Run 或停止。runner 必须对原 PGID 执行 TERM→KILL 并记录有界 cleanup observation（§5.4 坑 5），但不能声称它终止了已经逃离该组的对抗性进程。

**assistant blob 的产生方式**：流结束后，用累积到的 `content` / `reasoning_content` / `tool_calls` 通过固定字段顺序的 canonical assistant serializer 组装一次最终 JSON，写为 blob，之后永不重写。流式响应本来就没有一份现成的完整 message 字节，因此“原样”指累计 semantic value 的 UTF-8 字节在这次唯一 materialization 与后续请求中完全相同；测试比较累计语义字节、已提交字段与下一请求字段，而不虚构 SSE wire JSON 与最终 message JSON 在 JSON 转义层面逐字节相同。

在 `[DONE]` 前必须恰好接受一个 `stream_options.include_usage` 产生的完整 usage chunk；普通 delta 上的 `usage:null` 不落账。assistant 累计值、finish reason、provider request id 与 usage 全部先留在 staging；只有 `[DONE]`、唯一 usage、字段守恒与 canonical serializer 都成功后，才 durable 追加**一条** `assistant_committed`。它在同一 payload 原子携带 assistant FrozenBytes 引用、raw finish reason、完整已校验 usage、provider request id、attempt id 与 Snapshot id，并同时作为该 physical attempt 的成功终态；usage 与成功终态没有可独立落盘的第二事件。缺失、重复或守恒失败只追加 `request_interrupted(outcome=protocol_error)` 并闭合 Run，不提交 assistant/usage、不生成 Cache Checkpoint。

### 6.4 usage 归一化与成本

直读 DeepSeek 原生字段，不做跨厂商归一化：

```ts
export interface Usage {
  promptTokens: number;
  promptCacheHitTokens: number;   // 命中部分
  promptCacheMissTokens: number;  // 未命中部分
  completionTokens: number;
  reasoningTokens: number;        // completion_tokens_details.reasoning_tokens
  rawFinishReason: string;        // 原样保留，不做映射
}
```

两条纪律：

1. **`ReasoningTokens` 已包含在 `CompletionTokens` 内，不得二次相加。**
2. **`RawFinishReason` 与 dsh 内部映射的 stop 原因分开存储。** 映射会丢信息，原值是排查依据。（取自 Maka，这一点它做对了。）

不变量校验：`PromptTokens == PromptCacheHitTokens + PromptCacheMissTokens`。不成立是 mandatory usage protocol failure，走上一节的 `request_interrupted`；不得降级成 warning 或写入成本账本。best-effort 只修饰不会改变请求结果的 transport diagnostics，不修饰 native usage 正确性。

---

## 7. `src/journal` / `src/artifact` / `src/blob` — 单一事实账本与冻结证据

### 7.1 存储格式

```
.dsh/sessions/<session-id>/
  log.jsonl                 # append-only 事件流，唯一真相
  writer.lock/              # 原子 mkdir 获得的单 writer lease
  blobs/sha256/<hash>       # 超阈值的 FrozenBytes（默认 > 64 KiB）
  snapshots/sha256/<hash>   # 完整 model-visible request body；所有尺寸都独立 durable
  artifacts/sha256/<hash>   # 所有原始工具输出与其他原始证据
  recovery/sha256/<hash>    # torn tail 的原始尾字节证据；仍由 Journal 引用
```

`.dsh/`、Session 与所有存储子目录创建为 `0700`，其中普通文件为 `0600`；既存路径若是 symlink、类型不符或权限更宽则 fail closed。Session id 与其他 opaque id 使用下述 path-safe wire grammar，不能把调用方字符串直接拼成路径。

Fresh-tree bootstrap 必须逐层执行而不能用一次 recursive mkdir 模糊 durability：每创建一个目录，先 fsync 新目录，再 fsync 它的直接 parent，成功后才可在其中创建下一层。首次以 `wx/0600` 创建 `log.jsonl` 后先 fsync 空 log fd，再 fsync Session dir；这些步骤全部完成前 writer 不可使用，第一条 record 更不能 acknowledgement。每个新 CAS namespace 目录也遵守同一“新目录 + parent”fsync 顺序。既存目录仍逐层 lstat/mode/type 验证，但不假设一次 leaf fsync 可以补回未 durable 的祖先 entry。

Writer lease 使用同一 Session 内原子 `mkdir(writer.lock, 0700)`；第二 writer 一律拒绝。目录内唯一 owner record 是 canonical `{"v":1,"pid":<positive-safe-int>,"nonce":"<32-lower-hex>","acquiredAt":"<canonical-at>"}\n`，以 `wx/0600` 完整写入并 fsync owner file、lock dir 与 Session dir 后 lease 才可使用；owner 缺失、非 canonical、symlink 或权限异常都是 ambiguous lease。`process.kill(pid, 0)` 成功或权限不足表示 live/unknown；只有 `ESRCH` 证明已登记 PID 不存在。v0.1 **不自动删除或抢占任何 lease**：普通 open 对 stale-proven-dead 与 ambiguous 都 fail closed。

唯一恢复入口是显式 operator quarantine control。它接收刚完成的 inspection fingerprint 与“已确认没有并发启动”的显式 confirmation；只允许 stale-proven-dead，或操作者明确 force 的 ambiguous 状态。执行前必须立即重新 lstat/读取并逐字节核对 owner、inode/type/mode/fingerprint 未变化；任何 live/unknown、状态变化或无法复核都拒绝。通过后把**完整** lock dir 原子移到唯一 quarantine、fsync Session dir，不能先删除 `owner.json` 留出空锁窗口。正常 release 同样先关闭 log fd、逐字节核对 owner nonce，再把 lock dir 原子移到 release quarantine 并 fsync Session dir；owner 不匹配时绝不删除别人的 lease。

每个 Journal record 都使用固定字段顺序的 canonical JSON envelope，并以换行闭合：

```text
{v, seq, id, type, sessionId, lineageId?, runId?, parentId?, at, payload, prevHash, hash}\n
preimage = canonical JSON object containing fields v through prevHash, including its closing `}`
hash = SHA-256(preimage bytes)
```

Journal schema version 固定为整数 `v=1`；首条 record 是 `seq=1, prevHash=null`，空前缀表示 `seq=0, hash=null`。`seq` 必须严格连续，`prevHash` 必须链接上一条 record。`hash`、`prevHash` 与所有 byte digest 的 wire form 统一为 `sha256:<64 lowercase hex>`；前缀算法需要链入 digest 时 decode 为 raw 32-byte 值，禁止链入 ASCII hex。

`id` 永远是独立 `EventId`，不能兼作 Session/Lineage/Run/Artifact/Effect 等对象 id。opaque id wire form 按类型分别固定为 `evt|ses|lin|run|rqs|att|art|arv|eff|ccp|cbd` 前缀、下划线和 32 个 lowercase hex；`CacheAbiId` 是上述 SHA-256 wire form。`parentId` 若存在只允许引用同一 Session 中更早的 `EventId`，不表示全局顺序，也不预留 v0.1 不存在的 fork；多 source 事件在 typed payload 中携有序 source id 列表。

`at` 是 append 前显式采样并写入的事实，wire form 固定为 UTC RFC3339、恰好三位毫秒和 `Z`；重放不得读当前时间。envelope 的 `lineageId/runId/parentId` 不适用时省略，不能写 `undefined` 或 `null`；payload 中有业务含义的空值按下述 schema 显式写 `null`。字符串拒绝孤立 UTF-16 surrogate；数字只允许 schema 声明的 non-negative/positive safe integer；拒绝 float、负数、非有限数、unknown/duplicate field 与未知 event。canonical codec 只从 event-specific typed payload 构造无空白 JSON，按本节字段顺序使用标准 JSON string escaping；不接受 `Record<string, unknown>`、`Error`、exception cause、process env 或其他隐式 capture。

重放顺序固定为：按 LF 切 raw bytes → UTF-8 fatal decode → JSON parse → exact schema/key/type/range validation → canonical re-encode → 与原 line 逐字节相等 → 验证 seq/prevHash/hash。语义等价但字段重排、空白、非 canonical escape/number 或 duplicate key 的 JSON 都是 corruption。

通过逐行验证还不够；replay 同时维护一份可丢弃的 cross-record binding table，并在 append 前对同一 table 预检。第一条事实必须是唯一 `session_started`，后续 `sessionId` 不得变化；每个 `EventId` 全局唯一。`CacheAbiId`、`LineageId`、`RunId`、`ArtifactId`、`ArtifactVersionId`、`RequestSnapshotId`、`AttemptId`、`CacheCheckpointId`、`CommitBoundaryId` 与 `EffectId` 都由各自唯一 creator event single-assign，禁止重复声明或把同一个 wire id 绑定到另一类型。每个 parent/source/object/ref id 必须解析到同一 Session 中**更早且类型兼容**的 creator/event；forward、missing、wrong-type、rebind 与重复 source 全部 fail closed。Provider `toolCallId` 由更早 assistant FrozenBytes 中的唯一 call 创建，reference verifier 通过获准只读 view 解析并核对，不建立第二份 tool-call store。该 table 只是 replay 期间的验证投影，删除后必须能从 Journal/bytes 重建。

写入一个 record 的 durability boundary 是：持有完整 lease并进入进程内串行区 → 对唯一 immutable `record+LF` buffer 执行一个**逻辑 append** → `fsync(log fd)` 成功。Node 可能 short-write，因此实现必须在 append-mode file handle 上串行 await write loop 直到该 buffer 全部写完；任何 `bytesWritten == 0`、write 或 fsync 错误都会 poison writer，且不得 acknowledgement 或继续 append。循环期间不得插入另一条 record。

最后一个 LF 后的非空 suffix 是唯一可自动识别的 torn tail；即使 suffix 恰好是可 parse 的完整 JSON，没有 LF 也没有 commit framing，仍按 torn tail 处理。所有 LF-terminated record 必须先完整通过 canonical/schema/seq/hash 验证；若没有一条完整的 `session_started` valid prefix，则不能凭路径猜造身份，必须 fail closed。

修复使用一次原子 log replacement，不建立第二个 WAL：(1) 把固定顺序的 canonical recovery object `{v,sessionId,validPrefixByteCount,validPrefixSeq,validPrefixHash,tailByteCount,tailHash,tailEnc:"b64",tailBytes}` 通过下述 no-clobber publisher 发布到 `recovery/sha256/<object-hash>`；同一 valid prefix/tail 的 object bytes 与 hash 必须完全相同，rename 前的 crash 因而复用它；(2) 在 Session 内唯一 `0600` 临时文件写入“逐字节 valid prefix + 一条 canonical `journal_tail_recovered` record”；该 event 引用 recovery object，`seq/prevHash` 由 valid prefix 决定，`id/at` 在本次候选 repair 前正常采样，record hash 由完整 canonical preimage 计算；(3) fsync 并**关闭** repair temp 与旧 log fd；(4) 原子 rename 覆盖 `log.jsonl`、fsync Session 目录、重新打开并完整 replay。crash 若发生在 rename 前，旧 torn log 仍在且下一次可产生新的候选 id/at；只有成功 replacement 中的一条 event 成为事实。rename 后以 payload 的 `recoveryHash` 为唯一幂等 source，不得再追加第二条 repair event。rename 前遗留的未引用 recovery object 不参与正常重放，可在确认无 Journal 引用后回收。逻辑历史仍是 valid prefix 后只追加 repair fact，物理 replacement 只允许此 torn-EOF 路径。任何带 LF 的无效 JSON、hash/seq 缺口或非末尾损坏都是 mid-log corruption，必须 fail closed且不能向已损坏 Journal 追加“修复”事实。

Artifact、外置 blob、Snapshot body 与 recovery object 共用一个内部 CAS publisher，但不向上层公开任意 namespace 参数。发布顺序固定为：在**目标目录内**以 `wx/0600` 创建唯一临时文件 → 串行 short-write loop 写完 → fsync 文件 → `fstat` 普通文件并计算/核对 SHA-256 与 byte count → **关闭 writable temp handle** → `link(temp,target)` 原子 no-clobber 发布 → fsync 目标父目录 → 才允许 Journal 引用 → unlink temp 仅作清理。目标名是 digest 的 64 lowercase hex，ref 分别固定为 `artifacts|blobs|snapshots|recovery/sha256/<hex>`。普通 POSIX `rename` 会覆盖同名目标，因此除 torn-log replacement 外禁止用 check-then-rename 发布 CAS，也禁止 link 失败后 fallback 到 copy/rename。

`link` 返回 `EEXIST` 时，以 `O_NOFOLLOW` 打开既存 target，要求它是 `0600` 普通文件并逐字节/长度/hash 相同，再 fsync target 与父目录后才可复用；不一致是 integrity violation。其他 link/open/sync 错误全部 fail closed；candidate 支持平台的 directory fsync 是硬门，不能以 “unsupported” warning 静默放行。原始 Artifact 永不覆盖；用户编辑先读取旧版本，再发布新 hash 并追加 `artifact_version_created(old,new)`。Snapshot body 也永不覆盖且所有尺寸都 external，但不是用户 Artifact。可丢弃 metadata/index 不参与重放。

小 blob 随其唯一的 `user_committed`、`assistant_committed` 或 `tool_result_committed` 事件内联进 `log.jsonl`，**在事件 payload 内以 base64 存放**，不是嵌套对象、也不是 JSON 转义字符串。例如下列 payload 仍由上面的 canonical envelope 包裹，不是第二种 record 格式：

```json
{"role":"assistant","enc":"b64","bytes":"eyJyb2xlIjoi...","byteCount":42,"byteHash":"sha256:...","blobIndex":7,"chainHash":"sha256:..."}
```

三个候选形式的取舍（这是不变量 4 的实现细节，不是风格选择）：

| 形式 | 问题 |
|---|---|
| 嵌套对象 | 重新序列化 `log.jsonl` 时会改字节（字段顺序、数字格式、Unicode 转义策略）。**直接违反不变量 4** |
| JSON 转义字符串 | 转义本身无损，但在 JS 里必然经过 UTF-16 字符串。孤立代理项经 `TextEncoder` 会变成 U+FFFD，字节与哈希双双漂移（§5.4 坑 1） |
| **base64** | 体积 +33%，但 `Uint8Array` ⇄ base64 是纯字节映射，不经过字符串语义。**选它** |

体积代价是可接受的：日志本来就是 append-only 的本地文件，而正确性不可交易。`byteCount <= 65_536` 必须使用 `{role,enc:"b64",bytes,byteCount,byteHash,blobIndex,chainHash}`；`byteCount > 65_536` 必须先发布 raw bytes，再使用 `{role,enc:"ref",blobRef,byteCount,byteHash,blobIndex,chainHash}`，其中 ref digest 必须等于 `byteHash`。base64 必须是 canonical padded encoding，decode 后逐字节验证 count/hash。三种角色事件就是把一个 blob 纳入前缀的唯一事实，不再额外写通用 `blob_committed`，因此 replay 不会把一条消息计两次。`blobIndex` 从 `0` 开始且连续。

#### 7.1.1 v1 event payload schema

v1 的 payload 不是自由 JSON。下表字段顺序就是 canonical 顺序；表中 `null` 是显式 JSON null，`?` 只表示 discriminated union 的该变体没有此 key。所有 `...Id` 使用上面的 branded wire grammar；`...Hash` 使用 SHA-256 wire form；count/index/token/ordinal 都是 non-negative safe integer，只有 pid/ordinal 从 `1` 开始。`sourceEventIds` 与 `segmentHashes` 保留声明顺序、禁止重复。

角色 blob 的公共字段按顺序为：

```text
inline   = {role, enc:"b64", bytes, byteCount, byteHash, blobIndex, chainHash}
external = {role, enc:"ref", blobRef, byteCount, byteHash, blobIndex, chainHash}
```

工具的 durable terminal classification 只有一个 canonical object；字段顺序固定为：

```text
terminal = {status:"succeeded"|"failed"|"invalid"|"denied"|"unavailable", code, exitCode:null|integer, signal:null|Signal, descendantsReaped:null|boolean}
```

`code` 的 closed set 是
`ok|unknown_tool|invalid_json|invalid_arguments|permission_denied|io_error|edit_no_match|edit_not_unique|target_changed|nonzero_exit|signaled|timeout|cancelled|output_limit|bash_supervisor_unavailable|credential_shield_unavailable`。
同一个 terminal object 进入 Artifact/Effect 后禁止再用 `outcome`、异常名或自由文本建立第二份分类。

| event type | exact payload fields / closed variants |
|---|---|
| `session_started` | `{}`；新 `SessionId` 只在 envelope `sessionId` |
| `cache_abi_declared` | `{cacheAbiId, manifestArtifactId, manifestByteCount}`；manifest Artifact 必须先 durable，且其 hash 等于 `cacheAbiId` |
| `lineage_started` | `{cacheAbiId}`；新 `LineageId` 在 envelope `lineageId`，baseline 不含 parent/fork |
| `lineage_activated` | `{previousLineageId:null\|LineageId, nextLineageId, reason:"initial"\|"abi_change"}`；envelope `lineageId == nextLineageId` |
| `run_started` | `{cause:"user"\|"recovery", previousRunId:null\|RunId}`；新 `RunId` 在 envelope `runId`，`cause=user` 时 previous 必须为 null |
| `fact_recorded` | `{kind:"user_input"\|"project_instructions"\|"date"\|"cwd"\|"git", artifactId, byteCount}`；Artifact 必须先 durable，bytes 是唯一值，不在 payload 重复一份字符串 |
| `user_committed` | `inline/external(role="user")` 后接 `{sourceFactEventIds}`；至少一个 source，且必须包含本轮 `user_input` fact |
| `artifact_published` | `{artifactId, artifactRef, artifactHash, byteCount, lineCount:null\|number, mediaType, artifactType, streamBytes:null\|{read,stdout,stderr}, hardLimitReached:null\|boolean, descendantsReaped:null\|boolean, toolCallId:null\|ToolCallId, terminal:null\|terminal}` |
| `artifact_version_created` | `{artifactVersionId, parentArtifactVersionId:null\|ArtifactVersionId, oldArtifactId, newArtifactId}`；old/new 不得相等且都已 published |
| `request_snapshot_stored` | `{requestSnapshotId, bodyRef, bodyHash, byteCount, cacheAbiId, projectorVersion, headEventId, commitBoundaryId, segmentHashes, recoveryFromSnapshotId:null\|RequestSnapshotId}`；lineage/run 来自 envelope；v1 的 `segmentHashes` 恰为下述 `[header_hash, boundary.chain_hash]` 两项，`headEventId` 恰为该 Commit Boundary creator event id |
| `request_attempt_started` | `{attemptId, requestSnapshotId, ordinal}`；同一 Snapshot 的 ordinal 从 `1` 连续增长 |
| `request_semantic_started` | `{attemptId}`；同 attempt 最多一条，不保存 preview/staging |
| `assistant_committed` | `inline/external(role="assistant")` 后接 `{attemptId, requestSnapshotId, providerRequestId, responseModel, systemFingerprint:null\|string, semanticDeltaCount, usage}`；`usage={promptTokens,promptCacheHitTokens,promptCacheMissTokens,completionTokens,reasoningTokens,rawFinishReason}` |
| `request_interrupted` | `{attemptId, requestSnapshotId, outcome, status:null\|HttpStatus, retryClass, semanticState}` |
| `cache_checkpoint_created` | `{cacheCheckpointId, requestSnapshotId, blobCount, chainHash, promptTokens, providerRequestId, sourceAssistantEventId}` |
| `commit_boundary_created` | `{commitBoundaryId, cacheCheckpointId:null\|CacheCheckpointId, blobCount, chainHash, protocolClosed:true, effectsSettled:true, sourceEventIds}` |
| `cache_break` | planned `{classification:"planned",fromLineageId,toLineageId,reason:"abi_change",authorizedRevision}`；unplanned `{classification:"unplanned",reason,expectedHash,actualHash,diffArtifactId}` |
| `integrity_violation` | `{code, relatedEventId:null\|EventId, expectedHash:null\|Sha256, actualHash:null\|Sha256}` |
| `permission_decided` | `{toolCallId, policyDecision:"allow"\|"ask"\|"deny", finalDecision:"allow"\|"deny", resolution:"policy"\|"interactive"\|"yes_flag"\|"non_interactive"}` |
| `effect_prepared` | `{effectId, toolCallId, toolName:"write"\|"edit"\|"bash", argumentsHash}` |
| `effect_completed` | `{effectId, toolCallId, artifactId, terminal}` |
| `effect_indeterminate` | `{effectId, reason:"crash_gap"\|"process_state_unknown"\|"filesystem_state_unknown"\|"artifact_durability_failed"}` |
| `effect_reconciled` | completed `{effectId,resolution:"completed",evidenceArtifactId,outputArtifactId,terminal}`；not executed `{effectId,resolution:"proven_not_executed",evidenceArtifactId}` |
| `tool_result_committed` | `inline/external(role="tool")` 后接 `{toolCallId, effectId:null\|EffectId, artifactId:null\|ArtifactId, sourceEventId}`；只有 pure static validation 或 mechanical permission denial 的 artifact 为 null |
| `run_completed` | `{commitBoundaryId, sourceAssistantEventId}` |
| `run_interrupted` | `{reason, sourceEventId}` |
| `journal_tail_recovered` | `{recoveryRef, recoveryHash, recoveryByteCount, validPrefixSeq, validPrefixHash, tailByteCount, tailHash}`；`recoveryHash` 是唯一 repair source key |

`artifactRef/bodyRef/blobRef/recoveryRef` 分别只能位于其固定 namespace，ref 最后的 hex 必须等于对应 hash。`artifactType` 只允许 `cache_abi_manifest|project_instructions|fact|tool_output|operator_evidence|user_state`；`mediaType` 是 1–127 byte printable ASCII。`lineCount` 非 null 时按 raw bytes 计算：空文件为 `0`，否则为 LF 数加上“最后一个 byte 不是 LF”的一行；重放必须复算。

只有 `tool_output` 可以携非 null `streamBytes/hardLimitReached/toolCallId`，其 `mediaType` 必须恰为 `application/vnd.simpledsh.tool-output.v1`、`lineCount=null`，三个 stream count 与 `hardLimitReached` 都不得省略。非 tool Artifact 的这些字段、`descendantsReaped` 与 `terminal` 全为 null。bash 在 `effect_prepared` 后进入 native runner 时，output Artifact 的 `descendantsReaped` 必须是 boolean；若 spawn 未成功，它为 `true`（没有被创建的 PGID/pipe 可残留），否则仅在原 PGID 已不存在且双 EOF 都于观察窗内出现时为 `true`。其他工具以及任何未启动 bash 的 pre-effect observation 都为 null。T1 `read` 以及任何依赖 filesystem/platform 观察而在 `effect_prepared` 前 settled 的 Artifact，其 `terminal` 非 null；pure static validation 与 mechanical denial 不造 Artifact。T2 Artifact 在 `effect_prepared` 后、terminal Effect 前发布，因此它的 `terminal=null`，但 bash 的 cleanup observation 已写入独立 metadata；紧随其后的 Effect terminal 必须携相同 boolean。codec 必须把完整 CAS bytes parse 到 EOF，复算 record 数、三流 payload count、marker 与 `6*recordCount`，并验证 `sum(streamBytes) + 6*recordCount == byteCount`；**Journal/Artifact metadata 不保存 `framingByteCount`**，provider projection 中的 `framing_byte_count` 只能由上述等式派生。

terminal 的 status/code 映射是 closed：`succeeded/ok`；`failed/io_error|edit_no_match|edit_not_unique|target_changed|nonzero_exit|signaled|timeout|cancelled|output_limit`；`invalid/unknown_tool|invalid_json|invalid_arguments`；`denied/permission_denied`；`unavailable/bash_supervisor_unavailable|credential_shield_unavailable`。`effect_completed` 与 completed reconciliation 只允许 `succeeded|failed`；Artifact terminal 还可表示在 Effect 前已 durable 的 `invalid|unavailable` observation。`read` 只允许 `ok|invalid_arguments|io_error`，`write` 只允许 `ok|invalid_arguments|io_error|target_changed`，`edit` 只允许 `ok|invalid_arguments|io_error|edit_no_match|edit_not_unique|target_changed`，`bash` 只允许 `ok|io_error|nonzero_exit|signaled|timeout|cancelled|output_limit|bash_supervisor_unavailable|credential_shield_unavailable`。read selected bytes 达到 raw hard limit 时停止读取、发布 `hardLimitReached=true` 的 partial Artifact，并以 `succeeded/ok` settled；`output_limit` 因而是 bash-only process terminal。`permission_denied` 只由 `permission_decided` source 使用，不进入 Artifact/Effect terminal；pure static invalid 也不造 Artifact。

两个旧 unavailable code 为兼容现有 v1 codec 与 provider-visible result bytes 保留，不能据此复活 admission backend。新 writer 永不产生 `credential_shield_unavailable`；`bash_supervisor_unavailable` 只作为 frozen legacy wire spelling 表示 `win32` 的 bash unavailable，不代表存在 supervisor probe。Windows 是唯一 platform-unavailable 分支；所有非 Windows 平台都尝试同一 absolute `/bin/bash` path，macOS/Linux 不能因缺少 Lima、container runtime、镜像、mount 或 capability 而产生 unavailable。

`invalid_arguments` in Artifact 只表示 filesystem-dependent file guard observation；`edit_no_match|edit_not_unique` 也只允许在 pre-effect Artifact。write/edit 的 Effect terminal 因而只允许 `ok|io_error|target_changed`，bash Effect terminal 不允许 unavailable code。pure static invalid 与 mechanical denial 的两-key result 仍使用同一 closed status/code mapping，但没有伪造一个 observation Artifact。

非 bash 的 `exitCode/signal` 恒为 null，`descendantsReaped=null`。bash `ok` 固定 `0/null`，`nonzero_exit` 固定 `1..255/null`，`signaled` 固定 `null/non-null`；spawn-failed `io_error` 与 Windows pre-effect unavailable 固定 `null/null`。`timeout|cancelled|output_limit` 必须与直接子进程的已观察终态对齐，**严格恰有一个** exitCode 或 signal。bash 在 prepared 后进入 runner 的 Effect terminal 必须携 boolean `descendantsReaped`，并与 output Artifact metadata 相同；Windows pre-effect terminal 为 null。这个 boolean 不进入 §10.3 已冻结的 provider projection，不能改变 system prompt、tool schema、request serializer 或 tool-result field order。对 T1/pre-effect observation 是 Artifact terminal、对 T2 是绑定该 Artifact 的 Effect terminal；bash 的 code 为 `output_limit` 当且仅当 output Artifact 的 `hardLimitReached=true`，read 的 hard-limit Artifact 则按上一段保持 `succeeded/ok`。pre-effect Artifact 没有 producer output时 CAS bytes 为零、三流计数为零、`hardLimitReached=false`。

**独立 P1 勘误（2026-08-04；与 bash 方向变更无关）：** `output_limit` 的 exit/signal 约束一直应与 `timeout`、`cancelled` 相同，必须是严格 XOR。当前实现中的 `!neither && !exactlyOne` 会错误接受 `exitCode=null,signal=null`，且 `test/effects/codec.test.ts` 有一组单元 fixture 固化了这个错误；仓库内没有落盘 JSON/JSONL Journal 样本使用该形态。由于非进程 read 不能伪造 exit/signal，它达到 raw limit 时改用上一段定义的 `succeeded/ok + hardLimitReached=true`；这是本 P1 的必要一致性修正，不属于执行隔离方向。实现阶段必须把 validator 改为 strict `exactlyOne`，更新 fixture/read-limit expectation，并用 normalize/read、append 与 replay mutation 测试拒绝 neither/both，同时保留 exit-only 与 signal-only 的合法样本。

`Signal` 是以下 frozen wire enum，不能保存任意运行时字符串：`SIGABRT|SIGALRM|SIGBREAK|SIGBUS|SIGCHLD|SIGCONT|SIGFPE|SIGHUP|SIGILL|SIGINFO|SIGINT|SIGIO|SIGIOT|SIGKILL|SIGLOST|SIGPIPE|SIGPOLL|SIGPROF|SIGPWR|SIGQUIT|SIGSEGV|SIGSTKFLT|SIGSTOP|SIGSYS|SIGTERM|SIGTRAP|SIGTSTP|SIGTTIN|SIGTTOU|SIGUNUSED|SIGURG|SIGUSR1|SIGUSR2|SIGVTALRM|SIGWINCH|SIGXCPU|SIGXFSZ`；native runner 无法把 Node reported signal 映射到该集合时是 `process_state_unknown`，不是新字符串。

Provider `toolCallId` 是无 lone surrogate 的 Unicode-scalar string，UTF-8 长度固定为 `1..4096` bytes。SSE staging 的 UTF-16 length 一旦超过 `4096` 就提前 protocol-fail，terminal 时仍必须执行 scalar 与 UTF-8 byte 验证；assistant/tool FrozenBytes view 与所有 Journal 字段复用同一 validator。超界是 `invalid_tool_call` protocol failure，不是模型可见的 tool validation result。

`request_interrupted.outcome` 只允许 `http_error|transport_error|timeout|cancelled|protocol_error|durability_error`；`status` 只在 HTTP outcome 中为 `100..599`。`retryClass` 使用 Stage 02 的 `request_invalid|authentication|balance|rate_limited|server|unknown|timeout|cancelled|protocol|transport_unknown`；Stage 02 runtime semantic state `unknown` 在写 Journal 时唯一映射为 wire `semantic_state_unknown`，另外两个值为 `pre_semantic|post_semantic`，不能把两种 unknown spelling 都落盘。

`assistant_committed.usage` 必须满足 `promptTokens == promptCacheHitTokens + promptCacheMissTokens` 与 `reasoningTokens <= completionTokens`；`reasoning_content/content/tool_calls` 只存在于同一 assistant FrozenBytes，不在 payload 建第二份语义真相。`responseModel/systemFingerprint` 只在该 atomic success event 记录，不另建 response/usage event。

`integrity_violation.code` 只允许 `journal_canonical|journal_schema|journal_sequence|journal_hash|reference_missing|reference_mismatch|cas_collision|prefix_chain|protocol_closure|derived_conflict`。结构已损坏、无法合法继续 append 的 Journal 只返回 typed corruption 并 fail closed；不能为了“记录错误”继续写在 corruption 后。`run_interrupted.reason` 只允许 `request_failed|semantic_interrupted|effect_indeterminate|integrity_violation|cancelled|durability_failure`；`cache_break` unplanned reason 使用同一 1–64 byte lowercase snake-case code grammar，diff 必须放到先 durable 的 Artifact，不能塞自由 exception/error text。

Scope 规则固定为：`session_started/cache_abi_declared/journal_tail_recovered` 不带 lineage/run；`lineage_started/lineage_activated` 必须带 lineage、不带 run；`fact_recorded/artifact_published/artifact_version_created` 要么二者都省略（Session-scoped），要么二者都存在（Run-scoped）；planned `cache_break` 不带二者，unplanned `cache_break` 与 `integrity_violation` 若发生于 Run 则二者都带；其余事件必须同时带 lineage/run。`parentId` 除 `session_started` 外可在恰有一个决定性 source event 时使用，若无单一 source 就省略并使用 payload 的 source id 列表。

Artifact store 不通过扫描、过滤或改写 opaque bytes 猜测 credential：API 只接受调用方显式提供的 bytes 与 closed metadata，自己永不读取 env、`.env`、Credential、Error/cause 或任意对象图。CredentialLoader、HTTP capture 与 child-env builder 不得**自动**把 harness key 放入 Artifact；但同用户 bash 若被明确命令读取秘密，其 stdout/stderr 是普通证据，publisher 必须精确保存而不能事后删改。这正是 §11.2 必须向用户披露的无隔离边界。

Artifact 对外只开放强制有界的 `readArtifactRange(ref,{offset,maxBytes})`：`offset` 是 non-negative safe integer，`maxBytes` 是 `1..32_768` 的 safe integer，store 返回 `{bytes,offset,byteCount,totalByteCount,eof}` 且 `bytes.byteLength <= maxBytes`。v1 不存在无界 `readAll` overload；内部完整 hash/length 验证可以流式读取全文件，但不能把整份 Artifact 暴露为一次无界分配。

### 7.2 前缀账本

```
h[0] = H(blob[0].bytes)
h[i] = H(LP(h[i-1]) ‖ LP(blob[i].bytes))
header_hash  = H(LP(system_blob) ‖ LP(tools_blob))
cache_abi_id = H(cache_abi_manifest_bytes)  # §3 的唯一 length-delimited manifest
lineage_id   = lineage_started.lineage_id   # 唯一 opaque id，不从 cache_abi_id 推导
```

每个 blob 记录 `h[i]` 与序号 `n`。每次完整请求完成写一条 `cache_checkpoint_created`。`commit_boundary_created` 独立于它：任何新 append 使所选前缀达到“无 partial response、无未配对 tool call、Effect 全部 completed/reconciled”时立即写；因此新 user blob 或完整 tool-result 批次可产生没有 `cache_checkpoint_id` 的安全边界。

`request_snapshot_stored.segmentHashes` 不是可扩展列表或每-message 索引。v1 恰好保存两项、顺序固定为 `[header_hash, selected_commit_boundary.chain_hash]`：第一项证明冻结 system/tools header，第二项证明所选 Lineage blob prefix。`bodyHash` 另行覆盖完整 Provider body，所以不在列表重复。两项必须不同；碰撞或任何数量/顺序/值不符都属于 integrity failure。这样字段大小恒定，不随会话轮数增长，也不存在 optional `segmentHashes` 语义。

### 7.3 前缀完整性自检

在两处触发：**(a) 每次收到 400/422；(b) 会话恢复后的第一次请求前。**

```
1. cache_abi_id 与冻结区、版本、固定模型元组重算是否一致？
2. lineage_id 是否由唯一 lineage_started 定义，cache_abi/activation/CommitBoundary 引用是否有效？
3. blob 列表是否严格连续（n 无缺口、h 链可验证）？
4. tool results 是否构成声明顺序的无重复前缀？至多最后一个 assistant group 可有 pending suffix，且其后不得有 Snapshot/Commit Boundary/下一模型消息
5. 有 tool_calls 的 assistant blob 是否都有 string 类型 `reasoning_content`，且其 UTF-8 字节与首次累计并提交的值完全一致？
6. 是否存在孤儿 tool blob（前面没有对应的 assistant tool_calls）？
```

引用/顺序/重复失败 → 写 `integrity_violation + run_interrupted` 并拒绝；合法 pending suffix 返回 `pending_tools`，由 §8.2 新 Run 补齐且同样不允许发送模型请求。这比让 DeepSeek 返回语义模糊的 400 有用得多。

---

## 8. `src/lineage` — 事件、边界与恢复

### 8.1 事件 DAG

`log.jsonl` 是一条有全局 `seq/prevHash` 的 append-only 流；事件的 `parentId` 只表达对象/分支因果，不能替代全局写入顺序。一个 Lineage 的模型历史是 Projector 从显式 parent/lineage facts 选择出的路径，不是第二份日志。

v0.1 的规范事件集合如下；新增或改名属于 schema/恢复契约变更：

| 域 | 事件 |
|---|---|
| identity | `session_started` · `cache_abi_declared` · `lineage_started` · `lineage_activated` · `run_started` |
| facts/bytes | `fact_recorded` · `user_committed` · `artifact_published` · `artifact_version_created` · `request_snapshot_stored` |
| physical request | `request_attempt_started` · `request_semantic_started` · `assistant_committed` · `request_interrupted` |
| protocol/cache | `cache_checkpoint_created` · `commit_boundary_created` · `cache_break` · `integrity_violation` |
| tools/effects | `permission_decided` · `effect_prepared` · `effect_completed` · `effect_indeterminate` · `effect_reconciled` · `tool_result_committed` |
| Run closure/recovery | `run_completed` · `run_interrupted` · `journal_tail_recovered` |

identity event 的偏序唯一为 `session_started → cache_abi_declared → lineage_started → lineage_activated → run_started`；这些不要求在 Journal 中连续。project-instruction `artifact_published`/`fact_recorded` 必须落在 `session_started` 之后、`cache_abi_declared` 之前。`lineage_activated` 是唯一改变 Session 活动 Lineage 的事件；v0.1 payload 带 previous/next lineage 与 `initial|abi_change` 原因，Projector 从最后一条有效 activation 推导活动 Lineage，不读取隐藏指针。恢复只在同一活动 Lineage 追加新 `run_started`，不重复 activation；未来 evidence-gated reason 必须先修订 schema/review。

`user_committed`、`assistant_committed`、`tool_result_committed` 是互斥角色变体，也是将 FrozenBytes 纳入前缀链的唯一事件；每条都携 blob index/hash/chain hash。`assistant_committed` 原子引用 reasoning/content/tool_calls、raw finish reason、唯一已校验 usage、provider request id、attempt id 与 Snapshot id，并同时 terminalize 该 successful attempt；`tool_result_committed` 携唯一匹配的 tool-call/effect 引用。`permission_decided` 在每个 call 执行或拒绝前记录最终 decision；`artifact_published` 与 `artifact_version_created` 遵守 §7.1 的先文件后引用顺序。

`request_attempt_started` 必须在任何网络发送前 durable。每个 attempt 恰由一个终态闭合：协议成功时为上面的单条 `assistant_committed`；HTTP/transport/timeout/cancel/protocol failure 时为 `request_interrupted`，payload 固定记录 outcome、status/retry class 与 `pre_semantic|post_semantic|semantic_state_unknown`。started/terminal 描述同一 immutable Snapshot 的 physical attempts，它们不创建新 RequestSnapshot。首个语义 delta 必须先产生 durable `request_semantic_started`；该事件只标记 retry 边界，不保存 preview/staging 内容。

`assistant_committed` 只有收到协议终态、唯一完整 usage 校验成功且所有字段可在一次 Journal append 中持久化时才追加；成功后可确定性产生 Cache Checkpoint。pre-semantic 且 taxonomy 允许的 `request_interrupted` 可在同一 Run 对同一 Snapshot 启动下一 attempt；不可重试、预算耗尽或任何 post-semantic/unknown outcome 还必须闭合 Run。Commit Boundary 独立按 §3 的 closed-prefix 条件产生；`run_completed` 只在最终 assistant 无 tool call且当前 user task闭合时产生。

会话状态、TUI 渲染、成本账本、搜索索引**全部是这条日志的投影**（取自 Maka 的「Log is the Runtime」）。

**只有一条日志，只有一个投影层。** 不做第二本账（Task Event Log / TaskRun / cutover journal）——那是 Maka 走过的弯路，迁移机制本身长成了子系统。

### 8.2 恢复

启动时：验证 writer lease → 按 `seq/hash` 重放 `log.jsonl` → 验证所有引用 Artifact/blob/Snapshot → 重建身份、血统与 Effect 状态 → 跑一次前缀完整性自检（§7.3）→ 验证最后一个 Commit Boundary 之后的 durable tail 是否是下表允许的 pending suffix → 闭合旧 Run → 创建新 Run 或 fail closed。Commit Boundary 是安全证明，不是删除 append-only tail 的“回退位置”。

任何 crash 后遗留的 `request_attempt_started` 若既没有 matching `assistant_committed` 也没有 `request_interrupted`，都不得在旧 Run 内继续：恰好追加一次 `request_interrupted`（无法证明时固定为 `semantic_state_unknown`）。已经 durable 的 attempt terminal 不重复追加；尚未 terminal 的旧 Run 恰好追加一次 `run_interrupted`。随后才可在**同一 Lineage 的当前 durable tail** 创建新 Run。

当旧 request 没有 `assistant_committed`（包括 pre-semantic、post-semantic incomplete staging）时，新 Run 可以重发旧 Snapshot，但必须先追加新的 `request_snapshot_stored`：`recoveryFromSnapshotId` 引用旧 Snapshot，逐字节复用同一 immutable `bodyRef/bodyHash/byteCount/commitBoundaryId`，禁止重新调用 Projector 或 serializer。Snapshot body 属于 §7.1 的专用 FrozenBytes 路径，不冒充用户 Artifact。

崩溃恢复的关键场景是**流中途被 kill**：此时可能有 `tool_call` 已发出但无 `tool_result`。处理方式由不变量 5 决定：

```
无 terminal 的 physical attempt                    → 追加 request_interrupted；闭合旧 Run；新 Run 可 alias Snapshot
未完成 assistant staging（无 assistant_committed） → staging 从未成为 blob；同上，不提交半条 assistant
合法 user/tool batch 已 Commit Boundary、尚无 Snapshot → 闭合旧 Run；新 Run 第一次调用 Projector，不使用 recovery alias
assistant_committed、缺 cache checkpoint           → 从事件内 Snapshot/usage 确定性补唯一 cache_checkpoint_created
assistant_committed + pending T1 read              → 新 Run 可重新执行该 observational read；仍只提交一个 result
assistant_committed + pending T2、无 effect_prepared → 由强制顺序证明未执行；新 Run 按声明顺序执行
effect_prepared、无 effect_completed/reconciled     → 追加 effect_indeterminate + run_interrupted；停止
effect_completed、无 tool_result_committed          → 绝不重跑；从 completed 引用的 raw Artifact 确定性生成有界 result
effect_reconciled(proven_not_executed)               → 新 Run 才可执行 pending T2
effect_reconciled(completed)                         → 按 completed 路径补 result，不执行外部 effect
合法 user_committed、完整 tool-result batch 或最终 assistant，缺 Commit Boundary → 从已验证 blob/effect tail 确定性补唯一 commit_boundary_created
最终 assistant 已 Commit Boundary、缺 run_completed → 确定性补唯一 run_completed；不创建恢复 Run
```

恢复派生事件使用其决定性 source event/batch id 作为幂等键；启动重放若 matching derived event 已存在就不重复追加，若 payload 不一致则 integrity violation/fail closed。先完成这些 deterministic derived tails，再决定旧 Run 是否需要 `run_interrupted` 和新 Run；因此 final answer 已 durable 的 Run 不被误报为中断。

`assistant_committed` 的 pending calls 是合法的非 Commit tail；新 Run 继续它们，不创建 sibling Lineage，也不跳过任何 blob。只有结果全部按声明顺序提交后才能投影下一 Snapshot/Commit Boundary。Cache Checkpoint 只用于成本投影，不能证明副作用安全；“工具通常幂等”不是证据。

### 8.3 Evidence-gated lineage capabilities

v0.1 baseline **不定义** Compaction 或 Fork 的 API、Journal event、CLI、registry、配置或测试入口；`lineage_activated.reason` 当前只允许 `initial|abi_change`。Stage 09/10 在 Gate 2 后各做一次有界真实证据审计：若 readiness 不满足，只在普通用户文档声明本 candidate 的能力 `unavailable` 并删除临时 Plan/index；包内保持零实现，不创建 capability registry/protocol。若满足，必须先用观察到的 caller/failure 新建或修订 Plan，更新本 Spec 冻结具体 event/API/byte shape，完成 fresh review，之后才可实现。

未来任何获准设计仍受这些不可协商的上界约束：

- Compaction 必须由真实 Session economics 与用户知情请求触发；只能在完整 episode + Commit Boundary 上创建新 Lineage，旧 Lineage/原始 Artifact 不改写；digest 是版本化 Artifact；没有自动触发、隐藏 store、第二模型或工具执行捷径。
- Fork 必须有真实 same-prefix branch caller；child 具有独立 Lineage/Run，只能引用安全 Commit Boundary；固定 Flash/thinking/max，不支持跨模型、隐藏 Agent、并行 writer 或 fleet。
- 任一 prefix discontinuity 都必须走 §3 的 attributed planned `cache_break`；provider cache 命中仍是 best-effort，不能成为正确性证明。

这些是 admission 约束，不预先承诺函数名、event 名、迁移算法或缓存收益。普通文件、Artifact、Shell 与 Git 能完成的需求不得借 Stage 09/10 扩大 Core。

---

## 9. `src/ctx` — Context 构造

### 9.1 冻结区 / 易变区

```
┌─ 冻结区（参与 cache_abi_id，永不变） ──────────────┐
│ system blob:                                       │
│   角色与边界（简短）                                │
│   lineage 创建前已 durable 的 project instructions exact bytes │
│   四个工具的使用约定（简短）                        │
│ tools blob:                                        │
│   四个 schema，顺序确定（按名称排序）               │
└────────────────────────────────────────────────────┘
┌─ blob 列（只追加） ────────────────────────────────┐
│ user / assistant / tool ...                        │
└────────────────────────────────────────────────────┘
┌─ 本轮事实尾块（与本轮 user input 一次性物化） ─────┐
│ <env>日期 / cwd / git branch+status / 变化的文件</env> │
└────────────────────────────────────────────────────┘
```

外部状态的取得与 Provider 投影严格分成两步：baseline Session Kernel 只采样日期/cwd/Git 并以 `fact_recorded` durable；Projector 再把“本轮原始 user input fact + 本轮已登记环境 facts”一次性 materialize 成新的 user blob。已经存在的 user blob 永不追加、拼接或修改。**新事实放在新尾部，所以只是追加；请求时回读 cwd/Git/env 则属于隐藏 I/O，必须失败。**未来获准的外部输入仍必须先遵守 §13 的 evidence gate 与 Journal-first 上界，baseline 不预留 extension input。

优化：只在环境实际变化时输出该块，或只输出 diff。否则一个长会话会累积 N 份几乎相同的环境摘要——不破坏缓存，但白占 token 并把你更早推向压缩。

原始 user/env fact 到 user blob 的 materialization 也是纯函数，并先于 Projector 和 Snapshot：source facts 必须是同一 Run 内的 `[user_input, date?, cwd?, git?]`，按该固定 kind 顺序、每种至多一次；Artifact bytes 由调用方显式提供并核对 creator/hash/count。exact user content 是 fatal UTF-8 user input，若存在环境项则追加 `"\n\n<env>\n" + join(kind + ":\n" + value, "\n") + "\n</env>"`，随后由唯一 serializer 按固定 key 顺序生成 exact UTF-8 `{"role":"user","content":<JSON string>}` FrozenBytes 并 durable `user_committed`。tool role 的唯一 canonical 形状和 key 顺序是 exact UTF-8 `{"role":"tool","tool_call_id":<JSON string>,"content":<JSON string>}`；其 `tool_call_id` 必须与 `tool_result_committed` payload 相等。user/tool blob 在 append/replay 和投影时都必须经各自 parser 重建并逐字节 round-trip，相同 JSON value 的其他空白或 key 顺序一律拒绝。Projector 不重新 materialize fact，也不修改既有 user blob。

Projector 的规范边界是一个版本化纯函数：

```ts
projectV1(input: {
  cacheAbi: FrozenCacheAbiManifest;
  journalFacts: readonly VerifiedEvent[]; // exact verified prefix ending at boundary creator
  externalBlobs: ReadonlyMap<BlobRef, FrozenBytes>;
  lineageId: LineageId;
  commitBoundaryId: CommitBoundaryId;
}): {
  blobs: readonly FrozenBytes[];       // system first, then selected role blobs
  body: FrozenBytes;
  headEventId: EventId;                // selected Commit Boundary event id
  segmentHashes: readonly [Sha256, Sha256];
};
```

调用方必须先完成 Journal/hash/reference/Commit Boundary 校验；传入的 `journalFacts` 必须是从 genesis 到所选 Commit Boundary creator（含）的完整 verified prefix，不接受缺事件、额外后缀或任意筛选数组。Projector 自身再次选择属于目标 Lineage 的角色事件，显式读取 inline bytes 或 `externalBlobs`，并重算 blob index/hash/chain、活动 Lineage、Cache ABI、boundary blobCount/chainHash、canonical role bytes、closure predicate 与两项 `segmentHashes`。ABI manifest 在 `cache_abi_declared` append/replay 和 Projector 入口都必须由唯一 loader 解析五个长度帧直到 EOF，并拒绝固定 protocol/Projector/model/system/tools 之外的任何值。缺少、额外或不匹配的 external blob 都 fail closed；普通 Artifact 不进入 Projector，因为它在 `user_committed` 前已被 materialize。`projectV1` 不得调用 fs、time、cwd、Git、env、network、CredentialLoader 或 extension callback；测试会把这些入口替换为抛错函数。输出 body 先按 §7.1 发布到 `snapshots/sha256/<hash>`，再把 `bodyRef/bodyHash/byteCount/cacheAbiId/lineageId/runId/projectorVersion/headEventId/commitBoundaryId/segmentHashes` 作为 `request_snapshot_stored` 在发送前持久化。

Commit Boundary 的 `protocolClosed:true` 与 `effectsSettled:true` 只是冗余断言，不能充当证明。append/replay 与 Projector 必须调用同一个 closure predicate：不存在未终止/半提交的模型响应；若 assistant 声明 tool calls，则该唯一 pending group 的每个 call 都按声明顺序恰有一个 canonical tool result；每个 prepared effect 都已 durable completed，或已有带证据的 reconciled terminal resolution。任一条件不满足时不得接受或投影 Commit Boundary。

新投影的 `projectorVersion` 必须是 literal `"dsh-projector-v1"`，`headEventId` 必须等于指定 Commit Boundary 的 creator event id，`segmentHashes` 必须恰为 `[cacheAbi.headerHash, commitBoundary.chainHash]`。请求字节只有三条合法路径：

1. normal physical retry 按原 `RequestSnapshotId` 读取 body，不调用 Projector；
2. crash recovery 且旧 Snapshot 已存在时走 §8.2 alias：alias 必须属于同一 Lineage 的不同 recovery Run；除新 `requestSnapshotId`、新 Run scope 与指向原 Snapshot 的 `recoveryFromSnapshotId` 外，必须逐字段复制原 Snapshot 的 body ref/hash/count、Cache ABI、Projector version、head/boundary 和两项 segment hashes，禁止调用 Projector；
3. crash recovery 且安全 Commit Boundary 之后尚无 Snapshot 时，从该 Boundary 首次调用 Projector **恰好一次**，产生 `recoveryFromSnapshotId=null` 的普通 `request_snapshot_stored`。该 Snapshot 一旦 durable，状态立即转为第 2 条；此后再次崩溃只能 alias，不能反复投影。

第 3 条只适用于“从未投影过”的 Boundary，不放松第 2 条的逐字节复用要求。

### 9.2 System prompt 的写法

由 F9（SimpleDSH 每次显式发送 thinking enabled + reasoning_effort max），DeepSeek 会自己做大量推理。**不要在 prompt 里写推理脚手架**——不要「逐步思考」，不要 planning 协议，不要 reasoning 格式要求。这些既冗余，又永久地塑造每一轮。

由 §2.3，长度不是问题，**认知税和稳定性是问题**。判断标准不是「这段有用吗」，而是：

1. 它是否高频、通用、必要到值得常驻？
2. 它是否与已有能力语义重叠？
3. 模型是否需要为它额外跟踪状态？

低频信息留在普通文件或 Artifact 中，由四原语显式读取。v0.1 baseline 不扫描 Skill/Command 目录、不生成索引、不识别 slash loader；Stage 11 只有真实 caller/failure 通过准入后，才先冻结具体形状与 Cache ABI 影响。

---

## 10. `src/tool` — 四原语与单一收口

### 10.1 工具面：四个，就四个

```
read (path, offset?, limit?)              有界读，返回带行号
write(path, content)
edit (path, old_string, new_string, replace_all)
bash (command, timeout)
```

`read/write/edit.path` 与 `bash.command` 都必须是 non-empty、无 lone surrogate、无 NUL 的 Unicode-scalar string；失败是 pure static `{status:"invalid",code:"invalid_arguments"}`，不写 `permission_decided`、Artifact 或 Effect。这个检查发生在任何 path normalization、filesystem access 或 process launch 之前。`write.content` 与 `edit.old_string/new_string` 使用相同 scalar/NUL 规则，但允许 empty（只有 `edit.old_string` 另行禁止 empty）。

`read.offset` 是 zero-based LF-delimited record offset，默认 `0`；`read.limit` 是 record 数，默认 `200`、最大 `2000`。空文件有零条 record；每个 LF 结束一条 record，非空且不以 LF 结尾的 suffix 是最后一条，因此 `a\n` 是一条、`a\n\n` 是两条。offset 在 EOF 或其后返回成功的空 slice。切片在 raw bytes 上流式完成并保留原 LF；只把选中 bytes 计入 raw-output hard limit。

有效 UTF-8 且不含 NUL 的 read slice 按每条 record 投影为 `<absolute-one-based-decimal>\t<original-record-bytes>`：无前导零，原来有 LF 就保留，原来没有就不补，空 record 仍保留编号与 tab。第一条显示号是 `offset+1`。UTF-8 判定在拼接完整 slice 后一次 fatal decode，允许 code point 跨 Artifact DATA frame；存在 NUL 或 invalid UTF-8 时 base64 编码**未加行号的 exact selected bytes**，不能替换无效字节。`bash.timeout` 单位为秒，省略时 `120`，必须是有限正数且不得超过 `600`；超界在 `effect_prepared` 前拒绝。

搜索、文件遍历、Git、测试、进程检查、网络请求，全部通过 `bash` 加现有 CLI 完成。

**关于 search 工具的一次自我修正**：早期设计里我为「有界输出」保留了一个独立的 `search` 原语。这个论证不成立——§10.3 的输出预算已经对 `bash` 生效并提供了确定性截断，所以 `search` 的举证责任没有被满足。**v0.1 不做。** 如果实测显示 `bash grep` 持续吃掉输出预算，再加，并且要带上那次实测数据。

`read` 保留（而非用 `bash cat` 替代）的理由是具体的：它默认有界、返回可被 `edit` 引用的行号、能检测二进制文件。这三条 `cat` 都不满足。

每增加一个工具，代价是：tool-selection 熵、schema 字节（进冻结区）、工具间语义重叠、模型选错的概率、维护成本。**一个专用工具只有在明显优于现有原语时才值得存在。**

### 10.2 ToolRuntime：单一收口

所有工具侧危险集中在一处（取自 Maka，这是它最好的结构决策）：

```
toolRuntime.execute(call, signal: AbortSignal) :
  1. pure 参数校验（手写校验器 → 结构化错误回给模型，不致命）
  2. 不打开 final target，做 lexical subject + existing parent realpath/identity 解析
  3. 把 resolved subject 交给 §11 的 fixed pure decision producer
  4. allow 后完成 final lstat/open 等 syscall guard；alias/guard failure 只写一个 Artifact observation
  5. T1 read：直接执行；T2 write/edit/bash：durable effect_prepared 后才执行
  6. macOS/Linux bash 只走 native `/bin/bash --noprofile --norc -lc`；watchdog / timeout / AbortSignal 驱动 PGID TERM→KILL
  7. read bytes 直接流式写入 immutable Artifact；bash runner 在内存中有界拥有至多 16,777,216 payload bytes、按事件顺序合并不超过 65,536-byte records，精确到限即启动停止，并在有界 cleanup observation 内继续 drain/discard；直接子进程终态与 observation 确定后才把冻结 records 写入 Artifact，完成后不得再写
  8. 在有界窗口观察 negative PGID + 双 stdio EOF，写 `descendantsReaped`；false 仍继续完成，不冒充 containment
  9. durable effect_completed（T2）与 tool_result_committed；结果只含有界投影+Artifact handle
  10. 错误分类（用户错 / 环境错 / 工具 bug）与 best-effort 遥测
```

第 5、6 步的实际实现全部委托给 `src/proc/`——它是 TS 版本相对 Go 版本新增的模块，因为 Node 上 PGID TERM→KILL、cleanup observation、跨平台终态映射与背压都要自己写（§16 用例 7）。

只有能证明状态确定的错误才回喂模型。Provider 合法但名称不在四工具中的 call 仍先作为 assistant FrozenBytes 的 pending call durable，再由 Gateway 产生 static validation result；不能在 assistant binding 时丢掉 call。无 Artifact 的 content 只有固定两-key JSON `{status,code}`：pure static `invalid/unknown_tool|invalid_json|invalid_arguments` 或 mechanical `denied/permission_denied`，都不携自由 error text。

参数与 mechanical permission 拒绝发生在 `effect_prepared` 前。T1 read 无外部 effect，但成功或失败都先发布带 terminal 的 tool-output Artifact；依赖 filesystem I/O 的 file preflight rejection 也先发布带 terminal 的零-byte tool-output Artifact，不能把 live observation 伪装成可由 assistant bytes 重算的 static result。Windows bash unavailable 同样是带 legacy code 的零-byte pre-effect Artifact；非 Windows 不做 runtime/capability admission。T2 执行失败只有在 raw Artifact 与携同一 terminal classification 的 `effect_completed` 都 durable 后才是确定失败。prepared 后缺少 completed/reconciled、文件 publication/cleanup 状态未知、Artifact/Journal/fsync/integrity 失败必须追加合法 fail-closed 事实、`run_interrupted` 并停止；**仅 `descendantsReaped=false` 不属于这些情况**，不得阻止 completed 或下一模型请求。模型负责纠正确定错误，不负责猜外部世界。

`src/proc` 的内部 `BashRunReason` closed set 保持 `natural|timeout|cancelled|output_limit|io_error`；它只驱动唯一 terminal classification，不形成第二份 durable outcome。`natural` 再由直接子进程的 exit/signal 映射为 `ok|nonzero_exit|signaled`。cleanup observation 与 reason 正交：任何 reason 都可以伴随 `descendantsReaped=false`，而 `timeout|cancelled|output_limit` 仍必须有严格 XOR 的 direct-child exit/signal。

**只读工具的并行批量派发**：只有一个 assistant blob 内**连续且全部经 schema 证明为 `read`** 的批次可按固定上限 `4` 并行；遇到第一个 T2 call 就先提交前序结果，再按模型顺序串行执行余下 calls。结果无论完成先后都按原始 `tool_calls` 顺序连续提交（不变量 3）。不允许用 bash 命令文本推断“只读”。

durable source 绑定固定为：pure static validation → 创建该 call 的 `assistant_committed`；mechanical permission denial → `permission_decided`；T1 或依赖 filesystem/platform observation 的 pre-effect settled result → `artifact_published`；T2 settled → 匹配的 `effect_completed` 或 reconciled-completed `effect_reconciled`。`effect_indeterminate` 不产生 tool result。`argumentsHash` 只对 assistant FrozenBytes 中 exact `function.arguments` 字符串的 UTF-8 bytes 求 SHA-256，禁止 parse/re-stringify。

`tool_result_committed` verifier 必须 parse canonical inner content，并把 `toolCallId`、status/code 以及 Artifact-backed 时存在的 exit/signal、Artifact id/ref/hash/count/stream counts/hard-limit 与其 source graph 逐字段绑定：static invalid 对 assistant call，denied 对 permission event，T1/pre-effect observation 对 Artifact terminal，T2 对 Effect terminal；completed reconciliation 的 terminal 必须与它引用的 output Artifact 可重建事实相容。bash T2 还必须在 durable source graph 内验证 output Artifact metadata 的 `descendantsReaped` 与 Effect terminal 完全相同；§10.3 provider inner content 没有这个 key，verifier 不得把它投影或要求在 provider bytes 中出现。恢复后的结果只能由 durable event/Artifact 字段重建；terminal source 没有记录的 live `Error.message`、timeout 标签或异常对象不得进入首次或恢复投影。

### 10.3 输出预算（字节级执行不变量）

```
raw_output_hard_limit_bytes       默认 16_777_216（stdout+stderr/read 合计）
tool_result_projection_limit_bytes 默认 32_768
所有原始输出 → .dsh/sessions/<id>/artifacts/sha256/<hash>
模型投影 → 固定 metadata + stable head/tail + active-Session Artifact handle
```

raw `tool_output` 的唯一 v1 media type 是 `application/vnd.simpledsh.tool-output.v1`，CAS bytes 是下列 record 的零次或多次串接，没有全局 header 或 EOF record：

```text
record = stream:u8 | flags:u8 | payloadLength:u32be | payload
stream = 1(read) | 2(stdout) | 3(stderr)
flags  = 0(DATA) | 1(HARD_LIMIT)
```

DATA 的 payload length 可为 `1..2^32-1`；HARD_LIMIT 必须是最后一条、恰好 6-byte、零 payload、且只在 combined raw payload 到达上限时存在一次，stream 取触发上限的输入。到达**恰好**上限也立即标记并终止 producer；越界 chunk 只接收剩余额度的 exact prefix 后写 marker。stdout/stderr record 顺序是两个受背压 pipe consumer 进入单一串行 mux 的 callback/write 顺序，只声明 harness 观察顺序，不声称恢复进程内部的全序。binary/NUL/无效 UTF-8 原样进入 payload；hash 覆盖所有 frame header、payload 与 marker。空输出是零 byte Artifact。

每次 decode 必须从 byte `0` parse 到 EOF；truncated header/payload、未知 stream/flags、零长 DATA、非末尾或重复 HARD_LIMIT、marker 与 metadata 不一致、trailing bytes 都 fail closed。`read` 只允许 stream `1`，`bash` 只允许 `2/3`，`write/edit` v1 raw output 必须为空；HARD_LIMIT 只允许 `read/bash`。`streamBytes` 只计三类 DATA payload；durable metadata 没有 framing 字段，`framing_byte_count = byteCount - read - stdout - stderr = 6*recordCount` 只在完整验证后派生。

Artifact-backed provider `content` 是以下固定 key 顺序的 canonical JSON：

```text
{status,code,artifact_id,artifact_ref,artifact_sha256,byte_count,
 payload_bytes:{read,stdout,stderr},framing_byte_count,
 hard_limit_reached,exit_code,signal,encoding,head,tail,truncated}
```

无 Artifact 的 pre-effect result 恰为 `{status,code}`，其 closed pair 只有 §10.2 所列 pure static validation 与 mechanical denial。filesystem/backend observation 必须 Artifact-backed；raw exception text、errno message、live timeout label 都禁止。

Artifact display bytes 的转换顺序固定如下：先完成 codec/hash/metadata/source binding；忽略 HARD_LIMIT 的零 payload，把 DATA payload 按 Artifact record order 拼接。bash 不按 stream 重组也不加 synthetic label，因此 head/tail 保留 harness 观察到的 stdout/stderr mux order，stream provenance 仍在 raw framed Artifact。read 使用 §10.1 的逐-record one-based 行号转换；write/edit 是空 display bytes。拼接后的 bash bytes 或 read selected bytes只有在 fatal-valid UTF-8 且不含 NUL 时使用 `encoding="utf8"`；read 再加行号。否则 `encoding="base64"`，base64 域是未加行号、已去 frame 的 exact payload concatenation。空 display 固定为 UTF-8。

先尝试 `head=<完整 encoded display>`、`tail=""`、`truncated=false`，将 inner content 作为 string 交给 §9.1 唯一 canonical tool serializer，得到 exact outer `{"role":"tool","tool_call_id":...,"content":...}` bytes 后才测量。若超过 `32,768`，设 `truncated=true`，二分寻找可保留的最大单位数：UTF-8 单位是 Unicode scalar，base64 单位是 4-char quantum；head 取 `ceil(n/2)` 个最前单位、tail 取 `floor(n/2)` 个最后单位且不得重叠。每个候选都重新完成 inner 与 outer JSON escaping 后测 UTF-8 bytes。若空 head/tail 的 fixed metadata 仍超限，追加 `run_interrupted(durability_failure)` 并 fail closed，不发下一请求；禁止再缩字段、ref 或 tool id。

`artifact_ref` 是当前 Session 中已被 Journal 精确绑定的 opaque handle，不是任意用户 path。`read(artifact_ref,offset,limit)` 先解析 exact active-Session binding；若目标是 tool-output Artifact，必须验证并去除 frame 后才做 logical record slicing，不能把 header bytes 当文件内容。普通 path 与 Artifact handle 不能模糊前缀匹配。

Harness 不内置 tokenizer，因此运行时截断/kill 不得使用“约等于 tokens”。达到 raw hard limit 时先停止接收超限部分，对原 PGID 执行 TERM→KILL 并做有界 cleanup observation；Artifact 记录已消费的精确 byte prefix、`hard_limit_reached=true`、流别计数与 `descendantsReaped`，模型实际 input tokens 只从后续 Provider usage 观测，不反向改变执行边界。

模型按需用 `read(path, offset, limit)` 读 handle 指向的切片。`read` 对 `.dsh/` 默认 deny，只为当前 Journal 已发布、hash 匹配的精确 Artifact path 开只读例外；不能借前缀读取 Journal、locks 或其他 Session 文件。Artifact 的路径、hash、长度和 bytes 在 tool result 之前 durable；即使输出很小、命令失败、timeout 或 abort，已经观察到的原始 bytes 也必须成为 Artifact。超预算时立即终止 producer、保持 RSS 有界，并发布已读 partial Artifact；不能只保留截断字符串。

这是 Pi 的渐进披露原则应用到**输出侧**——两个参考项目都只做了输入侧（system prompt / MCP 工具说明），输出侧是漏掉的一半。

会话级追加量也要记账：`appended_tokens_total` 只用于展示 compaction economics；v0.1 不据此自动触发压缩（§2.1）。

---

## 11. 权限、误操作防护与执行边界

**分层原则：权限是策略，路径/进程措施是机械 guard，执行隔离是另一个产品边界。** v0.1 只实现前两者并明确不提供第三者；不得把应用内检查、closed child env 或 PGID cleanup 包装成 sandbox。

### 11.1 权限：规则即数据

**Stage 05 boundary.** Stage 05 不实现下面的规则语法或 approval 解析器，只提供一个固定 mechanical decision producer：static validation 失败不写 `permission_decided`；任何 `read/write/edit` 的 direct resolved subject 指向 canonical `.env` 或受保护 `.dsh` 路径（唯一例外是 §10.3 已绑定的 exact Artifact handle read）写 `{policyDecision:"deny",finalDecision:"deny",resolution:"policy"}`；其他所有已验证且 subject-resolved call（包括非 Windows bash）写 `{policyDecision:"allow",finalDecision:"allow",resolution:"policy"}`。decision 必须在任何 final-target access、执行或 `effect_prepared` 前 durable。Windows bash unavailable 发生在 fixed allow 后，发布带 frozen legacy code 的零-byte pre-effect Artifact，不启动命令；非 Windows 没有 backend/admission refusal。

“受保护 `.dsh`”恰为本 Session 已绑定 storage root 的 canonical absolute path及其 component-aware descendants，不能用字符串 prefix（例如 `.dsh-other` 不匹配）。顺序固定为：先做 scalar/NUL static check；再以 frozen cwd 做 lexical absolute resolution，并只 realpath 已存在的 parent components。若 resolved subject 已直接落入 canonical `.env`/`.dsh`，只产生一次 permission deny，不访问 final target。若 fixed allow 后才由 parent alias、final symlink 或 identity check 发现可能落入 protected path，则不得打开目标内容或补写第二个 permission decision，而以零-byte Artifact terminal `invalid/invalid_arguments` settled。无法证明 alias/identity 时 fail closed 为 Artifact-backed `failed/io_error`。

Stage 05 的 emitter 类型/API 不能构造 `ask`、`interactive`、`yes_flag` 或 `non_interactive` variant，也不读取 permission TOML、`allow_write`、`--yes` 或 workspace policy。v1 Journal codec 暂时保留这些 Stage 08 已冻结的通用 variants；Stage 08 只替换 decision producer，不能改变 Gateway/event/source contract。文件的 regular/symlink/hardlink/open/rename 检查是 syscall 安全，不冒充 permission policy 或 adversarial sandbox。

以下通用 Policy 是 Stage 08 contract，Stage 05 不提前实现：

```ts
export type Decision = 'allow' | 'ask' | 'deny';

export interface Policy {
  mode: Decision;              // writer 的 fallback，默认 'ask'
  allow: Rule[];
  ask: Rule[];
  deny: Rule[];
}

// 纯函数：无 I/O、无 fs、无时间依赖，因此可以穷举单测
export function decide(
  p: Policy,
  toolName: string,
  readOnly: boolean,
  args: unknown,          // 已校验过的参数对象，不是 FrozenBytes
): Decision;
```

注意 `args` 是已校验的参数对象而非 `FrozenBytes`——权限判定发生在 §10.2 收口的第 2 步，此时参数已经过第 1 步校验。这是唯一允许把工具参数解析成对象的路径，与 blob 的冻结规则不冲突（工具参数来自模型输出的 `tool_calls`，其首次 canonical materialization 字节已经在 assistant blob 里冻结了）。

规则语法沿用 Claude Code 风格（生态兼容零成本）：`Bash(npm run build)`、`Bash(go test:*)`、`Edit(docs/**)`。`:*` 后缀是命令前缀授权，且**生成的前缀规则必须拒绝引入 shell 操作符的后续命令**——`Bash(go test:*)` 不覆盖 `go test ./... && rm -rf tmp`。

主体（subject）从 args JSON 里按一小组已知键提取：`command`（bash）、`path` / `file_path`（文件工具）。工具本身不需要为此改动。

**优先级：`deny` > `ask` > `allow` > fallback。** fallback 对只读工具为 `Allow`，对写工具为 `Mode`（默认 `Ask`）。`deny` 永远赢——所以宽泛的 `allow = ["Bash"]` 仍可被 `deny = ["Bash(rm -rf*)"]` 挖洞。

**与 Reasonix 的一处明确分歧：非交互模式下 `Ask` 解析为 `Deny`，不是 `Allow`。**

Reasonix 让无 TTY 的运行把 `Ask` 解析为 allow 以保持自主性。我不同意：静默放行的失败模式（无人看管的运行做了破坏性操作）比失败模式（运行大声失败、你补一个 `--yes`）更糟。所以：

```
dsh run "..."            → Ask 解析为 Deny，运行失败并明确报告被拒的调用
dsh run --yes "..."      → Ask 解析为 Allow
permission.non_interactive = "allow" | "deny"（默认 deny）
```

`Deny` 在**任何**模式下都是硬阻断：工具不执行，模型收到一个「blocked」结果并可以据此调整。

**不做的**：plan mode、auto-plan、goal mode、三档 approval posture、collaboration mode、approved-plan 临时授权窗口。理由见 §15。

### 11.2 bash 执行边界：无内建隔离，诚实标注

**产品选择（“我们不做”）：** v0.1 不提供 bash 执行隔离，也不保留 optional backend、capability token、admission tuple、runtime/version/image probe、`external-required` 状态或对应配置。所有非 Windows 平台走同一条当前 dsh 进程直接启动 `/bin/bash --noprofile --norc -lc <command>` 的路径；只有 Windows 返回 unavailable。缺少 Lima、nerdctl、containerd、runc、RootlessKit、特定镜像、mount 或 inode 条件绝不能让 macOS/Linux bash unavailable。此前通过三轮评审并验证过的 Linux 虚拟机/container 方案仅证明某个固定 tuple 的机制可行，但它要求主机预装和锁定外部组件，不能在干净机器 `npm install -g simpledsh` 后立即工作，因此**因不可分发而放弃**。未来若重新引入任何内建隔离，必须作为新的产品契约提出、取得新证据并 fresh review；不得把旧证据解释成一个待开启的 backend。

**能力边界（“我们做不到”）：** 同一 Unix 用户启动的原生 bash 能访问该用户能访问的一切，包括项目 `.env`、`.dsh`、SSH key、其他文件、父进程信息、网络和系统 CLI。closed child env 只避免普通环境继承，不能阻止命令主动读取文件、`/proc`/平台进程接口或其他秘密。PGID TERM→KILL 只作用于仍在原组的进程；negative group check 与双 EOF 也看不到已经 `setsid`/double-fork 且关闭 pipe 的逃逸者。`descendantsReaped` 因此是有限观察，不是 containment、sandbox 或防对抗攻击者的保证。

启动时的 `.env` hygiene 仍保留且只执行一次：解析 real project root 下的 canonical `.env`；存在时要求 Git ignored、non-symlink regular file、mode `0600`，并以 `lstat → open(O_RDONLY|O_NOFOLLOW) → fstat/read` 再确认打开的是 regular file 且 mode 未漂移。无论 key 最终取自 process env 还是该文件，present 但不满足这些条件的 `.env` 都在 Provider/Tool 初始化前拒绝；这保护秘密引导文件免于常见配置错误，不绑定 dev/inode/nlink，不是 bash launch admission，也不在每次命令前重做 identity。file tools 始终 mechanical deny canonical `.env` 与受保护 `.dsh`；**bash 不受这条 path deny 约束**。

bash child 从空 object 只建立七个 harness-owned name：`HOME|HOSTNAME|LANG|LC_ALL|LOGNAME|PATH|USER`。不得自动继承 `DEEPSEEK_API_KEY`、`BASH_ENV`、`ENV`、`BASH_FUNC_*`、`LD_*`、`DYLD_*` 或任何未列名 parent entry，name/value 也不得进入诊断。这里的保证仅是“Harness 不自动传入这些变量”，不是“bash 无法取得这些值”。

native runner 的 exact lifecycle 是：尝试以 `detached:true` 建立 PGID；stdin 关闭，stdout/stderr 进入 byte-bounded mux；natural/timeout/cancelled/output-limit/io-error 归入唯一 `BashRunReason`；需要停止时 TERM → bounded grace → KILL；直接子进程 exit/signal 与双 EOF 各自有界等待；随后 negative-PGID probe。spawn 未成功时返回 `io_error,null/null,descendantsReaped=true`；spawn 成功时返回已知 direct-child terminal 与按上文定义的 observation。该 boolean 同时进入 output Artifact metadata 和 `effect_completed.terminal`，但不进入 provider-visible tool result。若已 spawn 的直接子进程 terminal 本身无法取得，才是 `process_state_unknown`；仅 cleanup observation 为 false 仍 completed。

需要不可信执行隔离的用户必须把**整个 dsh 进程**放进自己选择和管理的 container、VM 或独立 Unix user。这个建议是部署边界，不是运行 bash 的前置条件，也不由 dsh 探测、配置或背书。

**Phase 0A（Stage 05 必须有）——文件工具的原子替换与误操作 guard**

Stage 05 不消费 Stage 08 `allow_write`。file call 的 path 只按本 Run frozen cwd 解析一次；relative path 以 cwd 为基准，absolute path 保持 absolute，parent 必须已存在并 `realpath` 成 canonical directory，final target 单独 `lstat`。canonical `.env`/`.dsh` 先按 §11.1 deny；existing final target 只允许 non-symlink regular file 且 `nlink==1`，new target 只允许 final `ENOENT`。缺 parent、directory/device/socket/FIFO/symlink/hard-link 在 `effect_prepared` 前以 Artifact-backed `invalid/invalid_arguments` settled；无法稳定完成这些 I/O check 则以 Artifact-backed `failed/io_error` settled。这个 guard 不宣称 workspace confinement。

`write.content`、`edit.old_string/new_string` 必须是无 lone surrogate、无 NUL 的 Unicode-scalar string并严格编码 UTF-8。edit target 用 `O_RDONLY|O_NOFOLLOW` 打开并记录 `dev/ino/nlink/size/mode/SHA-256`；target bytes 必须 fatal-valid UTF-8 且无 NUL。`old_string` 不能为空；这条 pure argument failure 不造 Artifact。match 是 exact UTF-8 bytes 的 left-to-right non-overlapping match。零 match 在 prepared 前以零-byte Artifact terminal `failed/edit_no_match` settled；`replace_all=false` 且多于一处同样以 `failed/edit_not_unique` settled；`replace_all=true` 要求至少一处并替换全部。write existing target 也在 preflight 流式记录 identity 与 content hash；new target 记录 expected `ENOENT`。只有所有 preflight observation 成功后才进入下列 Effect sequence。

通过 static/mechanical preflight 后，write/edit 的 exact sequence 是：

1. durable `effect_prepared`；
2. 在同一 canonical parent 以 `O_CREAT|O_EXCL|O_WRONLY|O_NOFOLLOW`、初始 mode `0600` 创建唯一 `.dsh-tmp-<32-lower-hex>`；
3. serial short-write loop 写完整 replacement bytes，`bytesWritten==0` 即失败；
4. existing target 的 temp `fchmod(original.mode & 0777)`，new target 使用启动时 frozen `0666 & ~umask`；随后 file fsync、fstat 核对 size/hash、关闭 writable handle；
5. publication 前重新 `lstat`/open/hash：existing 必须与 preflight 的 dev/ino/nlink/type/content hash 相同；new 必须仍 ENOENT，否则 `target_changed`；
6. existing target 用同目录 `rename(temp,target)` 原子替换；new target 用 `link(temp,target)` 原子 no-clobber 发布后 unlink temp，避免 POSIX rename 覆盖竞争创建者；
7. fsync canonical parent directory；
8. 发布 empty tool-output Artifact（CAS bytes 恰为零），再写携 terminal 的 durable `effect_completed`。

rename/link 前的错误只有在 target unchanged、temp unlink 与 parent fsync 都已证明时，才能先发布零-byte output Artifact、再 completed-failed；否则 `filesystem_state_unknown`。rename 或 link 成功后任何 unlink/parent-fsync/ack 不确定性也是 `filesystem_state_unknown`。`effect_prepared` 后任何 output Artifact publication 失败都是 `artifact_durability_failed`；若 mutation 尚未发生，后续仍只能凭 operator evidence reconcile 为 `proven_not_executed`，不能从 live memory 猜。prepared 后 crash 仍是 `crash_gap`。所有 indeterminate 路径都不得写 completed 或生成 tool result。Stage 05 不自动删除 crash 遗留 temp；reconcile 需要显式 operator evidence。

replacement 改变 inode，只复制 existing target 的 POSIX permission bits。v0.1 不检查、复制或声称保留 existing target 的 ACL、extended attributes、file flags 或 hard-link identity；这些 metadata 可能随替换丢失或改为平台/父目录默认值，这是明确的用户可见限制，不用无法实现的“需要保留时拒绝”条件冒充保护。上述 check/recheck 是 deterministic misuse guard，**不宣称抵抗并发攻击者在最后一次 check 与 rename 间的 TOCTOU**。未来若要保留这些 metadata 或声称 adversarial file isolation，必须先修订/审查契约，并把所需 metadata/open/write/publication 操作放进可验证 OS boundary。

Stage 08 在这套 syscall/atomic 基线之前增加 workspace/`allow_write` 的 deterministic containment 与 Policy；它不重写 Stage 05 的 replacement、durability 或 Effect 顺序，也不得把该 containment 宣称为抵抗并发攻击者的 sandbox。

v0.1 没有 bash sandbox phase、`--unsafe-sandbox`、`sandbox.bash`、runtime backend selector 或 `enforced|external-required|unsupported` doctor matrix。`dsh doctor` 只能报告事实边界：非 Windows 是否存在并可执行 `/bin/bash`、child env 的 closed-name policy、cleanup observation 的定义，以及“无内建隔离”；不能把 path guard 或一次 PGID PASS 报成安全能力。

**诚实声明（必须逐意出现在 README 与 `dsh doctor` 输出里）：**

> `bash` 以当前用户直接运行，能访问该用户能访问的文件、秘密、进程和网络；SimpleDSH v0.1 不提供 bash 执行隔离。file-tool path checks、closed child env 与进程组 cleanup 只是低成本误操作/生命周期措施，不是安全保证。需要隔离时，请把整个 dsh 放进你管理的 container、VM 或独立 Unix user。

### 11.3 凭据与日志的信息边界

```
Harness 的自动凭据路径只允许 CredentialLoader 从环境变量读取 DEEPSEEK_API_KEY。
本地开发可由仓库根 `.env` 把该变量注入进程；`.env` 是秘密引导文件，不是运行时配置。
`.env` 必须被 Git 忽略且权限为 0600；若被跟踪或 group/other 可读写，启动拒绝。
Loader、官方 HTTP backend、capture/redaction 与 child-env builder 永不自动把密钥写入 dsh.toml、Journal、Artifact、Context、诊断或日志。
.dsh/ 目录 0700，文件 0600。
```

只有 `CredentialLoader` 被授权在启动时自动读取 `.env` 或进程环境；它不得自行把内容作为工具结果或模型输入。只有 `DeepSeekOfficialBackend` 被授权自动消费已加载的 key，并只在发送瞬间把它放进发往官方端点的 `Authorization: Bearer ...` header。该 header 不属于 Request Snapshot 的模型可见 body，任何 HTTP/telemetry capture 都必须先 redact；bash child env 不自动继承 `DEEPSEEK_API_KEY`。发布与 CI 不分发 `.env`；外部 secret store 只能在进程外把值注入环境，运行时仍只经过同一个 CredentialLoader。

**必须说清的一条边界：blob 是明文的。** 工具取得的任何内容都可能进入 raw Artifact、bounded tool result 与 `log.jsonl`；我们不假装有加密，也不事后扫描、过滤或改写 Journal：

- Stage 05 mechanical deny 只约束 `read/write/edit` 对 canonical `.env` 与受保护 `.dsh` 的直接访问；Stage 08 激活后默认 Policy 可增加 `Read(**/*.pem)` 与 `Read(**/.ssh/**)`。这些都是防常见误操作的规则。
- bash 从 closed allowlist 建 child env，但明确可以执行 `cat .env`、读取 `.dsh` 或访问其他当前用户可读秘密；若命令这样做，输出会按普通 raw evidence 保存，Harness 不承诺阻断或自动删密。
- 需要对抗性隔离时，把整个 dsh 跑在操作者管理的 container、VM 或独立 Unix user 里。
- `.dsh/` 必须在 `.gitignore` 里，且不要把它同步到云盘。

Maka 的 `credentials.json` 明文方案是我们明确不采用的反例。

---

## 12. `src/cost` — 成本与可观测性

**缓存命中率是这个系统的主控信号，不是可选遥测。** 所以成本账本进核心；但 trace 不进关键路径（取自 Maka：RunTrace best-effort，写失败绝不阻塞对话）。

### 12.1 SLI

| 指标 | 目标 | 说明 |
|---|---|---|
| `cache_hit_ratio`（per request, per lineage） | 第 2 轮起 ≥ 0.90 | 第一主控信号 |
| `unplanned_cache_break_count`（per session） | **0** | 非零即 bug |
| `http_400_count` | **0** | 每次都触发前缀完整性自检 |
| `appended_tokens`（per tool call / per session） | 有预算 | 压缩触发的输入 |
| `finish_reason == "length"` 计数 | 观察项 | 决定将来是否需要续写机制（§17） |
| `reasoning_share` = reasoning / completion | 观察项 | 只观察；不得据此改变固定 max effort |
| `queue_wait`（keep-alive 累计时长） | 观察项 | 区分排队与挂死 |
| `$/task`，拆分为 hit / miss / output | 观察项 | 带高峰时段标记 |

**命中率必须按 (血统, 模型) 分桶。** 由 F6，一个 session 汇总的「缓存命中率」在多血统下是没有意义的数字。

`cache_hit_ratio ≥ 0.90` 是长期诊断目标，不是单次 live 硬门；确定性门是 Snapshot/prefix 字节只追加和 `unplanned_cache_break_count == 0`。best-effort provider miss 以样本分布报告。

### 12.2 价格表

```toml
# 价格是带日期的配置数据，永不硬编码
[cost.prices.deepseek-v4-flash]
cache_hit = 0.0028
cache_miss = 0.14
output = 0.28
currency = "USD"
per = 1_000_000
verified_at = "2026-08-03"

[cost.peak]           # F12：高峰期价格 ×2，生效日期待官方公告
multiplier = 2.0
windows = ["09:00-12:00", "14:00-18:00"]
tz = "Asia/Shanghai"
enabled = false        # 官方公告生效后再打开
```

计费公式（不得把命中的 prompt token 二次计费）：

```
input_cost = hit_tokens × P_hit + miss_tokens × P_miss
output_cost = completion_tokens × P_out     # reasoning_tokens 已含在内
```

### 12.3 TUI 上必须常驻的三个数字

```
[ hit 97.2% | $0.041 | 312K ]
   命中率      本会话成本   前缀长度
```

命中率必须是**一等公民**，和 token 数、成本同等显眼。它是用户判断「我刚才那个操作是不是砸了缓存」的唯一即时反馈。

---

## 13. Evidence-gated extensibility boundary

v0.1 baseline 没有 `src/ext`、hook callback/registry、Skill/Command loader、MCP transport、static-tool plugin、exec-backend plugin、配置或测试入口。Stage 11 对每个 slice 单独审计真实 caller/failure；未满足时只在普通用户文档声明本 candidate 的 slice `unavailable`，包内保持缺席且不创建 capability registry/protocol。满足时先修订本 Spec，冻结该 slice 的实际输入、schema/bytes、生命周期和失败语义，并 fresh review；本节不预留名称或协议。

任何未来获准 slice 都必须遵守：外部输入先成为有来源/大小的 durable fact/Artifact 再进入纯 Projector；冻结区或工具 schema/order 变化创建新 Cache ABI、planned `cache_break` 与新 Lineage；所有执行仍经过 validator、permission、proc、T1/T2 Effect Gateway、raw Artifact 与有界 tool result。它不得直接写 Journal/历史/Request Snapshot，不得自动读取或继承 harness credential/process env，不得动态换工具、绕过 Gateway、调用第二模型循环、维护隐藏 transcript/Memory/store、启动背景 agent/service，或把其他 slice 的证据当成自己的准入。Extension 不能提供或选择 bash isolation/exec backend；未来若需要，先修改产品契约而不是走普通 slice 准入。

---

## 14. 配置

解析顺序：**命令行 flag > 项目 `./dsh.toml` > 用户 `~/.config/dsh/config.toml` > 内置默认值**。密钥只从进程环境来；本地开发时，仓库根 `.env` 可在解析配置前将 `DEEPSEEK_API_KEY` 注入进程环境，并必须通过 §11.3 的 ignore 与权限检查。

```toml
[generation]
max_tokens = 65536

[tool]
raw_output_hard_limit_bytes = 16777216
tool_result_projection_limit_bytes = 32768
bash_timeout_seconds = 120

[permission]
mode = "ask"
non_interactive = "deny"         # §11.1：与 Reasonix 的明确分歧
allow = []
ask = []
deny = ["Bash(rm -rf*)", "Read(.env)", "Read(**/.ssh/**)"]

[timeout]
connect_seconds = 30             # TCP/TLS 建连；超时主动 destroy request
ttfb_seconds = 620               # F10：服务端 10 分钟上界 + 终态余量；keep-alive 不重置
idle_seconds = 90                # 首个 reasoning/content/tool-call delta 后才生效
```

三个 timeout 必须为有限正数，且 `ttfb_seconds >= 600`；低于官方排队上界的配置启动即拒绝。实现不使用全局 fetch/undici，因此没有第二组隐含 headers/body timeout 可与它们冲突。

**刻意没有的配置项**：`model`、`thinking`、`reasoning_effort`（开发元组是冻结常量）、`base_url`（只准官方端点）、`provider` / `kind`（只有 DeepSeek 官方后端）、`context_window`（常量 1M）、`temperature` / `top_p`（F8：无效）、`plan_mode`、`subagent_concurrency`、`output_style`、`runtime`（Node 版本是硬要求，不是选项），以及任何 `sandbox`、bash backend、image/runtime/admission/capability 配置。环境变量同样不得覆盖前三项或端点。

---

## 15. 明确拒绝的复杂性

> 对工作流与 Core feature，重新准入必须承担举证责任：需要一个已经观察到的、可复现失败案例。**这条一般准入规则不适用于 Provider 产品边界或内建执行隔离**：其他 Provider、SDK、兼容端点、`base_url`、Pro/high、模型切换、跨模型 fork，以及任何 bash sandbox/VM/container runner，只能通过新的产品提案与 Architecture Charter 修订立项，不能凭普通 feature 证据、配置或 Extension 回流。

| 拒绝 | 来源 | 理由 |
|---|---|---|
| `Provider` interface + Factory + kind 注册表 | Reasonix / Maka | 产品契约只有 `DeepSeekOfficialBackend`；其他 Provider 不是待实现选项，而是明确越界 |
| plan mode / auto-plan / goal mode / 三档 approval posture / collaboration 三档 / approved-plan 授权窗口 | Reasonix | 需要一张表才能解释的组合状态机；且改变前缀形状 |
| 确定性 routing 启发式（「短追问直接给 executor，有界实现给轻量 plan」） | Reasonix | harness 里手写的第二个 agent；且改变前缀形状 |
| `max_subagent_concurrency = 6` / `max_parallel_writers = 3` | Reasonix | 多 writer 并发改同一仓库：局部合理，整体腐化 |
| `output_style` persona 折进 prompt | Reasonix | 直接改动冻结区字节 |
| 归档到独立 archive 目录 | Reasonix | 单 Journal + append-only Lineage 已保存历史，不建立第二份 archive（§8.1） |
| 独立 `search` / `glob` / `ls` / `multi_edit` 工具 | Reasonix | 与 bash + 输出预算重叠，举证不成立（§10.1） |
| Desktop / Tauri / QQ 通道 / Remote SSH / ACP / VS Code 扩展 | Reasonix | 不是 harness |
| Electron + React renderer + design-system / screenshot / a11y 契约体系 | Maka | 不是 harness |
| 7 个 bot 入口 + 开放 HTTP/SSE gateway 进核心 | Maka | 攻击面 + 鉴权 + 生命周期，全是核心永久负担 |
| 第二本账（Task Event Log + TaskRun + cutover_journal + SQLite 迁移机制） | Maka | 账本叠账本；迁移机制自身长成了子系统 |
| Autonomous Task Loop（preflight → runtime → SelfCheck → Feedback → Decision） | Maka | harness 里的第二个 agent |
| **自动优化自己的 system prompt** | Maka | 直接摧毁前缀缓存（改冻结区 = 换血统）。在 DeepSeek 上是经济性自杀 |
| Vercel AI SDK / OpenAI SDK 及 Maka 的多 Provider registry/router | Maka | 只借鉴 LLM Backend 的集中边界，不继承多 Provider、SDK 与跨厂商归一化（§6） |
| 明文 credentials.json 作为主路径 | Maka | 唯一路径是 `.env` / 进程环境 → CredentialLoader（§11.3） |
| ModelAdapter 跨厂商归一化层、第三方兼容端点、可配置 `base_url` | Maka / 通用反模式 | 退化为一个 DeepSeek 错误码映射器，并扩大凭据与协议攻击面 |
| 向量库 / 隐式长期记忆 / 内建 todo database | 通用反模式 | 不可观察的状态。用 artifact（`PLAN.md` / `TODO.md`，模型自己用 write 维护，harness 不认识它们） |
| MCP `list_changed` 动态工具集 | 通用反模式 | schema 字节抖动 = 缓存归零（§13） |
| 为所有命令弹窗的 permission framework | 通用反模式 | 大型 approval 状态机不等于安全；只保留有真实误操作价值的低成本规则并诚实标注（§11） |
| FIM completion | DeepSeek beta | 非思考模式、无工具，与 agent harness 不是同一个产品 |
| Zod / 任何 JSON Schema 生成器 | TS 生态 | tool schema 在冻结区，生成器版本升级 = 全员缓存归零（§5.4 坑 4） |
| 任何 SSE / eventsource 库 | TS 生态 | 会吞掉空行与 `:` 注释，直接违反不变量 6（§5.4 坑 2、3） |
| Ink / 任何 TUI 框架 | TS 生态 | v1 的 TUI 只需三件事，不值得引入 reconciler |
| tree-kill / execa | TS 生态 | PGID TERM→KILL、stdio 背压与 cleanup observation 是不变量 5 的核心，必须自己拿在手里（§5.4 坑 5） |
| monorepo / packages 拆分 | Pi 的做法 | Pi 拆包是因为它要同时发 SDK、TUI、agent 三个产物。我们只有一个 CLI，第二个真实消费者出现前不拆 |

---

## 16. 验证计划

不是单测清单，是**可失败的真实任务**。每一条都对应一个不变量。

### 用例 0 — 官方后端、冻结模型元组与诚实凭据边界

```text
0A（M0：发送边界，不需要工具）：
构造一次 golden request：
  断言目标 host/path 精确等于 https://api.deepseek.com/chat/completions
  断言 model == deepseek-v4-flash
  断言 thinking == {type: "enabled"}
  断言 reasoning_effort == "max"
  断言调用方无法传入 provider、base_url、model、thinking 或 effort
  断言生产依赖不含 ai、@ai-sdk/*、OpenAI/Anthropic SDK
  通过生产类型/API 结构检查，断言 src/** 不实现 Provider registry/factory/router、forkCrossModel 或其他 endpoint；负向测试 fixture 中的拒绝字面量不计
  断言本地 .env 被 Git 忽略且 mode == 0600
  断言 fixture key 只进入官方请求的 Authorization header，且 header capture 已 redact
  断言 fixture key 不出现在 Request Snapshot body、Journal、Artifact、Context、诊断或日志

0B（M1：bash 直接执行边界）：
  断言 read(.env) 被规范路径 deny
  断言 bash child env 不含 DEEPSEEK_API_KEY 或其他已加载 credential
  使用非秘密 marker fixture，断言 bash 以当前用户能够读取 .env/其他同用户文件；这是预期边界，不是假 FAIL
  断言 marker 按普通输出进入 Artifact/result，README/doctor 没有声称 OS deny、parent-process isolation 或 sandbox
  在令 Lima/nerdctl/containerd/runc/rootlesskit 均不可解析的 PATH/环境中，macOS/Linux 同一 native runner 仍完成真实 bash roundtrip
  断言只有 Windows 平台分支返回 frozen legacy unavailable；非 Windows 不做 backend/capability admission
  断言真实 fixture key 不因 loader、header capture、child-env 构造或诊断而自动进入 stdout/stderr、Artifact、Journal 或 Context
```

任一项失败都属于产品边界或凭据处理边界破坏，不能用 sandbox 声明掩盖。fixture 只能使用专门生成的非秘密 marker；测试不得读取或输出真实 `.env`/API key。

### 用例 1 — 缓存回归（最重要）

固定 `deepseek-v4-flash + thinking enabled + reasoning_effort max` 脚本会话，10 轮，含文件读写与 bash：

```
断言 unplanned_cache_break_count == 0
断言 每轮 Snapshot 的既有前缀字节/hash 与上一轮完全相同且只追加
断言 PromptTokens == HitTokens + MissTokens（每一轮）
报告第 2 轮起 cache_hit_ratio 的逐轮分布；best-effort miss 不单独判代码失败
```

**这条测试是整个项目的守门人。** 它挂了，后面所有优化都无意义。

### 用例 2 — 思考 + 工具链的 reasoning 往返（不变量 2）

```
连续 5 次 tool call，之后追加一条新 user 轮
断言 无 HTTP 400
断言 每个 assistant blob 的 reasoning_content 字节与流式累积结果完全一致
断言 每个 assistant/tool-call/results 原子组完整且声明顺序唯一，不存在孤儿或重复 tool blob
```

### 用例 3 — 崩溃恢复的字节级一致性（不变量 4、5）

```
在流式响应中途 kill -9
重启恢复
断言 重建的请求字节与崩溃前逐字节相同
断言 durable pending tool_call 在结果齐备前不能产生下一 Snapshot/Commit Boundary；新 Run 按 §8.2 唯一路径补齐
在 response staging 完成但 atomic assistant event 前 kill，断言没有 assistant/usage 事实且 attempt 只补 request_interrupted
在 atomic assistant event 后、Cache Checkpoint 前 kill，断言只补一个由 Snapshot/usage/provider request id 推导的 checkpoint
分别在 user commit、完整 tool-result batch、final assistant 后且 Commit Boundary 前 kill，断言各只补一个匹配 boundary
在 final Commit Boundary 后、run_completed 前 kill，断言只补 run_completed，且不误建 recovery Run
在 user/tool-batch Commit Boundary 后、Snapshot 前 kill，断言新 Run 对该 durable tail 第一次投影；没有旧 body 时不伪造 recovery alias
在 torn EOF repair temp rename 前/后 kill，断言重启结果只有旧 torn log 或 valid prefix + 唯一 journal_tail_recovered，不存在 clean-but-unreported tail
断言 前缀完整性自检通过
```

### 用例 4 — keep-alive fixture（不变量 6）

**离线 fixture，不打真实 API，也不真实等待 60 秒。** 用注入的单调时钟构造等价于 60 秒的空行与 `: keep-alive` 序列，再吐 delta。

```
断言 解析器不误判为错误
断言 keep-alive 期间不触发 idle_timeout
断言 queue_wait 被正确累计
断言 首个 delta 之后 idle_timeout 才开始生效
断言 \r\n 与 \n 两种行尾都被正确切分
断言 在一个中文字符的 UTF-8 字节中间切开 chunk 时，不产生 U+FFFD   ← 坑 3
断言 connect timer 会 destroy 未建连 request；ttfb<600 的配置被拒绝  ← 坑 2
```

最后两条是 TS 特有的，Go 版本不需要。

### 用例 5 — 压缩收益核算（§2.1）

```
仅在 Stage 09 已获真实证据准入后：用真实 Session 显式请求一次压缩
记录实际的成本回收轮数
断言 落在 K ≥ ρ(r−1)/(1−ρ) 的预测区间内
```

不在区间内不是测试失败——是**成本模型错了**，比测试失败更重要。

### 用例 6 — 错误码分类（不变量 7）

本地 fixture 模拟 400 / 401 / 402 / 429 / 500 / 503：

```
断言 400/422 不重试，且触发了前缀完整性自检
断言 401/402 立即停止，不烧 token
断言 429/500/503 走有界退避
断言 每次重试的 payload 字节与首次完全相同
```

---

### 用例 7 — 原生 PGID 生命周期、逃逸观察与背压（不变量 5，TS 特有）

Go 版本不需要这个用例；在 Node 上它是最容易留下不一致状态的地方。

```
场景 A（孙进程）
  bash("bash -c 'sleep 300 & sleep 300'") → 触发 timeout
  断言对原 PGID 依序 TERM→KILL，direct child terminal 严格有 exitCode/signal 其一
  断言 negative-PGID 与双 EOF 都观察到时 descendantsReaped=true

场景 A2（setsid 逃逸的诚实观察）
  fixture 用 setsid 等价方式启动 `sh -c 'sleep 3; exit 0'`，并继承输出 pipe；逃逸进程自带固定短时自杀
  cleanup 观察窗短于 3 秒，断言 descendantsReaped=false 进入 output Artifact metadata 与 effect_completed terminal
  断言 Effect 仍 completed、没有 effect_indeterminate、replay 保持相同 observation
  测试不得依赖 teardown/人工 kill；fixture 自然退出，测试可被动 bounded wait，但不把事后清理当正确性证明

场景 B（背压）
  bash("yes") → 无限输出
  断言 combined bytes 首次达到 raw_output_hard_limit_bytes 时触发 PGID TERM→KILL 与 cleanup observation
  断言 harness 常驻内存不随输出量增长
  断言 Artifact 精确记录已消费 byte prefix、stream counts 与 hard_limit_reached，模型只收有界投影+句柄
  断言 output_limit direct terminal 的 exitCode/signal 严格 exactly-one；neither/both 在 normalize/append/replay 均拒绝

场景 C（abort）
  流式响应中途 Ctrl-C
  断言 当前活动的 SSE request 与唯一 tool runner 收到同一个 AbortSignal；原 PGID 执行 TERM→KILL，direct terminal 与 cleanup observation durable
  断言 Harness 不启动第二个隐藏 runner；不把这条断言扩大为“setsid 逃逸者必然终止”
  断言 incomplete assistant staging 不提交；若已有 durable pending call，则新 Run 补齐或因 indeterminate 停止
  断言 §7.3 的前缀完整性自检允许规范 pending tail、拒绝 orphan/duplicate result

场景 D（跨平台）
  macOS 与 Linux 使用同一 `/bin/bash --noprofile --norc -lc` native path 跑 A、A2、B、C
  sanitized PATH/环境使 Lima/nerdctl/containerd/runc/rootlesskit 均不可解析，真实 bash roundtrip 仍成功
  Windows 是唯一 unavailable platform branch；不实现或宣称 taskkill 隔离路径
```

### 用例 8 — 冻结区 golden hash（不变量 1，TS 特有）

```
断言 system prompt + tools schema 的字节哈希等于签入的 golden 值
断言 Cache ABI manifest 使用固定域序和 u64be byte-length framing；相同 concat、不同字段切分的碰撞向量产生不同 manifest/hash
```

任何改动它的 PR 必须显式更新 golden 值——**让「开一条新血统」成为需要签字的动作，而不是 npm update 的副作用**（§5.4 坑 4）。

### 用例 9 — 冻结字节的往返（不变量 4，TS 特有）

```
构造含以下内容的 assistant 响应 fixture：
  emoji、CJK、组合字符、\u 转义、深层嵌套 tool_calls 参数
由 SSE semantic accumulator 产生一次 golden canonical assistant FrozenBytes
断言 committed FrozenBytes → base64 存储 → 读回 → 下一请求 messages 段的字节完全一致
断言 reasoning/content/tool-call semantic UTF-8 值与首次累计值一致；不与不存在的完整 SSE wire message JSON 比较转义空白
断言 代码库中不存在获准 view/invariant 文件之外对 FrozenBytes 的 JSON.parse（检查规则）
```

### 用例 10 — Gate 1 真实任务冻结协议

前述协议/恢复/Artifact 用例是 contract smoke，不冒充 task quality。`real-task-v1` 的具体 bytes 现在不能冻结，因为仓库尚无实现与观察到的真实 defect；Stage 07 必须在**第一次模型运行之前**从 Stages 02–06 的实际工作记录中选定 4 个可重放任务并一次性签入。每项必须同时具备：

- 结果出现前已经存在的原始 need/bug/Plan 文字与时间/commit 证据，不得由 suite 作者为模型生成；
- 可独立 checkout 的 pre-fix tree/hash、无 secret fixture、声明的允许副作用与确定性 verifier；
- 实际修复已证明 verifier 能 fail→pass，且 task prompt 不泄露答案/diff；
- 4 项覆盖至少 3 种真实机制（只读诊断、单点修复、多文件契约变更、工具/Artifact 证据中的适用者），不是四个同构函数题；
- fresh independent reviewer 在任何 live run 前确认来源真实、难度未按模型结果调节、verifier 不奖励越界修改。

Lead 随 manifest 一起冻结 task/prompt/fixture/verifier 全部 bytes/hash、每项静态预期工作链、semantic-request/wall/cost safety cap 与 Gate threshold；cap 必须由 fixture 工作链、Stage 06 已测开销和当日 Flash 价格推导，不能沿用无证据常数。每项使用 fresh Session、固定 Flash/thinking/max、一次 task attempt、零人工干预；physical pre-semantic retries 单列。

Gate 1 固定要求 Tier-0 invariants 全过且 `pass@1 = 4/4`。只有 4/4 才报告 uncached input tokens/task；只有质量与 token 可比才报告 wall-clock。首次 run 后不得修改 v1；任何 task/verifier/cap/threshold 变化创建 `real-task-v2` 和新 baseline，历史 evidence 保留。

## 17. 路线图

每个里程碑都明确列出**本轮刻意没有构建的东西**。

### M0 — 能正确读一条流（当前唯一在做的事）

```
做：唯一 DeepSeekOfficialBackend + 固定官方 endpoint/Flash/enabled/max request builder
    CredentialLoader、Authorization 瞬时注入与 capture redaction
    src/ds 的 node:https transport + SSE 读取器（字节级切行、keep-alive、显式计时）
    src/bytes 的 FrozenBytes/serializer；src/blob 的 base64 存储 + 前缀账本
    FrozenBytes 的 branded type 与禁止 JSON.parse 的 lint 规则
验收：用例 0A（官方后端、固定元组、.env bootstrap、auth redaction）
      用例 2（无 400、reasoning 字节一致）
      用例 4（keep-alive fixture，含 chunk 边界与超时校验）
      用例 9（冻结字节往返 + lint 规则生效）
不做：工具权限、通用沙箱、压缩、fork、TUI、MCP、成本 meter、子进程
```

**M0 的验收里，用例 4 与用例 9 是 TS 特有的**——它们对应 §5.4 的坑 1、2、3。固定后端与 secret redaction 则是跨语言产品边界，不得因传输测试通过而省略。

**如果 M0 的任一验收过不了，后面全部无意义**——固定官方请求、自动凭据路径 non-flow 与 50 倍缓存价差的前提，是你能先正确地构造、发送并读完一条字节稳定的流。

### M1 — 最小闭环 + 命中率可见

```
做：src/proc（进程组、TERM→KILL、cleanup observation、stdio 背压）  ← 先做这个
    native bash（macOS/Linux direct `/bin/bash`、closed child env、PGID TERM→KILL、cleanup observation）
    四原语 + ToolRuntime 收口 + 输出预算 + Phase 0A 原子文件 guard
    lineage / CacheCheckpoint / CommitBoundary / 恢复
    冻结区 golden hash 断言
    成本账本 + TUI 三数字（手写 ANSI，无框架）
验收：用例 0B（bash 凭据/分发边界）、用例 1（缓存回归）、用例 3（崩溃恢复）、用例 7（PGID/逃逸观察）、用例 8（golden hash）
不做：压缩、fork、通用权限规则（除固定 mechanical deny 外先全 allow 并明确告知）、MCP、bash 执行隔离
```

`src/proc` 排在四原语之前，因为 `bash` 工具依赖它，而它是 TS 版本最容易留下不一致状态的地方（§5.4 坑 5）。先把 PGID 生命周期、背压和 observation 测通，再让模型碰 shell；不能把该测试升级成 containment 声明。

### M2 — 权限、文件误操作防护、供应链

```
做：Policy 纯函数 + 交互式 Approver + Phase 0B workspace/allow_write containment
    （复用 Stage 05 Phase 0A 的 canonical-parent、atomic replacement 与 Effect 顺序）
    审计并强化 Stage 01 已建立的精确锁定 + npm-shrinkwrap + --ignore-scripts
                    + lifecycle allowlist + 依赖数棘轮
验收：用例 6；确定性 symlink/.. 误操作 guard；不宣称 TOCTOU 或 sandbox；依赖数棘轮
不做：任何内建 bash sandbox、VM/container runner、backend admission/capability、Windows bash 支持
```

Stage 01 先建立供应链基线，M2/Stage 08 在权限与文件 guard 上线时复核并强化；不是重复创建第二套 lock/ratchet。一个方向降低模型误操作，一个方向防依赖扩大攻击面（§5.4 坑 6），两者都不是执行隔离。

### M3–M5 — 先闭合准入，不预写实现

- M3/Stage 09：审计真实 Session economics 与知情需求；证据不足即 Compaction `unavailable`，证据满足则先冻结新契约/review，具体里程碑才在该 revision 定义。
- M4/Stage 10：审计真实 same-prefix branch caller；证据不足即 Fork `unavailable`，证据满足仍禁止跨模型、隐藏 Agent、fleet 或并行 writer，并先冻结新契约/review。
- M5/Stage 11：每个扩展 slice 独立审计；证据不足即该 slice `unavailable`，证据满足先冻结实际 caller 所需的最小协议/review。一项不授权另一项，workflow 偏好不回流 Core。

当前 roadmap 不承诺任何函数、命令、event、transport、registry 或 capability-success test 名；这正是 evidence gate 的含义。

### 观察后再决定（不预先构建）

- **续写截断输出**：先只记 `finish_reason == "length"` 的计数。计数长期为 0（384K 输出上限下很可能如此）就永远不做。非零再实现，并单独为「拼接后的 blob 与原始两段的字节关系」写测试。
- **`search` 工具**：等 `bash grep` 持续吃预算的实测数据。
- **`strict` 工具调用**：本轮 skip。
- **低谷时段调度**：等 F12 的官方生效公告。

---

## 附录 A — 事实来源

全部为 2026-08-03 直接对官方来源核对；价格、model version 与能力会变，发布日必须刷新，历史 ledger 不静默重算。

| 事实 | 来源 |
|---|---|
| `deepseek-v4-flash`，resolved `DeepSeek-V4-Flash-0731`，1M context、384K output、2500 concurrency；USD hit `$0.0028` / miss `$0.14` / output `$0.28`；峰时 2× 尚待公告 | `https://api-docs.deepseek.com/quick_start/pricing/` |
| 缓存前缀单元、完全匹配、持久化时机、best-effort、构建耗时 | `https://api-docs.deepseek.com/guides/kv_cache` |
| thinking 默认 enabled；Flash 接受 low/high/max，但本产品固定 max；thinking tool turn 必须回传 `reasoning_content`；四个 sampling 字段无效 | `https://api-docs.deepseek.com/guides/thinking_mode/` |
| 唯一 Chat Completions path、top-level thinking/effort、最多 128 functions、streaming 完整 usage 需要 `stream_options.include_usage=true` | `https://api-docs.deepseek.com/api/create-chat-completion/` |
| Flash 2500 account concurrency、429、空行/SSE keep-alive、10 分钟未开始推理则服务端关连接 | `https://api-docs.deepseek.com/quick_start/rate_limit/` |
| 官方错误码集合 400/401/402/422/429/500/503；页面未承诺 `Retry-After` | `https://api-docs.deepseek.com/quick_start/error_codes/` |
| Node 22 仍为 LTS；Node HTTP request 支持 AbortSignal，`setTimeout()` 不会自行 abort | `https://nodejs.org/en/about/previous-releases`；`https://nodejs.org/download/release/v22.15.0/docs/api/http.html` |
| Node 22 `FileHandle.write()` 返回实际 `bytesWritten` 且并发写不安全；`sync()` 请求落盘；`link()` 提供 POSIX hard-link primitive；`O_NOFOLLOW` 拒绝 final symlink；`process.kill(pid,0)` 只探测进程存在性 | `https://nodejs.org/download/release/v22.15.0/docs/api/fs.html`；`https://nodejs.org/download/release/v22.15.0/docs/api/process.html` |
| `smol-toml@1.7.1` registry metadata、integrity、Node ≥18、零传递依赖/无 install lifecycle | `https://registry.npmjs.org/smol-toml/1.7.1`；Stage 01 以 shrinkwrap 再证明 |
| 设计哲学 | Pi：`https://mariozechner.at/posts/2025-11-30-pi-coding-agent/`；`earendil-works/pi` 的 `agent-harness.md` 与 `security.md` |
| 供应链加固方案（整体照抄） | `earendil-works/pi` 的 README（`npm run check`、shrinkwrap、`--ignore-scripts`、生命周期脚本 allowlist、定时 `npm audit`） |
| 借鉴与反例 | `esengine/DeepSeek-Reasonix` 的 `docs/SPEC.md`；`maka-agent/maka-agent` 的 `README.en.md` 与 issue #19 |
| 三个参考项目的语言 | Pi = TypeScript（npm `@earendil-works/pi-coding-agent`）；Maka = TypeScript（Electron + npm workspaces）；Reasonix = Go，0.x 为 TypeScript 并已退到 `v1` 分支仅维护（`discussions/2397`、`docs/MIGRATING.md`） |

## 附录 B — 非阻塞观察项

Stage 00 已没有会改变 v0.1 实现的 Provider/runtime blocker。以下未知项只能影响后续显式决策，不能由猜测补齐：

1. **SWA cache 的最小 token 粒度**未由当前官方页声明；v0.1 不为小尾块做粒度启发式，只报告 native hit/miss 分布。
2. **峰时 2× 的生效日期**仍待官方公告；`cost.peak.enabled=false`，发布日刷新，旧 evidence 保留原核对日。
3. **429 是否携带 `Retry-After`**未由错误码页承诺；实现只在 header 存在且可安全解析时尊重，否则使用有界 backoff，离线 fixture 覆盖两种情况。
4. **macOS/Linux/Windows 与 Node 22 安装矩阵**属于 Stage 12 的实机证据；macOS/Linux 必须证明无需任何 Lima/container/runtime 前置即可走同一 native bash path，Windows 是唯一 unavailable platform branch。

## 附录 C — 不变量追踪与证据准入闭环

| 契约 | 首次实现阶段 | 必须失败的主要证据 |
|---|---|---|
| 1 字节只追加 / Cache ABI | 02、03、04 | request/schema golden、length-delimited manifest、prefix hash、same ABI independent Sessions/Lineages、unplanned break |
| 2 reasoning 原子性 | 02、03、06 | thinking tool roundtrip、partial stream、atomic assistant |
| 3 工具结果完备有序 | 05、06 | mixed batch/order、duplicate/orphan result |
| 4 字节级恢复 | 02、03、04、07 | FrozenBytes roundtrip、Snapshot lookup、kill/replay hash |
| 5 中断一致性 | 03、05、06、07 | torn tail、PGID lifecycle、setsid false observation、abort、new Run recovery |
| 6 keep-alive/超时 | 02 | virtual-clock SSE/UTF-8/connect/ttfb/idle matrix |
| 7 错误分类/同 Snapshot retry | 02 | 400/401/402/422/429/500/503 与 semantic-delta split |
| 8 fail-closed effects | 03、05、07、08 | prepared/crash/completed、indeterminate/reconcile、deny-before-prepared |
| credential handling / honest execution boundary | 01–08、12 | `.env` startup hygiene、header redaction、closed child env、explicit bash-read marker、documentation/package scan |
| 真实任务质量 | 07、12 | frozen `real-task-v1` 4/4 pass@1，再报告 tokens/time |

Stage 09–11 是 evidence-gated capability，不允许永久留下含糊 `BLOCKED`。Gate 2 后，Lead 必须对每个 stage/slice 执行一次有界准入审计。若 readiness 满足，先补具体 Spec/review 再按 Plan 实现；若不满足，审计过程、证据路径、未满足项、更便宜落点和 reviewer verdict 留在 Plan/Git，只把本 candidate 的用户可见 `unavailable` 说明与可证伪 re-admission trigger 写入普通 README/release notes；不得创建 capability registry、通用 non-admission protocol 或第二事实账本。

Non-admission 不是实现：不得添加空 module、stub、registry、CLI/config/provider-visible schema 或 feature-specific test script。统一 `npm run test:release` 只核对 package inventory 中能力确实缺席且用户文档声明一致，不输出能力 PASS。证据/review/cuts/downstream 完整后删除 Plan/index；未来 trigger 出现时以新 Plan、Spec revision 与新 review 重新立项。

## 附录 D — 一句话总结

> 构建最小且可观察的闭环；用四个原语完成动作，用普通文件与 artifact 保存状态和偏好；**把字节前缀当成第一等对象**，只为通用不变量支付核心复杂性。
