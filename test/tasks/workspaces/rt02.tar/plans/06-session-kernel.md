# Stage 06 — Session Kernel

- **Status:** `ACTIVE`
- **Gate:** Gate 1 integration
- **Depends on:** Stage 04 Context/Lineage/Projector and Stage 05 Effect Gateway/Four Tools
- **Lead:** `/root`
- **Baseline:** `a9fc0b531e8f08e816d93cbcf82bf9380c1c7220` (accepted Stage 04/05 Plans and index cleaned)
- **Review:** required because this stage fixes the single loop, concurrency order, cancellation, and commit semantics
- **Exclusive write scope:** `src/session/**`, minimal `src/cli/**`, integration fixtures, `test:session` wiring

## Actual need

The verified protocol, durable facts, deterministic context, and Effect Gateway need one mechanical coordinator. It must preserve order and lifecycle without becoming a planner, router, second agent, or hidden workflow state machine.

## Contract and invariant impact

- Charter: Single Loop, logical architecture, main execution loop, and Session/Run/Commit Boundary objects.
- Engineering Spec: invariants 2, 3, and 5; dependency rules; tool batching; M1 minimal loop.
- Protects one active Lineage, one writer, atomic assistant commit, exact tool pairing, ordered effects, and cancellation propagation.
- Expected metric impact: first runnable task loop; no pass@1/cache/latency claim until Stage 07 measures it.

## Smallest working loop

```text
durable user fact
→ safe user Commit Boundary
→ stored Request Snapshot
→ fake model response with one read call
→ Effect Gateway result
→ safe tool-result-batch Commit Boundary
→ second Snapshot
→ complete visible answer
→ final-assistant Commit Boundary
```

## In scope

- Session Kernel with exactly one active Run, active Lineage, and Journal writer.
- User input is durable before projection or network request.
- Immutable Snapshot selection and the sole official DeepSeek call through Stage 02; the Kernel cannot select endpoint/model/preset and accepts only the fixed Flash/thinking/max ABI.
- Streamed reasoning/text shown only as uncommitted preview.
- Complete assistant response committed in one atomic `assistant_committed` event with reasoning/tool calls, raw finish reason, verified usage, provider request id, attempt id, and Snapshot id; it is also the physical-attempt success terminal.
- Tool-call validation and dispatch only through Stage 05 Effect Gateway.
- One and only one matching tool result per call, committed in declared order.
- Consecutive proven-read-only calls may use the bounded batch interface; mutating calls remain serial.
- Commit Boundary is created immediately after each safe new user commit, complete ordered tool-result batch, and final no-tool assistant when protocol and all effects are closed or reconciled.
- Abort propagation to provider stream and active effect; a post-semantic-delta `request_interrupted` is journaled and the Run ends without transparent replay.
- Minimal non-interactive CLI path sufficient for offline integration fixtures.
- First outbound protocol E2E only through the complete durable path: one no-tool turn and one thinking/read/tool-result roundtrip on fixed Flash/max under the recorded 2026-08-04 authorization and this Plan's two-turn scope; no cache/task-quality claim.

## Non-goals

- No planner, goal/todo mode, Provider/router/SDK, Pro/high/other model or model switching, reflection loop, sub-agent, retry policy outside the Gateway, hidden background job manager, full TUI, recovery UX, cost dashboard, compaction, fork, or extension hooks.
- No second in-memory transcript treated as authority.
- No automatic repair that invents a missing tool result or effect outcome.

## Readiness gate

- [x] Stage 04 Snapshot, boundary, ABI, and Lineage APIs passed fresh review at accepted evidence `441f888`.
- [x] Stage 02/04 evidence proves the only accepted request identity is official endpoint + Flash/thinking/max; `git diff --exit-code 441f888 -- src/bytes/request.ts src/bytes/schemas.ts src/bytes/system.ts` exited 0 at activation.
- [x] Stage 05 Effect API and crash-state model passed final fresh review at implementation `561cc9c` and accepted evidence `29aeabe`; verdict `KEEP/ACCEPT/PASSED`, cuts 0.
- [x] Shared event schema/version integration is one serial branch at `a9fc0b5`; activation hashes for `journal/{types,schema,bindings,closure}`, `lineage/prefix`, and `tool/{index,runtime}` are recorded below.
- [x] `/root` has exclusive ownership of Session, CLI, shared event/serializer integration, registry, and package/checker wiring.
- [x] Existing offline SSE and Effect Gateway fixtures can drive all paths without live credentials; Stage 06 E2E must use the real Projector/Snapshot path rather than their manual request shortcut.
- [x] User authorization and bounded live request scope/cost terms are recorded below; no live call occurs before every durable-before-send test passes.

## Live authorization — 2026-08-04

- **Authorized backend/request:** DeepSeek v4 Flash, `thinking={"type":"enabled"}`, `reasoning_effort=max`.
- **Cost terms:** no hard monetary cap; use the dated Flash unit prices recorded in `PLANS.md`. The Stage 06 scope is one no-tool turn and one thinking/read/tool-result roundtrip, plus only the protocol's already-bounded physical retries; record actual calls, native usage, and cost.
- **Forbidden:** Pro, `reasoning_effort=high`, any other model, provider, endpoint, SDK, or configurable routing path.
- **First-send prerequisite:** every durable-before-send test must pass before the first live request. The user fact and Request Snapshot must already be durable and Commit Boundary eligibility must be correct; a smoke request may not bypass persistence.

## Activation record — 2026-08-04

- **Activation revision:** `a9fc0b531e8f08e816d93cbcf82bf9380c1c7220`; clean worktree.
- **Frozen input hashes, in command order:** `c22ef8b2ba6757f8b9e6f511c6eb102a81acd900`, `782b8ce707eeb55170fb2f7351baf296d8e432db`, `9bd197d06ab998170060032e313075fa31a97613`, `130c49a17d0511e8e743aeb096976aaf7c0df687`, `ff06696897244a8ed4c54ccee213e0b74a19ca5f`, `72bc26844ada291d43583a4290ce6daaf6049b2f`, `eddbed8048c3acb18b139d89f0adf2cacc01f285` from `git hash-object src/journal/types.ts src/journal/schema.ts src/journal/bindings.ts src/journal/closure.ts src/lineage/prefix.ts src/tool/index.ts src/tool/runtime.ts`; exit 0.
- **First implementation slice:** exercise the full offline durable path with a fake legal SSE response before expanding the Run state matrix. The order is durable user fact/blob → user Commit Boundary → Project/store/load exact Snapshot → durable attempt → fake response containing one `read` → atomic assistant commit → ToolRuntime result → tool-batch Commit Boundary → second Project/store/load Snapshot → final assistant → final Commit Boundary/Run terminal → close/reopen replay.
- **Shared ownership:** Run admission/terminal bindings, event schema, Snapshot adapter, concrete DeepSeek transport boundary, serializer, registry, Commit Boundary creation, package scripts, and checker remain Lead-only. Workers are read-only until an interface and disjoint file scope are frozen.
- **Cancellation decision:** provider and native bash actively consume `AbortSignal`; an already-started file operation reaches its existing atomic settled/indeterminate durability point before the Kernel stops. v0.1 does not claim generic preemption of filesystem syscalls.

## Work packages

1. **Run state machine:** explicit states and allowed transitions, with no task-policy states.
2. **Input/request path:** durable user fact, projection, Snapshot lookup, sole `src/ds` invocation.
3. **Response path:** preview stream, atomic assistant/usage/attempt-success commit, canonical `request_interrupted` failure record.
4. **Tool path:** validate, batch read-only calls, serialize effects, order results, loop.
5. **Completion/cancel:** immediate user/tool-batch/final-assistant Commit Boundaries, final Run closure, and end-to-end AbortSignal.
6. **Minimal CLI:** start one task, render preview/final output, propagate exit reason.
7. **Integration fixtures:** scripted model/tool traces for success, error, cancel, and invalid closure.
8. **Durable live protocol:** after offline acceptance, run the two minimal official-endpoint E2E turns and retain redacted request/usage/cost evidence.

## Lead design freeze before implementation

The Kernel's in-memory state is a disposable projection of durable events, not
a second transcript. The only mechanical states are:

```text
created -> ready -> requesting -> committing_assistant
                             \-> interrupted
committing_assistant -> executing_tools -> ready
                     \-> completed
executing_tools -> interrupted
```

Each transition is justified by the matching Journal append(s). Reopen ignores
this enum and derives truth from the Journal.

1. **Current-prefix view:** `JournalWriter` exposes an immutable snapshot of the
   exact events whose append acknowledgement completed, initialized from replay
   and advanced only after fsync/preflight commit. It is a disposable read view
   over the single Journal, required because ToolRuntime appends internal events
   and Projector requires the complete genesis-to-boundary prefix. Kernel code
   must not maintain or guess a parallel event list.
2. **Run admission:** the shared binding projection tracks one active Run,
   latest Run per Lineage, and terminalized Runs. The first Run is exactly
   `cause=user, previousRunId=null`. A later Run is exactly
   `cause=recovery, previousRunId=<latest same-Lineage Run>` and that predecessor
   must have closed with `run_interrupted`; a completed Run is never recoverable.
   No Run may start while another is active. `run_completed|run_interrupted`
   must cite a source event from that same Run, terminalizes exactly once, and
   forbids every later Run-scoped event. Final completion additionally binds the
   latest no-tool assistant, its Cache Checkpoint, and its exact final Commit
   Boundary.
3. **Store ownership:** the Session creates exactly one long-lived BlobStore
   and SnapshotStore handle from `openJournal().paths.sessionDir`. The handles
   are stateless wrappers over the same no-clobber CAS namespaces verified by
   Journal reopen; `openJournal` itself is not expanded merely to return them.
4. **Boundaries:** a user boundary cites its one `user_committed`; a tool-batch
   boundary cites the complete declared-order result event ids and has a null
   checkpoint because the preceding assistant checkpoint describes the shorter
   pending-tool prefix; a final boundary cites its one no-tool
   `assistant_committed` and that assistant's Cache Checkpoint. Duplicate
   boundaries for the same Lineage/blob-count/chain-hash are rejected. Blob
   count/hash always come from the durable role event, never from staging.
   Once a safe user, complete tool-result batch, or final-assistant tail is
   durable, its deterministic Boundary is the next Run event even if Abort has
   arrived. A crash in that gap is repaired on reopen in the still-active old
   Run before any terminal or recovery Run. A tool batch may finish across
   successive recovery Runs after earlier partial-batch interruptions; its
   Boundary belongs to the Run that commits the final result and cites the
   complete declared-order result ids across the same Lineage.
5. **Snapshot adapter:** the Kernel passes the complete current prefix to
   `storeProjectedSnapshotV1`, reloads the resulting CAS body, and at one
   tested adapter strips only the validated `sha256:` tag before calling
   `restoreDeepSeekRequestSnapshot`. It never rebuilds or reserializes a retry.
   Recovery has one explicit state transition: a safe predecessor Boundary
   with no Snapshot may be freshly projected exactly once in the recovery Run
   with `recoveryFromSnapshotId=null`; once that event is durable, the state is
   “Snapshot exists” and every later recovery must use a byte-identical alias.
   The transition is tested as Boundary crash → fresh projection → second
   crash → alias with the same body hash. This records the 2026-08-04 user-
   approved correction of over-broad wording in Spec §3/§9.1; it clarifies the
   behavior already fixed by §8.2 and does not change product behavior.
6. **Transport:** production adds one concrete official `node:https.request`
   wrapper with fixed endpoint/timeouts and no Provider interface or request
   override. Existing request-function/timer seams remain explicitly fixture
   only. Request metadata and retry scheduling are best-effort telemetry;
   semantic durability barriers are awaited and never swallowed.
7. **Preview:** the SSE hook first awaits the fatal
   `request_semantic_started` durability barrier, then emits a frozen
   discriminated fragment before staging: reasoning/content carry their exact
   decoded fragment; tool-call deltas carry only their kind. Preview,
   request-metadata, and retry-notification sinks are best-effort read-only
   observers: the first thrown observer error disables that sink and cannot
   change request truth. The semantic durability barrier is never swallowed.
   CLI renders uncommitted preview to stderr and only the committed final
   content to stdout.
8. **Interruption ownership:** DeepSeek lifecycle owns request terminal facts;
   ToolRuntime/JournalToolDurability owns classified Effect and tool-path
   `run_interrupted` facts. On a partial tool batch, ToolRuntime may use
   `JournalToolDurability` to terminalize immediately. Once the complete batch
   is durable, ToolRuntime returns its exact committed results even if aborted;
   the Kernel appends the mandatory Boundary, then asks that same durability
   owner to append the sole interruption. On a ToolRuntime throw the Kernel
   inspects the committed Journal view and never appends a duplicate terminal;
   absence of a required durable terminal means durability is unavailable and
   fails closed.
9. **Abort semantics and winner rule:** a successfully resolved transport
   promise wins its race with a later Abort and commits its one complete
   `assistant_committed`; no partial response is committed. Before any next
   tool start, Snapshot, or send, the Kernel checks the signal. A mandatory
   deterministic Boundary is never skipped for cancellation. Every already-
   started tool first reaches its durable settled/indeterminate point; the
   successful batch commits all ordered results and its Boundary, then honors
   the signal before any next Snapshot/send.
   A no-tool assistant that is already durable finishes its exact checkpoint,
   final Boundary, and `run_completed` even if Abort arrives during that
   finalization. Provider lifecycle or `JournalToolDurability`, respectively,
   owns the sole interruption terminal; the Kernel consults the acknowledged
   view and never guesses or duplicates it. ToolRuntime observes the signal
   after each settled slice/result; a complete batch returns to the Kernel for
   mandatory Boundary finalization, while an incomplete batch terminalizes and
   cannot start another tool. Bash and provider transport continue to consume
   the signal actively.

10. **Run phase mirror:** bindings and `src/lineage/prefix.ts` independently
    mirror active/latest/terminal Run state plus normal, must-interrupt, and
    finalizing phases. A post-semantic interruption requires `run_interrupted`
    next; pre-semantic retry remains bound to the same stored Snapshot. A
    terminal requires no open physical attempt. Existing recovery fixtures must
    close their old Run with a same-Run `run_interrupted` before starting the
    recovery Run.
11. **Durability acknowledgement truth:** only events present in the writer's
    immutable acknowledged view may justify `SessionInterrupted`. A healthy
    writer closes Snapshot/CAS failure from the current safe Boundary, and an
    assistant-blob/preflight failure closes the acknowledged physical attempt
    with `request_interrupted(durability_error)` followed by
    `run_interrupted(durability_failure)`. A poisoned writer or ambiguous
    acknowledgement never receives another append and returns Kernel
    durability failure for Stage 07 replay. Once assistant, Checkpoint, or a
    mandatory Boundary is durable, only its deterministic next tail is legal;
    it cannot be replaced with an interruption. Complete-tool cancellation is
    reported as cancelled only after the exact Boundary-sourced
    `run_interrupted` is acknowledged.
12. **Targeted-test truth:** the shared test runner uses TAP inspection for
    `--test-name-pattern` and exits 2 when no real test name matches. Node's
    otherwise-successful per-file zero-test wrappers are not accepted as
    evidence.

No Journal event name/payload, provider-visible request byte, tool schema/order,
Cache ABI, or Effect outcome is changed by this design.

## Ownership and allowed parallelism

| Lane | Exclusive scope | May overlap |
|---|---|---|
| Lead | Run state machine, shared integration, Commit Boundary creation | none on shared flow |
| CLI worker | reserved minimal CLI files | after Kernel interface freeze |
| Fixture worker | fake Gateway/effect scenarios | Kernel implementation |
| Verification worker | read-only traces and cancellation checks | after patch freeze |

No Worker changes event schemas, serializer, tool registry, package scripts, or Effect semantics. Integration conflicts return to the Lead.

## Verification

| Evidence | Exact command | Expected result | Actual result |
|---|---|---|---|
| Full Session suite | `npm run test:session` | exit 0 | exit 0; 20/20 pass; no skipped/todo |
| One-loop trace | `npm run test:session -- --test-name-pattern="single loop"` | only Context→Model→Tool→Result→Model→Output | exit 0; one named loop test pass; zero-match guard active |
| Durable-before-send | `npm run test:session -- --test-name-pattern="durable user|snapshot before send"` | provider not invoked before both facts are durable | exit 0; one named test pass |
| Recovery Snapshot transition | `npm run test:context -- --test-name-pattern="fresh projection then a second crash aliases"` | first recovery projects once; second recovery aliases exact body hash | exit 0; binding and real Snapshot-store transitions pass; one publish total |
| Fixed backend | `npm run test:session -- --test-name-pattern="backend|model override"` | only stored Flash/thinking/max Snapshot can be sent; overrides fail closed | exit 0; one named test pass |
| Atomic assistant | `npm run test:session -- --test-name-pattern="atomic assistant|partial"` | preview never becomes committed half-blob | exit 0; three named failure-boundary tests pass |
| Tool closure/order | `npm run test:session -- --test-name-pattern="tool result|declared order"` | exactly one result per id, in order | exit 0; single-read and three-call real Runtime traces pass |
| Boundary timing | `npm run test:session -- --test-name-pattern="user boundary|tool batch boundary|final boundary"` | each of the three safe append points emits one boundary; pending calls/effects emit none | exit 0; four named success/cancel/fault tests pass |
| Effect ordering | `npm run test:effects -- --test-name-pattern="read batches cap|T2 mutations serialize"` | bounded reads; writes/effects serial | exit 0; two named real Runtime tests pass |
| Semantic interruption | `npm run test:session -- --test-name-pattern="semantic interruption"` | old Run ends, canonical `request_interrupted` exists, no same-Run transparent replay; §8.2 recovery alias remains legal | exit 0; one named test pass |
| Cancellation | `npm run test:session -- --test-name-pattern="AbortSignal|cancel"` | stream/effect stop and state remains closed or explicit | exit 0; three named pre-send/final-winner/terminal-ack tests pass |
| Durability fault matrix | `npm run test:session -- --test-name-pattern="Snapshot CAS durability|assistant blob CAS durability|ambiguous finalization|failed acknowledgement of cancellation"` | healthy failures close canonically; poison/ambiguity never invents terminals | exit 0; 8 named cases plus one parent pass |
| Live opt-in guard | `env -u DSH_LIVE npm run test:live:protocol` | exit nonzero before CredentialLoader or network | exit 1; 0 pass, 1 expected guard failure, 0 skipped |
| Live protocol E2E | `DSH_LIVE=1 npm run test:live:protocol` | exit 0; durable Snapshot-before-send; no-tool + thinking/read roundtrip; fixed Flash/max; no 400; redacted cost evidence | — |
| Static checks | `npm run check` | exit 0; dependency direction and single-writer rules pass | exit 0; `check-package: ok dependencies=4 lifecycle=0` |

## Independent review

Use a fresh read-only reviewer when the state diagram and integration diff are concrete. Review the absence of policy intelligence, Commit Boundary eligibility, effect ordering, post-delta interruption, and cancellation. Record verdict and cuts.

- **Reviewer context/date:** fresh independent `/root/stage06_fresh_design_review`,
  2026-08-04, read-only review of revision
  `115f97dcb7d49a6f0ed233089bcecf4a6dcece11` after reading the complete
  `dev/docs/pi-style-reviewer-system-prompt.md`.
- **Verdict:** Direction `KEEP`; Implementation `ACCEPT AFTER CUTS`;
  Verification `NOT RUN`.
- **Required cuts/evidence:** P0 freeze recovery predecessor/terminal source and
  terminal-once rules; P0 freeze Abort-versus-success linearization and terminal
  ownership; P1 separate fatal semantic durability from best-effort preview.
  All three cuts are incorporated in design-freeze items 2, 7, 9, and 10 above.
  Required verification is append/replay Run rejection coverage, the Abort
  fault matrix around SSE/tools/final result, and all offline gates before live.

## No-go conditions

- Kernel decides task strategy, routes models, or owns a second plan/todo state.
- Kernel accepts Pro/high/model/endpoint override or contains a Provider selection branch.
- A request is sent before its user fact/Snapshot is durable.
- Preview bytes enter canonical history before complete response finalization.
- Direct tool/process execution bypasses Effect Gateway.
- A Cache Checkpoint is emitted as a Commit Boundary while effects are open.
- A retry after semantic output is hidden inside the Kernel.

## Handoff evidence

Return baseline, changed paths, state diagram, representative event traces, exact commands/exits, cancellation/process observations, reviewer verdict, open risks, and the stable recovery/observability inputs for Stage 07.

## Completion and cleanup

- [ ] All Actual result and review fields are filled.
- [ ] Fake loop and authorized minimal live loop reach valid Commit Boundaries with no orphan state.
- [ ] Durable behavior/state changes are in the Engineering Spec.
- [ ] Stage 07 is unblocked by exact event traces and commands.
- [ ] Remove this Plan and its index row after handoff.
