import { spawnSync } from "node:child_process";
import { resolve } from "node:path";

import { createBlobStore, type BlobPosition, type BlobStore } from "../blob/index.js";
import { restoreDeepSeekRequestSnapshot, type DeepSeekRequestSnapshot } from "../bytes/request.js";
import { assertUnicodeScalarString, utf8Bytes } from "../bytes/ops.js";
import { viewAssistant } from "../bytes/view.js";
import type { FrozenBytes } from "../bytes/types.js";
import { materializeUserV1, storeProjectedSnapshotV1 } from "../ctx/index.js";
import type { DeepSeekCredential } from "../ds/credential.js";
import {
  DeepSeekHttpError,
  DeepSeekProtocolError,
  type DeepSeekRetryDecision,
  type DeepSeekSemanticState,
} from "../ds/errors.js";
import {
  DeepSeekDurabilityError,
  DeepSeekTransportError,
  runDeepSeekOfficialWithRetry,
  type DeepSeekRetryLifecycle,
} from "../ds/transport.js";
import type {
  CompletedDeepSeekResponse,
  DeepSeekSemanticFragment,
} from "../ds/types.js";
import {
  newArtifactId,
  newAttemptId,
  newCacheCheckpointId,
  newCommitBoundaryId,
  newLineageId,
  newRequestSnapshotId,
  newRunId,
  openJournal,
  randomEventIdentitySource,
  systemJournalClock,
  type AnyVerifiedJournalEvent,
  type BlobPayload,
  type BlobRef,
  type CacheCheckpointId,
  type CommitBoundaryId,
  type EventId,
  type EventIdentitySource,
  type JournalClock,
  type LineageId,
  type RunId,
  type SessionId,
  type VerifiedJournalEvent,
} from "../journal/index.js";
import type { PersistenceTestControls } from "../journal/faults.js";
import { buildCacheAbiV1, type FrozenCacheAbiManifest } from "../lineage/index.js";
import { createSnapshotStore, type SnapshotStore } from "../snapshot/index.js";
import { JournalToolDurability, ToolDurabilityError } from "../tool/durability.js";
import { ToolRuntime } from "../tool/runtime.js";

type RoleEvent = Extract<
  AnyVerifiedJournalEvent,
  {
    readonly type:
      | "user_committed"
      | "assistant_committed"
      | "tool_result_committed";
  }
>;

type KernelPhase =
  | "created"
  | "ready"
  | "requesting"
  | "committing_assistant"
  | "executing_tools"
  | "completed"
  | "interrupted";

type SendSnapshot = (
  snapshot: DeepSeekRequestSnapshot,
  lifecycle: DeepSeekRetryLifecycle,
  preview: ((fragment: DeepSeekSemanticFragment) => void | Promise<void>) | undefined,
  signal: AbortSignal,
) => Promise<CompletedDeepSeekResponse>;

export interface SessionEnvironmentFacts {
  readonly date?: string;
  readonly cwd?: string;
  readonly git?: string;
}

interface SessionBaseInput {
  readonly workspaceRoot: string;
  readonly sessionId: SessionId;
  readonly userInput: string;
  readonly environmentFacts?: SessionEnvironmentFacts;
  readonly signal?: AbortSignal;
  readonly onPreview?: (
    fragment: DeepSeekSemanticFragment,
  ) => void | Promise<void>;
  readonly clock?: JournalClock;
  readonly eventIds?: EventIdentitySource;
}

export interface OfficialSessionInput extends SessionBaseInput {
  readonly credential: DeepSeekCredential;
}

export type SessionFixtureTurn =
  | Readonly<{
      readonly kind: "success";
      readonly response: CompletedDeepSeekResponse;
      readonly fragments?: readonly DeepSeekSemanticFragment[];
    }>
  | Readonly<{
      readonly kind: "interrupted";
      readonly failure: Error;
      readonly semanticState: DeepSeekSemanticState;
      readonly decision: DeepSeekRetryDecision;
      readonly fragments?: readonly DeepSeekSemanticFragment[];
    }>;

export interface SessionFixtureInput extends SessionBaseInput {
  readonly turns: readonly SessionFixtureTurn[];
  readonly persistenceControls?: PersistenceTestControls;
  readonly onBeforeSend?: (observation: Readonly<{
    readonly snapshot: DeepSeekRequestSnapshot;
    readonly acknowledgedEvents: readonly AnyVerifiedJournalEvent[];
  }>) => void | Promise<void>;
}

export interface CompletedSessionResult {
  readonly status: "completed";
  readonly sessionId: SessionId;
  readonly lineageId: LineageId;
  readonly runId: RunId;
  readonly content: string;
  readonly commitBoundaryId: CommitBoundaryId;
  readonly requestCount: number;
}

export type SessionInterruptionReason =
  | "request_failed"
  | "semantic_interrupted"
  | "effect_indeterminate"
  | "integrity_violation"
  | "cancelled"
  | "durability_failure";

export class SessionInterruptedError extends Error {
  constructor(readonly reason: SessionInterruptionReason) {
    super(`Session interrupted: ${reason}`);
    this.name = "SessionInterruptedError";
  }
}

export class SessionKernelError extends Error {
  constructor(
    readonly code:
      | "invalid_state"
      | "fixture_exhausted"
      | "durability_failure",
  ) {
    super(`Session Kernel failed: ${code}`);
    this.name = "SessionKernelError";
  }
}

function asEvent<Type extends AnyVerifiedJournalEvent["type"]>(
  event: AnyVerifiedJournalEvent,
  type: Type,
): Extract<AnyVerifiedJournalEvent, { readonly type: Type }> {
  if (event.type !== type) throw new SessionKernelError("durability_failure");
  return event as Extract<AnyVerifiedJournalEvent, { readonly type: Type }>;
}

function isRoleEvent(event: AnyVerifiedJournalEvent): event is RoleEvent {
  return (
    event.type === "user_committed" ||
    event.type === "assistant_committed" ||
    event.type === "tool_result_committed"
  );
}

function transition(current: KernelPhase, next: KernelPhase): KernelPhase {
  const legal: Readonly<Record<KernelPhase, readonly KernelPhase[]>> = {
    created: ["ready", "interrupted"],
    ready: ["requesting", "interrupted"],
    requesting: ["committing_assistant", "interrupted"],
    committing_assistant: ["executing_tools", "completed", "interrupted"],
    executing_tools: ["ready", "interrupted"],
    completed: [],
    interrupted: [],
  };
  if (!legal[current].includes(next)) {
    throw new SessionKernelError("invalid_state");
  }
  return next;
}

function bestEffortPreviewObserver(
  observer: SessionBaseInput["onPreview"],
): ((fragment: DeepSeekSemanticFragment) => void) | undefined {
  if (observer === undefined) return undefined;
  let enabled = true;
  let pending = false;
  return (fragment): void => {
    if (!enabled || pending) return;
    try {
      const completion = observer(fragment);
      if (completion === undefined) return;
      pending = true;
      void Promise.resolve(completion).then(
        () => {
          pending = false;
        },
        () => {
          pending = false;
          enabled = false;
        },
      );
    } catch {
      enabled = false;
    }
  };
}

function rolePosition(
  events: readonly AnyVerifiedJournalEvent[],
  lineageId: LineageId,
): BlobPosition {
  let position: BlobPosition = Object.freeze({
    blobIndex: 0,
    previousChainHash: null,
  });
  for (const event of events) {
    if (!isRoleEvent(event) || event.lineageId !== lineageId) continue;
    if (
      event.payload.blobIndex !== position.blobIndex ||
      event.payload.chainHash === null
    ) {
      throw new SessionKernelError("invalid_state");
    }
    position = Object.freeze({
      blobIndex: event.payload.blobIndex + 1,
      previousChainHash: event.payload.chainHash,
    });
  }
  return position;
}

async function externalBlobMap(
  events: readonly AnyVerifiedJournalEvent[],
  lineageId: LineageId,
  blobs: BlobStore,
): Promise<ReadonlyMap<BlobRef, FrozenBytes>> {
  const external = new Map<BlobRef, FrozenBytes>();
  let position: BlobPosition = Object.freeze({
    blobIndex: 0,
    previousChainHash: null,
  });
  for (const event of events) {
    if (!isRoleEvent(event) || event.lineageId !== lineageId) continue;
    const bytes = await blobs.load(
      event.payload as BlobPayload<RoleEvent["payload"]["role"]>,
      position,
    );
    if (event.payload.enc === "ref") {
      external.set(event.payload.blobRef, bytes);
    }
    position = Object.freeze({
      blobIndex: event.payload.blobIndex + 1,
      previousChainHash: event.payload.chainHash,
    });
  }
  return external;
}

function eventsThrough(
  events: readonly AnyVerifiedJournalEvent[],
  eventId: string,
): readonly AnyVerifiedJournalEvent[] {
  const index = events.findIndex((event) => event.id === eventId);
  if (index < 0) throw new SessionKernelError("invalid_state");
  return Object.freeze(events.slice(0, index + 1));
}

function descriptorForSnapshot(
  event: VerifiedJournalEvent<"request_snapshot_stored">,
): Readonly<{
  readonly bodyRef: VerifiedJournalEvent<"request_snapshot_stored">["payload"]["bodyRef"];
  readonly bodyHash: VerifiedJournalEvent<"request_snapshot_stored">["payload"]["bodyHash"];
  readonly byteCount: number;
}> {
  return Object.freeze({
    bodyRef: event.payload.bodyRef,
    bodyHash: event.payload.bodyHash,
    byteCount: event.payload.byteCount,
  });
}

async function restoredSnapshot(
  store: SnapshotStore,
  event: VerifiedJournalEvent<"request_snapshot_stored">,
): Promise<DeepSeekRequestSnapshot> {
  const body = await store.load(descriptorForSnapshot(event));
  const tagged = event.payload.bodyHash;
  if (!tagged.startsWith("sha256:") || tagged.length !== 71) {
    throw new SessionKernelError("invalid_state");
  }
  return restoreDeepSeekRequestSnapshot(body, {
    bodySha256: tagged.slice("sha256:".length),
    byteCount: event.payload.byteCount,
  });
}

function sameToolCalls(
  left: CompletedDeepSeekResponse["toolCalls"],
  right: CompletedDeepSeekResponse["toolCalls"],
): boolean {
  return (
    left.length === right.length &&
    left.every(
      (call, index) =>
        call.id === right[index]?.id &&
        call.type === right[index]?.type &&
        call.function.name === right[index]?.function.name &&
        call.function.arguments === right[index]?.function.arguments,
    )
  );
}

function validateResponse(response: CompletedDeepSeekResponse): void {
  const view = viewAssistant(response.assistantBytes);
  if (
    view.content !== response.content ||
    view.reasoningContent !== response.reasoningContent ||
    !sameToolCalls(view.toolCalls, response.toolCalls)
  ) {
    throw new SessionKernelError("invalid_state");
  }
}

function failureOutcome(failure: Error):
  | "http_error"
  | "transport_error"
  | "timeout"
  | "cancelled"
  | "protocol_error"
  | "durability_error" {
  if (failure instanceof DeepSeekHttpError) return "http_error";
  if (failure instanceof DeepSeekProtocolError) return "protocol_error";
  if (failure instanceof DeepSeekDurabilityError) return "durability_error";
  if (failure instanceof DeepSeekTransportError) {
    if (failure.kind === "timeout") return "timeout";
    if (failure.kind === "cancelled") return "cancelled";
    return "transport_error";
  }
  return "transport_error";
}

function interruptionReason(
  failure: Error,
  semanticState: DeepSeekSemanticState,
): SessionInterruptionReason {
  if (failure instanceof DeepSeekDurabilityError) return "durability_failure";
  if (failure instanceof DeepSeekTransportError && failure.kind === "cancelled") {
    return "cancelled";
  }
  if (semanticState !== "pre_semantic") return "semantic_interrupted";
  return "request_failed";
}

function semanticWire(
  value: DeepSeekSemanticState,
): "pre_semantic" | "post_semantic" | "semantic_state_unknown" {
  return value === "unknown" ? "semantic_state_unknown" : value;
}

async function closeDurabilityFailure(input: Readonly<{
  writer: Awaited<ReturnType<typeof openJournal>>["writer"];
  sessionId: SessionId;
  lineageId: LineageId;
  runId: RunId;
  sourceEventId: EventId;
  attempt?: VerifiedJournalEvent<"request_attempt_started">;
  requestSnapshotId?: VerifiedJournalEvent<"request_snapshot_stored">["payload"]["requestSnapshotId"];
  semanticState?: DeepSeekSemanticState;
}>): Promise<boolean> {
  if (input.writer.state !== "open") return false;
  try {
    let sourceEventId = input.sourceEventId;
    if (
      input.attempt !== undefined &&
      input.requestSnapshotId !== undefined &&
      input.semanticState !== undefined
    ) {
      const interrupted = asEvent(
        await input.writer.append({
          type: "request_interrupted",
          sessionId: input.sessionId,
          lineageId: input.lineageId,
          runId: input.runId,
          payload: {
            attemptId: input.attempt.payload.attemptId,
            requestSnapshotId: input.requestSnapshotId,
            outcome: "durability_error",
            status: null,
            retryClass: "unknown",
            semanticState: semanticWire(input.semanticState),
          },
        }),
        "request_interrupted",
      );
      sourceEventId = interrupted.id;
    }
    await input.writer.append({
      type: "run_interrupted",
      sessionId: input.sessionId,
      lineageId: input.lineageId,
      runId: input.runId,
      payload: { reason: "durability_failure", sourceEventId },
    });
    return true;
  } catch {
    return false;
  }
}

async function appendBoundary(
  writer: Awaited<ReturnType<typeof openJournal>>["writer"],
  sessionId: SessionId,
  lineageId: LineageId,
  runId: RunId,
  sourceEventIds: readonly EventId[],
  cacheCheckpointId: CacheCheckpointId | null,
): Promise<VerifiedJournalEvent<"commit_boundary_created">> {
  const source = writer.events.findLast(
    (event) => event.id === sourceEventIds.at(-1),
  );
  if (source === undefined || !isRoleEvent(source)) {
    throw new SessionKernelError("invalid_state");
  }
  return asEvent(
    await writer.append({
      type: "commit_boundary_created",
      sessionId,
      lineageId,
      runId,
      ...(sourceEventIds.length === 1 ? { parentId: source.id } : {}),
      payload: {
        commitBoundaryId: newCommitBoundaryId(),
        cacheCheckpointId,
        blobCount: source.payload.blobIndex + 1,
        chainHash: source.payload.chainHash,
        protocolClosed: true,
        effectsSettled: true,
        sourceEventIds,
      },
    }),
    "commit_boundary_created",
  );
}

async function appendCheckpoint(
  writer: Awaited<ReturnType<typeof openJournal>>["writer"],
  sessionId: SessionId,
  lineageId: LineageId,
  runId: RunId,
  assistant: VerifiedJournalEvent<"assistant_committed">,
): Promise<VerifiedJournalEvent<"cache_checkpoint_created">> {
  return asEvent(
    await writer.append({
      type: "cache_checkpoint_created",
      sessionId,
      lineageId,
      runId,
      parentId: assistant.id,
      payload: {
        cacheCheckpointId: newCacheCheckpointId(),
        requestSnapshotId: assistant.payload.requestSnapshotId,
        blobCount: assistant.payload.blobIndex + 1,
        chainHash: assistant.payload.chainHash,
        promptTokens: assistant.payload.usage.promptTokens,
        providerRequestId: assistant.payload.providerRequestId,
        sourceAssistantEventId: assistant.id,
      },
    }),
    "cache_checkpoint_created",
  );
}

async function publishFact(
  opened: Awaited<ReturnType<typeof openJournal>>,
  sessionId: SessionId,
  lineageId: LineageId,
  runId: RunId,
  kind: "user_input" | "date" | "cwd" | "git",
  value: string,
): Promise<Readonly<{
  readonly published: VerifiedJournalEvent<"artifact_published">;
  readonly fact: VerifiedJournalEvent<"fact_recorded">;
  readonly bytes: FrozenBytes;
}>> {
  assertUnicodeScalarString(value, `${kind} fact`);
  const bytes = utf8Bytes(value);
  const descriptor = await opened.artifacts.publishArtifact(bytes, {
    lineCount: null,
    mediaType: "text/plain; charset=utf-8",
    artifactType: "fact",
    streamBytes: null,
    hardLimitReached: null,
    descendantsReaped: null,
    toolCallId: null,
    terminal: null,
  });
  const artifactId = newArtifactId();
  const published = asEvent(
    await opened.writer.append({
      type: "artifact_published",
      sessionId,
      lineageId,
      runId,
      payload: { artifactId, ...descriptor },
    }),
    "artifact_published",
  );
  const fact = asEvent(
    await opened.writer.append({
      type: "fact_recorded",
      sessionId,
      lineageId,
      runId,
      parentId: published.id,
      payload: { kind, artifactId, byteCount: bytes.byteLength },
    }),
    "fact_recorded",
  );
  return Object.freeze({ published, fact, bytes });
}

async function initialize(
  opened: Awaited<ReturnType<typeof openJournal>>,
  input: SessionBaseInput,
  blobs: BlobStore,
): Promise<Readonly<{
  readonly cacheAbi: FrozenCacheAbiManifest;
  readonly lineageId: LineageId;
  readonly runId: RunId;
  readonly boundary: VerifiedJournalEvent<"commit_boundary_created">;
}>> {
  if (opened.writer.events.length !== 0 || input.userInput.length === 0) {
    throw new SessionKernelError("invalid_state");
  }
  const session = asEvent(
    await opened.writer.append({
      type: "session_started",
      sessionId: input.sessionId,
      payload: {},
    }),
    "session_started",
  );
  const cacheAbi = buildCacheAbiV1();
  const manifest = await opened.artifacts.publishArtifact(cacheAbi.manifestBytes, {
    lineCount: null,
    mediaType: "application/octet-stream",
    artifactType: "cache_abi_manifest",
    streamBytes: null,
    hardLimitReached: null,
    descendantsReaped: null,
    toolCallId: null,
    terminal: null,
  });
  const manifestArtifactId = newArtifactId();
  const manifestEvent = asEvent(
    await opened.writer.append({
      type: "artifact_published",
      sessionId: input.sessionId,
      parentId: session.id,
      payload: { artifactId: manifestArtifactId, ...manifest },
    }),
    "artifact_published",
  );
  await opened.writer.append({
    type: "cache_abi_declared",
    sessionId: input.sessionId,
    parentId: manifestEvent.id,
    payload: {
      cacheAbiId: cacheAbi.cacheAbiId,
      manifestArtifactId,
      manifestByteCount: cacheAbi.manifestBytes.byteLength,
    },
  });
  const lineageId = newLineageId();
  await opened.writer.append({
    type: "lineage_started",
    sessionId: input.sessionId,
    lineageId,
    payload: { cacheAbiId: cacheAbi.cacheAbiId },
  });
  await opened.writer.append({
    type: "lineage_activated",
    sessionId: input.sessionId,
    lineageId,
    payload: {
      previousLineageId: null,
      nextLineageId: lineageId,
      reason: "initial",
    },
  });
  const runId = newRunId();
  await opened.writer.append({
    type: "run_started",
    sessionId: input.sessionId,
    lineageId,
    runId,
    payload: { cause: "user", previousRunId: null },
  });

  const factInputs = [
    await publishFact(
      opened,
      input.sessionId,
      lineageId,
      runId,
      "user_input",
      input.userInput,
    ),
  ];
  for (const kind of ["date", "cwd", "git"] as const) {
    const value = input.environmentFacts?.[kind];
    if (value !== undefined) {
      factInputs.push(
        await publishFact(
          opened,
          input.sessionId,
          lineageId,
          runId,
          kind,
          value,
        ),
      );
    }
  }
  const user = materializeUserV1({ facts: factInputs });
  const payload = await blobs.publish("user", user.blob, {
    blobIndex: 0,
    previousChainHash: null,
  });
  const userEvent = asEvent(
    await opened.writer.append({
      type: "user_committed",
      sessionId: input.sessionId,
      lineageId,
      runId,
      parentId: user.sourceFactEventIds.at(-1)!,
      payload: { ...payload, sourceFactEventIds: user.sourceFactEventIds },
    }),
    "user_committed",
  );
  const boundary = await appendBoundary(
    opened.writer,
    input.sessionId,
    lineageId,
    runId,
    [userEvent.id],
    null,
  );
  return Object.freeze({ cacheAbi, lineageId, runId, boundary });
}

async function runKernel(
  input: SessionBaseInput,
  send: SendSnapshot,
  beforeSend?: SessionFixtureInput["onBeforeSend"],
  persistenceControls?: PersistenceTestControls,
): Promise<CompletedSessionResult> {
  assertUnicodeScalarString(input.userInput, "user input");
  const signal = input.signal ?? new AbortController().signal;
  const observePreview = bestEffortPreviewObserver(input.onPreview);
  const opened = await openJournal(
    input.workspaceRoot,
    input.sessionId,
    input.clock ?? systemJournalClock,
    input.eventIds ?? randomEventIdentitySource,
    persistenceControls,
  );
  let phase: KernelPhase = "created";
  try {
    const [blobs, snapshots] = await Promise.all([
      createBlobStore(opened.paths.sessionDir, persistenceControls),
      createSnapshotStore(opened.paths.sessionDir, persistenceControls),
    ]);
    const initialized = await initialize(opened, input, blobs);
    const { cacheAbi, lineageId, runId } = initialized;
    let boundary = initialized.boundary;
    let requestCount = 0;
    phase = transition(phase, "ready");

    for (;;) {
      if (signal.aborted) {
        await opened.writer.append({
          type: "run_interrupted",
          sessionId: input.sessionId,
          lineageId,
          runId,
          payload: { reason: "cancelled", sourceEventId: boundary.id },
        });
        phase = transition(phase, "interrupted");
        throw new SessionInterruptedError("cancelled");
      }
      let snapshotEvent: VerifiedJournalEvent<"request_snapshot_stored">;
      let requestSnapshot: DeepSeekRequestSnapshot;
      try {
        const journalFacts = eventsThrough(opened.writer.events, boundary.id);
        snapshotEvent = await storeProjectedSnapshotV1({
          snapshotStore: snapshots,
          journal: opened.writer,
          requestSnapshotId: newRequestSnapshotId(),
          sessionId: input.sessionId,
          runId,
          projectionInput: {
            cacheAbi,
            journalFacts,
            externalBlobs: await externalBlobMap(journalFacts, lineageId, blobs),
            lineageId,
            commitBoundaryId: boundary.payload.commitBoundaryId,
          },
        });
        requestSnapshot = await restoredSnapshot(snapshots, snapshotEvent);
      } catch {
        const source = opened.writer.events.findLast(
          (event) => event.lineageId === lineageId && event.runId === runId,
        ) ?? boundary;
        const closed = await closeDurabilityFailure({
          writer: opened.writer,
          sessionId: input.sessionId,
          lineageId,
          runId,
          sourceEventId: source.id,
        });
        phase = transition(phase, "interrupted");
        if (!closed) throw new SessionKernelError("durability_failure");
        throw new SessionInterruptedError("durability_failure");
      }
      if (signal.aborted) {
        await opened.writer.append({
          type: "run_interrupted",
          sessionId: input.sessionId,
          lineageId,
          runId,
          payload: { reason: "cancelled", sourceEventId: snapshotEvent.id },
        });
        phase = transition(phase, "interrupted");
        throw new SessionInterruptedError("cancelled");
      }
      await beforeSend?.(
        Object.freeze({
          snapshot: requestSnapshot,
          acknowledgedEvents: opened.writer.events,
        }),
      );

      phase = transition(phase, "requesting");
      const attempts = new Map<number, VerifiedJournalEvent<"request_attempt_started">>();
      const semanticAttempts = new Set<string>();
      let activeAttempt: VerifiedJournalEvent<"request_attempt_started"> | undefined;
      const lifecycle: DeepSeekRetryLifecycle = {
        beforeAttempt: async (ordinal, candidate) => {
          if (candidate !== requestSnapshot || attempts.has(ordinal)) {
            throw new SessionKernelError("invalid_state");
          }
          const attempt = asEvent(
            await opened.writer.append({
              type: "request_attempt_started",
              sessionId: input.sessionId,
              lineageId,
              runId,
              payload: {
                attemptId: newAttemptId(),
                requestSnapshotId: snapshotEvent.payload.requestSnapshotId,
                ordinal,
              },
            }),
            "request_attempt_started",
          );
          attempts.set(ordinal, attempt);
          activeAttempt = attempt;
        },
        onSemanticStarted: async (ordinal) => {
          const attempt = attempts.get(ordinal);
          if (attempt === undefined || activeAttempt?.id !== attempt.id) {
            throw new SessionKernelError("invalid_state");
          }
          await opened.writer.append({
            type: "request_semantic_started",
            sessionId: input.sessionId,
            lineageId,
            runId,
            payload: { attemptId: attempt.payload.attemptId },
          });
          semanticAttempts.add(attempt.id);
        },
        afterInterrupted: async (
          ordinal,
          failure,
          semanticState,
          decision,
        ) => {
          const attempt = attempts.get(ordinal);
          if (attempt === undefined || activeAttempt?.id !== attempt.id) {
            throw new SessionKernelError("invalid_state");
          }
          const interrupted = asEvent(
            await opened.writer.append({
              type: "request_interrupted",
              sessionId: input.sessionId,
              lineageId,
              runId,
              payload: {
                attemptId: attempt.payload.attemptId,
                requestSnapshotId: snapshotEvent.payload.requestSnapshotId,
                outcome: failureOutcome(failure),
                status:
                  failure instanceof DeepSeekHttpError ? failure.status : null,
                retryClass:
                  decision.retryClass === "unknown"
                    ? "unknown"
                    : decision.retryClass,
                semanticState: semanticWire(semanticState),
              },
            }),
            "request_interrupted",
          );
          activeAttempt = undefined;
          if (!decision.retry) {
            await opened.writer.append({
              type: "run_interrupted",
              sessionId: input.sessionId,
              lineageId,
              runId,
              payload: {
                reason: interruptionReason(failure, semanticState),
                sourceEventId: interrupted.id,
              },
            });
          }
        },
      };

      let response: CompletedDeepSeekResponse;
      try {
        response = await send(
          requestSnapshot,
          lifecycle,
          observePreview,
          signal,
        );
      } catch (error) {
        let terminal = opened.writer.events.findLast(
          (event): event is VerifiedJournalEvent<"run_interrupted"> =>
            event.type === "run_interrupted" &&
            event.lineageId === lineageId &&
            event.runId === runId,
        );
        if (terminal === undefined) {
          if (opened.writer.state !== "open") {
            phase = transition(phase, "interrupted");
            throw new SessionKernelError("durability_failure");
          }
          let source = opened.writer.events.findLast(
            (event) => event.lineageId === lineageId && event.runId === runId,
          );
          try {
            if (activeAttempt !== undefined) {
              const semanticState: DeepSeekSemanticState = semanticAttempts.has(
                activeAttempt.id,
              )
                ? "post_semantic"
                : "pre_semantic";
              source = await opened.writer.append({
                type: "request_interrupted",
                sessionId: input.sessionId,
                lineageId,
                runId,
                payload: {
                  attemptId: activeAttempt.payload.attemptId,
                  requestSnapshotId: snapshotEvent.payload.requestSnapshotId,
                  outcome:
                    error instanceof SessionKernelError
                      ? "durability_error"
                      : error instanceof Error
                        ? failureOutcome(error)
                        : "durability_error",
                  status:
                    error instanceof DeepSeekHttpError ? error.status : null,
                  retryClass:
                    error instanceof DeepSeekProtocolError
                      ? "protocol"
                      : error instanceof DeepSeekTransportError
                        ? error.kind === "timeout"
                          ? "timeout"
                          : error.kind === "cancelled"
                            ? "cancelled"
                            : "transport_unknown"
                        : "unknown",
                  semanticState: semanticWire(semanticState),
                },
              });
              activeAttempt = undefined;
            }
            if (source === undefined) {
              throw new SessionKernelError("durability_failure");
            }
            const reason =
              error instanceof DeepSeekTransportError && error.kind === "cancelled"
                ? "cancelled"
                : "durability_failure";
            await opened.writer.append({
              type: "run_interrupted",
              sessionId: input.sessionId,
              lineageId,
              runId,
              payload: { reason, sourceEventId: source.id },
            });
          } catch {
            phase = transition(phase, "interrupted");
            throw new SessionKernelError("durability_failure");
          }
          terminal = opened.writer.events.findLast(
            (event): event is VerifiedJournalEvent<"run_interrupted"> =>
              event.type === "run_interrupted" &&
              event.lineageId === lineageId &&
              event.runId === runId,
          );
        }
        phase = transition(phase, "interrupted");
        if (terminal === undefined) {
          throw new SessionKernelError("durability_failure");
        }
        throw new SessionInterruptedError(terminal.payload.reason);
      }
      requestCount += 1;
      const successfulAttempt = activeAttempt;
      if (successfulAttempt === undefined) {
        throw new SessionKernelError("invalid_state");
      }
      try {
        validateResponse(response);
        if (
          (response.semanticDeltaCount > 0) !==
          semanticAttempts.has(successfulAttempt.id)
        ) {
          throw new SessionKernelError("invalid_state");
        }
      } catch {
        const semanticState: DeepSeekSemanticState = semanticAttempts.has(
          successfulAttempt.id,
        )
          ? "post_semantic"
          : "pre_semantic";
        const interrupted = asEvent(
          await opened.writer.append({
            type: "request_interrupted",
            sessionId: input.sessionId,
            lineageId,
            runId,
            payload: {
              attemptId: successfulAttempt.payload.attemptId,
              requestSnapshotId: snapshotEvent.payload.requestSnapshotId,
              outcome: "protocol_error",
              status: null,
              retryClass: "protocol",
              semanticState: semanticWire(semanticState),
            },
          }),
          "request_interrupted",
        );
        activeAttempt = undefined;
        await opened.writer.append({
          type: "run_interrupted",
          sessionId: input.sessionId,
          lineageId,
          runId,
          payload: {
            reason:
              semanticState === "post_semantic"
                ? "semantic_interrupted"
                : "request_failed",
            sourceEventId: interrupted.id,
          },
        });
        phase = transition(phase, "interrupted");
        throw new SessionInterruptedError(
          semanticState === "post_semantic"
            ? "semantic_interrupted"
            : "request_failed",
        );
      }
      phase = transition(phase, "committing_assistant");
      let assistant: VerifiedJournalEvent<"assistant_committed"> | undefined;
      try {
        const assistantPayload = await blobs.publish(
          "assistant",
          response.assistantBytes,
          rolePosition(opened.writer.events, lineageId),
        );
        assistant = asEvent(
          await opened.writer.append({
            type: "assistant_committed",
            sessionId: input.sessionId,
            lineageId,
            runId,
            payload: {
              ...assistantPayload,
              attemptId: successfulAttempt.payload.attemptId,
              requestSnapshotId: snapshotEvent.payload.requestSnapshotId,
              providerRequestId: response.providerRequestId,
              responseModel: response.responseModel,
              systemFingerprint: response.systemFingerprint,
              semanticDeltaCount: response.semanticDeltaCount,
              usage: response.usage,
            },
          }),
          "assistant_committed",
        );
      } catch {
        const semanticState: DeepSeekSemanticState = semanticAttempts.has(
          successfulAttempt.id,
        )
          ? "post_semantic"
          : "pre_semantic";
        const closed = await closeDurabilityFailure({
          writer: opened.writer,
          sessionId: input.sessionId,
          lineageId,
          runId,
          sourceEventId: successfulAttempt.id,
          attempt: successfulAttempt,
          requestSnapshotId: snapshotEvent.payload.requestSnapshotId,
          semanticState,
        });
        activeAttempt = undefined;
        phase = transition(phase, "interrupted");
        if (!closed) throw new SessionKernelError("durability_failure");
        throw new SessionInterruptedError("durability_failure");
      }
      activeAttempt = undefined;
      let checkpoint: VerifiedJournalEvent<"cache_checkpoint_created">;
      try {
        checkpoint = await appendCheckpoint(
          opened.writer,
          input.sessionId,
          lineageId,
          runId,
          assistant,
        );
      } catch {
        phase = transition(phase, "interrupted");
        throw new SessionKernelError("durability_failure");
      }

      if (response.toolCalls.length === 0) {
        try {
          boundary = await appendBoundary(
            opened.writer,
            input.sessionId,
            lineageId,
            runId,
            [assistant.id],
            checkpoint.payload.cacheCheckpointId,
          );
          await opened.writer.append({
            type: "run_completed",
            sessionId: input.sessionId,
            lineageId,
            runId,
            parentId: boundary.id,
            payload: {
              commitBoundaryId: boundary.payload.commitBoundaryId,
              sourceAssistantEventId: assistant.id,
            },
          });
        } catch {
          phase = transition(phase, "interrupted");
          throw new SessionKernelError("durability_failure");
        }
        phase = transition(phase, "completed");
        return Object.freeze({
          status: "completed",
          sessionId: input.sessionId,
          lineageId,
          runId,
          content: response.content,
          commitBoundaryId: boundary.payload.commitBoundaryId,
          requestCount,
        });
      }

      phase = transition(phase, "executing_tools");
      const durability = new JournalToolDurability({
        scope: {
          sessionId: input.sessionId,
          lineageId,
          runId,
          sourceAssistantEventId: assistant.id,
        },
        writer: opened.writer,
        artifacts: opened.artifacts,
        blobs,
        blobPosition: rolePosition(opened.writer.events, lineageId),
      });
      let results;
      try {
        results = await new ToolRuntime({
          durability,
          cwd: resolve(input.workspaceRoot),
          storageRoot: opened.paths.dshDir,
          canonicalEnvPath: resolve(input.workspaceRoot, ".env"),
          umask: 0o022,
        }).execute(response.toolCalls, signal);
      } catch (error) {
        const terminal = opened.writer.events.findLast(
          (event): event is VerifiedJournalEvent<"run_interrupted"> =>
            event.type === "run_interrupted" &&
            event.lineageId === lineageId &&
            event.runId === runId,
        );
        if (terminal === undefined) {
          throw error instanceof ToolDurabilityError
            ? new SessionKernelError("durability_failure")
            : error;
        }
        phase = transition(phase, "interrupted");
        throw new SessionInterruptedError(terminal.payload.reason);
      }
      try {
        boundary = await appendBoundary(
          opened.writer,
          input.sessionId,
          lineageId,
          runId,
          results.map((result) => result.eventId),
          null,
        );
      } catch {
        phase = transition(phase, "interrupted");
        throw new SessionKernelError("durability_failure");
      }
      if (signal.aborted) {
        try {
          await durability.interruptRun("cancelled", boundary.id);
        } catch (error) {
          if (!(error instanceof ToolDurabilityError)) throw error;
        }
        phase = transition(phase, "interrupted");
        const terminal = opened.writer.events.findLast(
          (event): event is VerifiedJournalEvent<"run_interrupted"> =>
            event.type === "run_interrupted" &&
            event.lineageId === lineageId &&
            event.runId === runId &&
            event.payload.reason === "cancelled" &&
            event.payload.sourceEventId === boundary.id,
        );
        if (terminal === undefined) {
          throw new SessionKernelError("durability_failure");
        }
        throw new SessionInterruptedError("cancelled");
      }
      phase = transition(phase, "ready");
    }
  } finally {
    await opened.writer.close().catch(() => undefined);
  }
}

export async function captureSessionEnvironment(
  workspaceRoot: string,
): Promise<SessionEnvironmentFacts> {
  const cwd = resolve(workspaceRoot);
  const branch = spawnSync("git", ["-C", cwd, "branch", "--show-current"], {
    encoding: "utf8",
  });
  const status = spawnSync("git", ["-C", cwd, "status", "--short"], {
    encoding: "utf8",
  });
  const git =
    branch.status === 0 && status.status === 0
      ? `branch: ${branch.stdout.trim() || "detached"}\nstatus:\n${status.stdout.trim()}`
      : "not a git repository";
  return Object.freeze({
    date: new Date().toISOString().slice(0, 10),
    cwd,
    git,
  });
}

export async function runOfficialSession(
  input: OfficialSessionInput,
): Promise<CompletedSessionResult> {
  const environmentFacts =
    input.environmentFacts ?? (await captureSessionEnvironment(input.workspaceRoot));
  return runKernel({ ...input, environmentFacts }, (snapshot, lifecycle, preview, signal) =>
    runDeepSeekOfficialWithRetry(snapshot, input.credential, {
      lifecycle,
      signal,
      ...(preview === undefined ? {} : { onSemanticDelta: preview }),
    }),
  );
}

export function runSessionFixture(
  input: SessionFixtureInput,
): Promise<CompletedSessionResult> {
  let turnIndex = 0;
  return runKernel(input, async (snapshot, lifecycle, preview, signal) => {
    await lifecycle.beforeAttempt(1, snapshot);
    const turn = input.turns[turnIndex];
    turnIndex += 1;
    if (turn === undefined) throw new SessionKernelError("fixture_exhausted");
    if (signal.aborted) {
      const failure = new DeepSeekTransportError("cancelled", "ABORTED");
      const decision: DeepSeekRetryDecision = {
        retry: false,
        delayMs: null,
        retryClass: "cancelled",
        integritySelfCheck: false,
      };
      await lifecycle.afterInterrupted(1, failure, "pre_semantic", decision);
      throw failure;
    }
    const fragments = turn.fragments ?? [];
    if (
      fragments.length > 0 ||
      (turn.kind === "success" && turn.response.semanticDeltaCount > 0) ||
      (turn.kind === "interrupted" && turn.semanticState === "post_semantic")
    ) {
      await lifecycle.onSemanticStarted(1);
    }
    for (const fragment of fragments) await preview?.(Object.freeze(fragment));
    if (turn.kind === "interrupted") {
      await lifecycle.afterInterrupted(
        1,
        turn.failure,
        turn.semanticState,
        turn.decision,
      );
      throw turn.failure;
    }
    return turn.response;
  }, input.onBeforeSend, input.persistenceControls);
}
