#!/usr/bin/env node

import { loadDeepSeekCredential, CredentialError } from "./ds/credential.js";
import { newSessionId } from "./journal/index.js";
import {
  captureSessionEnvironment,
  runOfficialSession,
  SessionInterruptedError,
  SessionKernelError,
} from "./session/index.js";
import type { DeepSeekSemanticFragment } from "./ds/types.js";

const USAGE = "Usage: dsh run <prompt...>\n       printf '<prompt>' | dsh run\n";

type CliFailure = Readonly<{
  readonly message: string;
  readonly exitCode: number;
}>;

class CliInputError extends Error {
  constructor() {
    super("invalid CLI input");
    this.name = "CliInputError";
  }
}

async function promptFromStdin(): Promise<string> {
  if (process.stdin.isTTY === true) throw new CliInputError();
  process.stdin.setEncoding("utf8");
  let prompt = "";
  for await (const chunk of process.stdin) prompt += chunk;
  if (prompt.trim().length === 0) throw new CliInputError();
  return prompt;
}

async function parsePrompt(arguments_: readonly string[]): Promise<string> {
  if (arguments_[0] !== "run") throw new CliInputError();
  const promptParts = arguments_.slice(1);
  if (promptParts.length === 0) return promptFromStdin();
  const prompt = promptParts.join(" ");
  if (prompt.trim().length === 0) throw new CliInputError();
  return prompt;
}

function classifyFailure(error: unknown): CliFailure {
  if (error instanceof CliInputError) {
    return Object.freeze({ message: "dsh: invalid_invocation\n", exitCode: 2 });
  }
  if (error instanceof CredentialError) {
    return Object.freeze({
      message: `dsh: credential_${error.code}\n`,
      exitCode: 3,
    });
  }
  if (error instanceof SessionInterruptedError) {
    return Object.freeze({
      message: `dsh: session_interrupted_${error.reason}\n`,
      exitCode: error.reason === "cancelled" ? 130 : 4,
    });
  }
  if (error instanceof SessionKernelError) {
    return Object.freeze({
      message: `dsh: session_${error.code}\n`,
      exitCode: 5,
    });
  }
  return Object.freeze({ message: "dsh: internal_error\n", exitCode: 1 });
}

function renderPreview(fragment: DeepSeekSemanticFragment): void {
  if (fragment.kind !== "tool_call") process.stderr.write(fragment.text);
}

async function main(): Promise<void> {
  const arguments_ = process.argv.slice(2);
  if (
    arguments_.length === 1 &&
    (arguments_[0] === "--help" || arguments_[0] === "-h")
  ) {
    process.stdout.write(USAGE);
    return;
  }
  if (
    arguments_.length === 2 &&
    arguments_[0] === "run" &&
    (arguments_[1] === "--help" || arguments_[1] === "-h")
  ) {
    process.stdout.write(USAGE);
    return;
  }

  const controller = new AbortController();
  const onInterrupt = (): void => controller.abort();
  process.once("SIGINT", onInterrupt);
  try {
    const prompt = await parsePrompt(arguments_);
    const workspaceRoot = process.cwd();
    const credential = loadDeepSeekCredential({ projectRoot: workspaceRoot });
    const environmentFacts = await captureSessionEnvironment(workspaceRoot);
    const result = await runOfficialSession({
      workspaceRoot,
      sessionId: newSessionId(),
      userInput: prompt,
      environmentFacts,
      signal: controller.signal,
      onPreview: renderPreview,
      credential,
    });
    process.stdout.write(result.content);
  } catch (error) {
    const failure = classifyFailure(error);
    process.stderr.write(failure.message);
    process.exitCode = failure.exitCode;
  } finally {
    process.removeListener("SIGINT", onInterrupt);
  }
}

await main();
