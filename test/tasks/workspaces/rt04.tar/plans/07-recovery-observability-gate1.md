# Stage 07 — Recovery, Observability, and Gate 1

- **Status:** `BLOCKED`
- **Gate:** Gate 1 exit
- **Depends on:** Stage 06 Session Kernel
- **Lead:** unassigned
- **Baseline:** record when activated
- **Review:** required because this stage integrates recovery, reconciliation, persistent projections, and user control
- **Exclusive write scope:** recovery integration, `src/cost/**`, read-only UI/diagnostic projections, fixed task suite, `test:recovery` and `test:acceptance` wiring

## Actual need

A runnable loop is not durable until it can restart from facts, refuse ambiguous effects, expose what the model and tools actually saw, and demonstrate useful behavior on a fixed real-task suite. Gate 1 is the first point at which SimpleDSH may be called a usable harness.

## Contract and invariant impact

- Charter: recovery semantics, observability/fitness, Durable Minimal Loop, and metric priority.
- Engineering Spec: invariants 3–5; replay/integrity; cost SLI; validation cases 1, 3, 7, and 8; M1.
- Protects new-Run recovery, Commit Boundary safety, fail-closed effects, request-byte identity, and a single source of truth.
- Metric order: invariants first, then fixed-suite pass@1, then uncached tokens/task, then wall-clock.

## Smallest working loop

```text
run a scripted task
→ kill at a selected crash point
→ replay Journal + Artifacts
→ classify every open effect
→ validate durable tail against last safe Commit Boundary
→ create a new Run on the same Lineage and continue/stop by exact Effect state
→ complete task
→ render exact context/effect/cost evidence
```

## In scope

- Startup replay, integrity validation, Commit Boundary safety proof, legal pending-tail classification, and creation of a new Run on the same append-only Lineage; never resume old process memory or roll back durable assistant/tool facts.
- Recovery decision limited to proven-not-executed, proven-completed, or `indeterminate`.
- Explicit reconcile input/event for `indeterminate`; no guessed or automatic write-effect retry.
- Crash matrix across Journal append/atomic torn-tail repair, request send, pre/post semantic delta, atomic assistant+usage success, derived Cache Checkpoint, effect prepared/executing/completed, complete tool-result batch, each Commit Boundary, and final Run closure.
- Read-only projections for exact model context/Snapshot hash, Session/ABI/Lineage/Run/boundaries, tool/effect state, active processes, Artifact locations, interruptions, cache usage, cost, and recovery controls.
- Cost ledger projected from native usage facts using only dated Flash prices: hit `$0.0028`, miss `$0.14`, output `$0.28` per 1M tokens (`r=50`, verified 2026-08-03); no Pro/high price table or selectable model dimension.
- Three separate metric groups: task effect, cache efficiency, runtime correctness.
- Stage 07 freezes the observed real-task manifest/tasks/verifiers/budgets/timeouts in-repo before the first model run; Stage 00 fixes the sourcing protocol and 4/4 threshold.
- Ten-turn live cache scenario fixed to official endpoint + Flash/thinking/max, reported as best-effort distribution; deterministic CI gate is exact prefix/Snapshot identity and zero unplanned Cache Break.
- Gate 1 credential handling: `.env` is ignored/non-symlink/`0600`; only CredentialLoader automatically reads it and only `src/ds` transiently consumes key for Authorization at send; header captures redact it and Stage 05's closed child environment does not automatically inherit credentials. The automatic credential path keeps values out of Snapshot body, Journal, Artifact, logs, diagnostics, Context, child env, projections, and evidence. v0.1 provides no bash execution isolation: a same-user command may actively read local files and its output is ordinary tool output, so bash boundary tests use only a synthetic non-secret marker and documentation states this limitation plainly.
- Minimal user operations to inspect, interrupt, recover, and reconcile the active Session without any branch-origin or Fork surface.

## Non-goals

- No general permission policy or workspace containment beyond Stage 05's fixed `.env`/protected-`.dsh` file-tool mistake guards; no adversarial bash isolation, built-in VM/container/backend, compaction, fork execution, extensions, aggregate cross-unit “score,” or hidden trace database.
- No claim that a pending/partial suite run is task-quality evidence.
- No use of a single DeepSeek cache miss as a deterministic code failure.

## Readiness gate

- [ ] Stages 02–06 have accepted review verdicts and matching event/schema hashes.
- [ ] Stage 05 proves the single macOS/Linux native `/bin/bash` path without Lima/runtime prerequisites, the Windows-only unavailable branch, closed child environment, direct-child terminal plus bounded cleanup observation, and an honest same-user bash-access marker.
- [ ] Stage 00's real-task sourcing/freeze protocol and 4/4 threshold are fixed; Stage 07 selects four observed Stage02–06 tasks and freezes full manifest/bytes/caps with fresh review before the first model run.
- [ ] Crash points and expected outcomes are indexed before implementation changes.
- [ ] Live cache/task budget and credential use are explicitly authorized.
- [ ] Flash official prices and verification date are refreshed; any drift updates the dated price fact without changing historical ledgers.
- [ ] A single integration Lead owns recovery and shared CLI projections.

## Work packages

1. **Replay and integrity:** rebuild all state from Journal/Artifacts and reject invalid closure.
2. **Recovery planner:** deterministic safe-boundary plus pending-tail/open-effect classification and same-Lineage new Run creation.
3. **Reconcile path:** explicit operator evidence and durable resolution.
4. **Crash harness:** deterministic process-kill/fault injection at every indexed point.
5. **Read-only projections:** fixed Flash model view, state ids, effects/processes, evidence, and Flash-priced cost/cache.
6. **Fixed task suite:** source four observed tasks, prove fail→pass provenance, then freeze manifest/task/prompt/fixture/verifier/caps before any live result.
7. **Gate 1 run:** offline crash/acceptance plus separately budgeted live cache/task evidence.

## Ownership and allowed parallelism

| Lane | Exclusive scope | May overlap |
|---|---|---|
| Lead | recovery state machine, reconcile events, shared CLI/status | none on shared state |
| Crash worker | reserved fault harness/fixtures | projection worker |
| Projection worker | cost/read-only projection files | crash worker after event freeze |
| Suite worker | fixed task data/verifiers only | implementation after suite contract freeze |
| Verification worker | read-only full-gate execution | after patch freeze |

Only the Lead changes event schema, Session state, package scripts, or gate thresholds. The suite Worker cannot tune tasks after seeing implementation results.

## Verification

| Evidence | Exact command | Expected result | Actual result |
|---|---|---|---|
| Recovery/crash suite | `npm run test:recovery` | exit 0; every crash point has one allowed state | — |
| New Run rule | `npm run test:recovery -- --test-name-pattern="new Run|old stack"` | recovered execution uses a new Run id | — |
| Effect ambiguity | `npm run test:recovery -- --test-name-pattern="indeterminate|reconcile"` | no retry before durable reconcile | — |
| Byte identity | `npm run test:recovery -- --test-name-pattern="snapshot bytes|request hash"` | safe retry/recovery uses stored exact bytes | — |
| Disposable projections | `npm run test:recovery -- --test-name-pattern="delete projections|rebuild"` | identical UI/cost/state from facts | — |
| Fixed task gate | `npm run test:acceptance` | exit 0; frozen threshold and Tier-0 invariants pass | — |
| Fixed request and credential boundary | `npm run test:acceptance -- --test-name-pattern="Flash|max|credential|env|authorization|bash boundary|closed env"` | fixed body; header-only key/redaction; closed child env; automatic credential path absent from persisted/model/tool surfaces; non-secret marker proves explicit bash read/ordinary persistence and documentation makes no isolation claim | — |
| Live cache evidence | `DSH_LIVE=1 npm run test:live:cache` | 10-turn report; zero byte drift/cache breaks; hit distribution recorded | — |
| Static/full checks | `npm run check` | exit 0 | — |

Evidence report must include pass@1, time, calls, interventions; uncached tokens and hit/miss by fixed `deepseek-v4-flash` + Lineage; protocol/recovery/tool errors, `indeterminate` count, and cost split at dated Flash prices. Do not collapse them into one score.

## Independent review

Use a fresh read-only reviewer on the concrete crash matrix, recovery/reconcile state machine, projection authority, and Gate 1 evidence. A review request receives only need, constraints, relevant plan/diff/code, and validation evidence. Record verdict and cuts.

- **Reviewer context/date:** —
- **Verdict:** —
- **Required cuts/evidence:** —

## No-go conditions

- Recovery continues an old connection/stack or silently reconstructs a changed request.
- “Rollback” is treated as undoing an external effect.
- An unknown effect is retried because the tool is believed idempotent.
- Cost/UI/search state cannot be rebuilt from Journal/Artifacts.
- Fixed tasks, thresholds, or verifier change after results without a new suite version.
- Gate 1 is claimed from cache/loss/partial-completion evidence without task outcomes.
- Cost uses Pro/high or an undated/mixed-model table, request identity is switchable, the automatic credential path or child environment leaks key material, a real credential is used as a bash sentinel, documentation claims same-user bash cannot read accessible secrets, a non-Windows host returns unavailable because a host runtime prerequisite is absent, or Windows attempts the native bash path.

## Handoff evidence

Return baseline/revision, crash matrix, traces, fixed-suite outputs, commands/exits, three metric groups, dated Flash price source and cost, fixed request-identity proof, automatic credential non-flow plus explicit same-user bash-access marker evidence without real values, reviewer verdict, and Stage 08 assumptions.

## Completion and cleanup

- [ ] All Actual result, reviewer, suite, and live-evidence fields are complete.
- [ ] Gate 1 threshold is met with protocol/recovery/effect invariants intact.
- [ ] Durable recovery/metric workflows are promoted only if reusable.
- [ ] Unblock Stage 08 with evidence artifacts and exact commands.
- [ ] Remove this Plan and its index row after handoff.
