# Stage 08 — Permissions, File Containment, and Supply Chain

- **Status:** `BLOCKED`
- **Gate:** Gate 2 foundation
- **Depends on:** accepted Stage 07 / Gate 1 revision, including stable Effect Gateway, abort/direct-child-terminal and bounded cleanup-observation evidence, Journal decision events, and recovery semantics
- **Lead:** unassigned
- **Baseline:** record when activated
- **Review:** required because this stage changes permission, deterministic file-containment, credential-handling, doctor, and dependency-trust semantics
- **Exclusive write scope:** `src/permission/**`, Stage 08-owned file-containment/doctor/security fixtures, supply-chain checks; root manifests, lock/shrinkwrap, CI, and shared CLI wiring are Lead-only

## Actual need

The Gate 1 loop can execute repository-changing commands but does not yet have a pure, explainable permission decision layer or a component-aware workspace/`allow_write` guard against accidental file-tool escape. Allowed bash remains unrestricted native execution with the current user's authority. The Node process also holds an API key and shell access, so its automatic credential path and npm dependency tree need narrow, testable controls. v0.1 does not provide bash execution isolation; `dsh doctor` must state that boundary plainly rather than imply an operating-system sandbox.

## Contract and invariant impact

- Charter: one Effect Gateway, visible permissions, honest execution/non-isolation boundaries, fail-closed side effects, and no permission theater.
- Engineering Spec: TypeScript pitfall 6; §§11, 14; roadmap M2.
- Preserves Journal authority: approval decisions are durable facts, not hidden session grants.
- Preserves effect ordering: deny/ask resolves before `prepared`; approved execution still uses Stage 05's effect bracket and process lifecycle.
- Expected impact is fewer accidental unauthorized writes and dependency risks; no adversarial-security, task-quality, cache, or speed gain is claimed.

## Smallest working loop

```text
validated tool call -> pure policy decision
-> deny: durable decision + blocked result, no prepared/effect
-> ask: explicit approval -> durable scoped decision
-> file tool: component-aware workspace/allow_write containment
   allowed bash: direct Stage 05 native runner, with no path/security containment claim
-> Stage 05 prepared -> effect -> completed/indeterminate
```

## In scope

- Pure `decide(policy, tool, readOnly, validatedArgs)` with no I/O, time, environment, or mutable state.
- Precedence `deny > ask > allow > fallback`; read fallback is Allow, writer fallback is configured Mode, default Ask.
- Resolution order is fixed: Deny remains absolute; explicit `--yes` converts only Ask to Allow and records `resolution=yes_flag`; otherwise an Ask with no usable TTY always resolves to Deny with `resolution=non_interactive`. There is no configuration override.
- Interactive approval durably records one tool-call-scoped `permission_decided` before execution: the normalized subject is reconstructed from the already-frozen validated arguments, and the event records decision, scope, and source. No Effect id exists before an allowed T2 call reaches `effect_prepared`, and there is no hidden approval window or second approval store.
- Prefix rules reject shell-control continuations such as `&&`, `||`, `;`, pipes, redirections, command substitution, and newlines.
- Existing targets use `fs.realpath`; new targets canonicalize the nearest existing parent; containment is path-component aware, not string-prefix based.
- File-guard fixtures cover `..`, absolute escape, existing symlink files/directories, missing/new-target parents, and deterministic swaps. This is low-cost accidental-write protection only and does not claim adversarial TOCTOU resistance.
- Stage 05 lifecycle behavior remains regression-covered: native timeout/cancel applies TERM→KILL to the original PGID, records the direct-child terminal, and makes only a bounded negative-PGID plus double-EOF observation. A self-expiring setsid fixture records `descendantsReaped=false` without indeterminate; none of this is containment.
- Preserve Stage 05's closed child environment and canonical `.env`/protected-`.dsh` file-tool mechanical denies while adding Policy/file containment. These controls do not protect files from bash.
- `dsh doctor` reports factual configuration, credential metadata, Journal/Artifact permissions, package/dependency health, non-Windows `/bin/bash` availability, the closed child-env names, and the cleanup-observation definition. It states explicitly that v0.1 has no built-in bash execution isolation; Windows bash is unavailable. It does not probe/select a backend or report a sandbox capability state.
- Only CredentialLoader may automatically read `.env`; only `src/ds` may consume `DEEPSEEK_API_KEY`, and only to attach it to the official HTTP Authorization header at send time. Header captures redact the value and the closed tool child environment does not automatically inherit credentials. `.env` is ignored/not packed, non-symlink `0600`, and cannot override endpoint/model/thinking/effort.
- The automatic credential path never enters model-visible Snapshot body, Journal, Artifact, logs, diagnostics, Context, child env, or evidence. File-tool rules for `.env`, PEM, or `.ssh` are mistake guards only. A same-user bash command can actively read any host file the user can read and its output may become ordinary tool output; tests use only synthetic non-secret markers and documentation makes no security guarantee.
- `.dsh/` directory mode 0700 and files 0600; documentation distinguishes automatic harness credential handling from arbitrary plaintext repository or host data.
- Audit and ratchet the exact direct pins, published `npm-shrinkwrap.json`, ignored-script install path, lifecycle allowlist, and dependency-count baseline already established by Stage 01; changes require attributable need and the count may only stay level or decrease.
- Registry audit/signature checks and isolated packed-install smoke coverage; network-dependent evidence is reported separately from deterministic CI.

## Non-goals

- No built-in bash execution isolation, OS/container/VM backend, adversarial sandbox claim, credential vault, DLP, encrypted Journal, or secret-scanning rewrite.
- No claim that Policy or realpath prevents an adversarial same-user command from reading or modifying accessible host data.
- No plan/goal mode, temporary authorization state machine, autonomous approver, dynamic tool set, or background security service.
- The sandbox portion was removed because v0.1 abandoned execution isolation; its absence is an intentional product decision, not an omitted work package. Reintroduction requires a new product contract. Whole-application isolation may be a deployment choice but is not a SimpleDSH capability state or host prerequisite.

## Readiness gate

- [ ] Stage 07 Gate 1 evidence is accepted, including zero blind effect replay and passing abort/direct-child-terminal/cleanup-observation tests.
- [ ] Stage 05/07 evidence proves the single native non-Windows bash path, Windows-only unavailable branch, closed child environment, bounded cleanup observation, and honest credential boundary without a Lima/container/runtime prerequisite.
- [ ] The Spec fixes the no-bash-isolation product boundary and `doctor`'s honest user-visible statement.
- [ ] At least one native Unix runner and the Windows-unavailable fixture are available; absence of Lima/container/runtime tooling cannot alter non-Windows behavior. Stage 12 owns the final real macOS/Linux platform matrix.
- [ ] One Lead owns policy grammar, file-containment/doctor facts, supply-chain ratchet, CI, and shared CLI wiring; Stage 01's manifests/lock/shrinkwrap are inputs and change only for an attributable reviewed need.
- [ ] Baseline revision, dependency count, lifecycle scripts, `.env` ignore/mode/package state, and unrelated dirty paths are recorded without reading values.

## Work packages

1. Implement and exhaustively fixture the pure Policy, precedence, non-TTY, `--yes`, subject extraction, and approval record.
2. Implement canonical path containment and deterministic race fixtures; label the guarantee as accidental-write protection only.
3. Integrate Policy/file containment with the Stage 05 Gateway while preserving native bash, direct-child terminal, and bounded cleanup-observation semantics.
4. Add factual `doctor`, `.env` metadata/automatic credential-path and file-mode checks, file-tool sensitive-read denies, a non-secret explicit-bash-read marker, and the explicit no-bash-isolation statement.
5. Re-audit and, only where evidence requires, strengthen Stage 01's pins/shrinkwrap/ignored-scripts/allowlist/count ratchet; add registry audit and isolated install evidence without creating a second lock baseline.

## Ownership and allowed parallelism

| Lane | Exclusive paths | Start condition |
|---|---|---|
| Policy worker | `src/permission/**`, reserved policy fixtures | grammar and Journal event frozen |
| Containment worker | reserved deterministic path/`allow_write`/doctor fixtures | path contract and fixture ownership frozen |
| Supply worker | reserved checks/fixtures | audits Stage 01 baseline; only Lead may make an evidenced manifest/lock/shrinkwrap or CI change |
| Verification worker | read-only matrix execution | patch and dependency tree frozen |
| Lead only | shared CLI/doctor, Effect integration, root manifests, lock/shrinkwrap, CI | always serial |

## Planned validation commands

| Evidence | Exact command | Expected result | Actual result |
|---|---|---|---|
| Runtime baseline | `node --version` | supported Node >= 22 | |
| Script-safe clean install | `npm ci --ignore-scripts` | exit 0; only allowlisted explicit lifecycle handling | |
| Stage 01 supply baseline ratchet | `npm run check` | exit 0; exact pins/shrinkwrap/integrity remain attributable and dependency count does not increase | |
| Policy/path/credential/process/supply matrix | `npm run test:security` | exit 0; precedence, shell-prefix, component containment, automatic credential non-flow, native no-prerequisite/Windows-unavailable facts, bounded cleanup observation, factual doctor, and package cases pass | |
| Registry vulnerabilities | `npm audit --omit=dev` | no unresolved accepted-severity production finding | |
| Registry signatures | `npm audit signatures --omit=dev` | exit 0, or documented registry/network blocker without a false pass | |

## Acceptance evidence

- [ ] Exhaustive Policy fixtures prove precedence, read/write fallback, non-TTY Ask->Deny, `--yes` scope, hard Deny, and shell-operator rejection. **Actual result:**
- [ ] Deny writes no `prepared`; approval is durable before execution and recovery reconstructs the same decision without hidden grants. **Actual result:**
- [ ] canonical-parent/`..`/existing-symlink/new-target fixtures pass; results explicitly make no adversarial TOCTOU claim for file tools. **Actual result:**
- [ ] Native timeout/Ctrl-C preserves direct-child terminal and original-PGID cleanup observation; a self-expiring setsid fixture records `descendantsReaped=false`, durable completion, and no indeterminate. **Actual result:**
- [ ] `doctor` and README state that v0.1 has no built-in bash execution isolation, non-Windows bash has no external runtime prerequisite, and Windows bash is unavailable, while accurately reporting their remaining configuration, credential-metadata, file-mode, package, dependency, and platform diagnostics. **Actual result:**
- [ ] `.env` checks pass; only CredentialLoader automatically reads the file, key appears only in `src/ds`'s transient Authorization header, captures are redacted, child env is closed, and the automatic credential path never reaches Snapshot body, Journal/Artifact/log/diagnostics/Context/argv/child env/handoff. Bash boundary tests use no real secret and document the same-user limitation. **Actual result:**
- [ ] Stage 01 pins/shrinkwrap/ignored-scripts/lifecycle allowlist/count baseline remains intact or has a reviewed attributable tightening; audit, signatures, and isolated install produce separate evidence. **Actual result:**

## Independent review

A fresh read-only reviewer must inspect Policy precedence/grammar, approval durability, deterministic file containment and honest TOCTOU limits, native cleanup observation without full-tree claims, the explicit no-bash-isolation statement, automatic credential handling, doctor output, and dependency controls before implementation proceeds.

- **Reviewer context/date:**
- **Verdict:**
- **Required cuts/evidence:**

## No-go conditions

- Gate 1 effect/recovery/process evidence is incomplete, or permission decisions require a second mutable store.
- Policy or realpath is marketed as adversarial bash isolation, documentation implies that same-user bash cannot read accessible host files, or a non-Windows bash path gains an external runtime/capability prerequisite.
- Approval can override Deny, non-TTY Ask silently allows, or a shell prefix authorizes a chained command.
- Permission/path handling changes Effect ordering, an application-layer guard is reported as TOCTOU-safe, cleanup observation is marketed as full-tree containment, or `descendantsReaped=false` becomes indeterminate.
- `.env` is trackable/packed/symlinked/not `0600`, the automatic credential path reaches a persisted/model/tool surface, backend identity is env-configurable, `.dsh` permissions are loose, or dependency controls can drift silently.

## Handoff evidence

Return baseline/dirty state, paths, Policy/containment matrix, the durable permission event id/hash, path-component fixtures, native lifecycle and honest setsid observation, factual doctor output, `.env` ignore/mode/package and automatic credential-path results without values, the explicit same-user bash marker, dependency/lifecycle inventory, shrinkwrap hash, audits, commands/exits, verdict, and Stage 09–12 assumptions.

## Completion and cleanup

- [ ] Fill all Actual result, revision, exit, evidence, platform, and reviewer fields.
- [ ] Move durable permission/file-containment/supply-chain semantics into the Spec; promote only reusable security workflows.
- [ ] Make downstream stages depend on accepted evidence hashes, then remove this Plan and its `PLANS.md` row; Git history is the archive.
