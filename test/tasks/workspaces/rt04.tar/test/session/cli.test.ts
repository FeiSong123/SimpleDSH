import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..", "..", "..");
const cliPath = resolve(projectRoot, "dist/src/cli.js");

function runCli(
  arguments_: readonly string[],
  options: Readonly<{ cwd?: string; input?: string }> = {},
) {
  return spawnSync(process.execPath, [cliPath, ...arguments_], {
    cwd: options.cwd ?? projectRoot,
    encoding: "utf8",
    env: {},
    input: options.input,
    timeout: 5_000,
  });
}

test("CLI help is local, stable, and credential independent", () => {
  const result = runCli(["--help"]);

  assert.equal(result.error, undefined);
  assert.equal(result.signal, null);
  assert.equal(result.status, 0);
  assert.equal(
    result.stdout,
    "Usage: dsh run <prompt...>\n       printf '<prompt>' | dsh run\n",
  );
  assert.equal(result.stderr, "");
});

test("CLI rejects invalid input with a fixed exit and no stdout", () => {
  const result = runCli([]);

  assert.equal(result.error, undefined);
  assert.equal(result.signal, null);
  assert.equal(result.status, 2);
  assert.equal(result.stdout, "");
  assert.equal(result.stderr, "dsh: invalid_invocation\n");
});

test("CLI fails closed before a request when the credential is absent", () => {
  const workspace = mkdtempSync(join(tmpdir(), "simpledsh-cli-missing-key-"));
  try {
    const result = runCli(["run", "offline prompt"], { cwd: workspace });

    assert.equal(result.error, undefined);
    assert.equal(result.signal, null);
    assert.equal(result.status, 3);
    assert.equal(result.stdout, "");
    assert.equal(result.stderr, "dsh: credential_missing\n");
  } finally {
    rmSync(workspace, { recursive: true, force: true });
  }
});
